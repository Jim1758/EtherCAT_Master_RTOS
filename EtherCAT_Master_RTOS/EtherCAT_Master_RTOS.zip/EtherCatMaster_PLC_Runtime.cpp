#include "EtherCatMaster.h"
#include "EtherCatMaster_DC_Internal.h"
#include "GlobalConfig.h"
#include <windows.h>
#include <rtapi.h>
#include <rtssapi.h>
#include <stdio.h>





//PLC ���_�@�~----------------------------------------------------------
void RTAPI GlobalTimerHandler_PLC(void* nContext)
{
    EtherCatMaster* pMaster =
        (EtherCatMaster*)nContext;

    if (pMaster == nullptr)
    {
        return;
    }


    // =========================================================
    // PLC Cycle
    //
    // �`�N�G
    //
    // PLC Handler �������I EtherCAT IO Map�C
    //
    // EtherCAT Physical I/O�G
    // �� 250us PDO Handler �Τ@�޲z�C
    //
    // PLC Handler�G
    // �u�t�d Shadow Buffer <-> PLC Logic�C
    // =========================================================


    // =========================================================
    // 1. Shadow Input -> PLC Virtual I/O
    // =========================================================

    pMaster->m_Plc.SyncPhysicalToVirtual();


    // =========================================================
    // 2. PLC Logic
    // =========================================================

    if (g_PLC != nullptr)
    {
        g_PLC->RunCycle(1);
    }


    // =========================================================
    // 3. PLC Virtual Output -> Shadow Output
    //
    // �`�N�G
    //
    // �o�̥u��s Shadow Output�C
    //
    // ���n�b PLC Handler FlushOutputs�C
    //
    // �U�@�� PDO 250us Cycle �}�l�ɡA
    // PDO Handler �|�Τ@ FlushOutputs�C
    // =========================================================

    pMaster->m_Plc.SyncVirtualToPhysical();


    pMaster->tickCount_PLC++;

    //�]���O����----------------------------------------


    if (pMaster->tickCount_PLC % 30 == 0)//50
    {
       // pMaster->m_Plc.Update_Debug();
    }
}

