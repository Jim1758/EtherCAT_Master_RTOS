// ============================================================
// CoordinateManager_TravelLimit.cpp
//
// Software Travel Limit / Stored Stroke Check
//
// �\���k�ݡGCoordinateManager
//
// �t�d�G
//
// 1. G22 / G23 Modal State
// 2. Software Travel Limit 1
// 3. Software Travel Limit 2
// 4. Software Travel Limit 3
// 5. Automatic Target Pre-Check
// 6. Manual Direction Permission
//
// ���t�d�G
//
// - Physical +OT / -OT
// - Alarm
// - Motion Stop
// - HOME Limit Sequence
//
// ============================================================

#include "CoordinateManager.h"
#include "MotionCore.h"
#include <cmath>
#include "NCManager.h"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include "GlobalConfig.h"
#include "EtherCatMaster.h"
#include "GlobalConfig.h" // �p�G�A���Ψ� DEBUG_PRINT ���\��
namespace
{
    // ========================================================
    // Travel Limit Range Validation
    //
    // ���`��{�d�򥲶��G
    //
    // Negative Limit < Positive Limit
    //
    // �Ҧp�G
    //
    // -10.0 ~ +500.0
    //
    // Enable=true ���d����~�ɡA
    // �ثe�������L�Ľd��C
    //
    // ���� Parameter Alarm ����A�[�J�C
    // ========================================================
    bool IsValidTravelLimitRange(
        double negativeLimit,
        double positiveLimit)
    {
        if (!std::isfinite(negativeLimit) ||
            !std::isfinite(positiveLimit))
        {
            return false;
        }

        return negativeLimit < positiveLimit;
    }


    // ========================================================
    // Get Actual Machine Position
    //
    // AxisContext.currentActPos�G
    //     Pulse
    //
    // �ഫ���G
    //
    // Linear Axis:
    //     mm
    //
    // Rotary Axis:
    //     degree
    //
    // --------------------------------------------------------
    // �����򤣥� CoordinateManager::actualMCS[]�G
    //
    // �{�� MotionCore �� Rotary Axis ��ܮy�Хi�వ
    // modulo 360�C
    //
    // Software Travel Limit �����ϥίu���i�}�᪺��m�A
    // ����]�� 370 degree ��ܦ� 10 degree
    // �N���h��{�O�@�C
    // ========================================================
    double GetActualMachinePositionUnit(
        const AxisContext& axis)
    {
        if (axis.resolution_PPR <= 0.0)
        {
            return 0.0;
        }

        return
            axis.currentActPos *
            (axis.finalLead / axis.resolution_PPR);
    }
}


// ============================================================
// G22 / G23
// ============================================================

void CoordinateManager::SetStoredStrokeCheckMode( int gCode,NCManager* nc)
{
    // �ثe���ϥ� NCManager�C
    // ����Y�n�� Alarm / System Variable / Log
    // �i�H�����q�o�ӤJ�f�X�R�C
    (void)nc;


    switch (gCode)
    {
    case 22:

        // G22
        //
        // Enable Programmable Travel Limit 1
        m_programmableTravelLimitEnabled = true;
        nc->MacroSys.SetVar('$', 4, 22.0);
        break;


    case 23:

        // G23
        //
        // Disable Programmable Travel Limit 1
        m_programmableTravelLimitEnabled = false;
        nc->MacroSys.SetVar('$', 4, 23.0);
        break;


    default:

        // �o�� API �u���� G22 / G23�C
        //
        // ���b CoordinateManager ���� G-Code Alarm�C
        // Unsupported G-Code ���� NCManager / Parser �t�d�C


        break;
    }
}


// ============================================================
// Direct Runtime State Setter
//
// ������ Power-On Parameter / Reset �ϥΡC
// ============================================================

void CoordinateManager::SetProgrammableTravelLimitEnabled(
    bool enabled, NCManager* nc)
{
    m_programmableTravelLimitEnabled =
        enabled;

    if (enabled == true)
    {
        nc->MacroSys.SetVar('$', 4, 22.0);
    }
    else
    {
        nc->MacroSys.SetVar('$', 4, 23.0);
    }



}


// ============================================================
// G22 / G23 State Query
// ============================================================

bool CoordinateManager::IsProgrammableTravelLimitEnabled() const
{
    return
        m_programmableTravelLimitEnabled;
}


// ============================================================
// Update Software Travel Limit Runtime State
// ============================================================

void CoordinateManager::UpdateSoftwareTravelLimitState(
    AxisContext& axis) const
{
    // ========================================================
    // 1. �C�� Scan ���M���ª��A
    // ========================================================

    axis.travelLimit1PositiveActive = false;
    axis.travelLimit1NegativeActive = false;

    axis.travelLimit2PositiveActive = false;
    axis.travelLimit2NegativeActive = false;

    axis.travelLimit3PositiveActive = false;
    axis.travelLimit3NegativeActive = false;


    // ========================================================
    // 2. ���s�b���b�����P�_
    // ========================================================

    if (!axis.isExist)
    {
        return;
    }


    // ========================================================
    // 3. �|���إ� Machine Coordinate �ɤ��ҥ� Soft Limit
    //
    // Software Travel Limit �O Machine Coordinate Protection�C
    //
    // HOME �|�������H�e�A
    // Machine Zero �|���i�a�إߡA
    // ���������~�y�а� Software Limit �P�_�C
    //
    // �`�N�G
    // �A�{�b axis.isHomed �w�]���O true�A
    // �ҥH�ثe�J���t�Φ欰���|�]�����ܡC
    //
    // HOME ����������A�� Power-On �w�]�令 false�C
    // ========================================================

    if (!axis.isHomed)
    {
        return;
    }


    // ========================================================
    // 4. ���o�u�� Machine Position
    //
    // Linear = mm
    // Rotary = degree
    // ========================================================

    const double currentPosition =
        GetActualMachinePositionUnit(axis);


    // ========================================================
    // 5. Software Travel Limit 1
    //
    // Parameter Enable
    // +
    // G22 / G23
    // ========================================================

    if (axis.travelLimit1Enable &&
        m_programmableTravelLimitEnabled &&
        IsValidTravelLimitRange(
            axis.travelLimit1Negative_unit,
            axis.travelLimit1Positive_unit))
    {
        if (currentPosition >=
            axis.travelLimit1Positive_unit)
        {
            axis.travelLimit1PositiveActive =
                true;
        }

        if (currentPosition <=
            axis.travelLimit1Negative_unit)
        {
            axis.travelLimit1NegativeActive =
                true;
        }
    }


    // ========================================================
    // 6. Software Travel Limit 2
    //
    // Parameter Enable Only
    //
    // ���� G22 / G23 �v�T�C
    // ========================================================

    if (axis.travelLimit2Enable &&
        IsValidTravelLimitRange(
            axis.travelLimit2Negative_unit,
            axis.travelLimit2Positive_unit))
    {
        if (currentPosition >=
            axis.travelLimit2Positive_unit)
        {
            axis.travelLimit2PositiveActive =
                true;
        }

        if (currentPosition <=
            axis.travelLimit2Negative_unit)
        {
            axis.travelLimit2NegativeActive =
                true;
        }
    }


    // ========================================================
    // 7. Software Travel Limit 3
    //
    // Parameter Enable Only
    //
    // ���� G22 / G23 �v�T�C
    // ========================================================

    if (axis.travelLimit3Enable &&
        IsValidTravelLimitRange(
            axis.travelLimit3Negative_unit,
            axis.travelLimit3Positive_unit))
    {
        if (currentPosition >=
            axis.travelLimit3Positive_unit)
        {
            axis.travelLimit3PositiveActive =
                true;
        }

        if (currentPosition <=
            axis.travelLimit3Negative_unit)
        {
            axis.travelLimit3NegativeActive =
                true;
        }
    }
}


// ============================================================
// Automatic Target Pre-Check
//
// Target �ϥ� Machine Coordinate Unit�G
//
// Linear = mm
// Rotary = degree
//
// ��ɥ������\��F�G
//
// target == Positive Limit
// target == Negative Limit
//
// �u���u���W�X�h�~�^�� false�C
// ============================================================

bool CoordinateManager::IsTargetWithinSoftwareTravelLimit(
    const AxisContext& axis,
    double targetMCS) const
{
    // ========================================================
    // 1. ���b
    // ========================================================

    if (!axis.isExist)
    {
        return true;
    }


    if (!std::isfinite(targetMCS))
    {
        return false;
    }


    // ========================================================
    // 2. HOME �e���ϥ� Software Travel Limit
    // ========================================================

    if (!axis.isHomed)
    {
        return true;
    }


    // ========================================================
    // 3. Travel Limit 1
    //
    // Parameter Enable + G22/G23
    // ========================================================

    if (axis.travelLimit1Enable &&
        m_programmableTravelLimitEnabled &&
        IsValidTravelLimitRange(
            axis.travelLimit1Negative_unit,
            axis.travelLimit1Positive_unit))
    {
        if (targetMCS <
            axis.travelLimit1Negative_unit ||
            targetMCS >
            axis.travelLimit1Positive_unit)
        {
            return false;
        }
    }


    // ========================================================
    // 4. Travel Limit 2
    // ========================================================

    if (axis.travelLimit2Enable &&
        IsValidTravelLimitRange(
            axis.travelLimit2Negative_unit,
            axis.travelLimit2Positive_unit))
    {
        if (targetMCS <
            axis.travelLimit2Negative_unit ||
            targetMCS >
            axis.travelLimit2Positive_unit)
        {
            return false;
        }
    }


    // ========================================================
    // 5. Travel Limit 3
    // ========================================================

    if (axis.travelLimit3Enable &&
        IsValidTravelLimitRange(
            axis.travelLimit3Negative_unit,
            axis.travelLimit3Positive_unit))
    {
        if (targetMCS <
            axis.travelLimit3Negative_unit ||
            targetMCS >
            axis.travelLimit3Positive_unit)
        {
            return false;
        }
    }


    return true;
}


// ============================================================
// Manual Positive Direction Permission
//
// Software Limit ��F + Side �ɡG
//
// + Direction = Block
// - Direction = Allowed
//
// �`�N�G
// �o�̧������� Physical +OT�C
// Physical Limit ����� NCPLCManager �A�|�[�C
// ============================================================

bool CoordinateManager::CanMoveSoftwarePositive(
    const AxisContext& axis) const
{
    if (axis.travelLimit1PositiveActive)
    {
        return false;
    }

    if (axis.travelLimit2PositiveActive)
    {
        return false;
    }

    if (axis.travelLimit3PositiveActive)
    {
        return false;
    }

    return true;
}


// ============================================================
// Manual Negative Direction Permission
//
// Software Limit ��F - Side �ɡG
//
// - Direction = Block
// + Direction = Allowed
// ============================================================

bool CoordinateManager::CanMoveSoftwareNegative(
    const AxisContext& axis) const
{
    if (axis.travelLimit1NegativeActive)
    {
        return false;
    }

    if (axis.travelLimit2NegativeActive)
    {
        return false;
    }

    if (axis.travelLimit3NegativeActive)
    {
        return false;
    }

    return true;
}