﻿// 檔案：EtherCatMaster_Run.cpp
#include "EtherCatMaster.h"
#include "GlobalConfig.h" // 如果你有用到 DEBUG_PRINT 等功能
#include <windows.h> 
#include <rtapi.h> 
#include <rtssapi.h> 
#include <stdio.h>
#include "SHMManager.h"
#include "EtherCatWatchdogDiagPublisher.h" // Stage 12E.7D - P50 Watchdog SHM publisher
#include "EtherCatDcQualificationDiagContract.h" // Stage 17A.3C.1 - MAD qualification recorder
#include "EtherCatDcV1aDiagContract.h" // Stage 17A.5.1 - V1A observer forensics
#include "EtherCatRxCorrelationDiagContract.h" // Stage 17A.8.1 - RX/V1A correlation
#include "EtherCatRxForensics.h" // DC-RX.4A - owner-safe incident/ESC snapshots
#include "EtherCatRxForensicsDiagContract.h" // DC-RX.4B - Windows read-only SHM bridge
#include "EtherCatP64DeferredDiagnostics.h" // DC-DIAG.2 - P64 numeric event handoff
#include "HMI_Bridge.h"    // 🌟 1. 引入橋接器
#include "AlarmManager.h"
#include "PLCManager.h" // 🌟 1. 引入 PLC 管理器標頭檔
#include "NCPLCManager.h"
#include "HomePersistenceManager.h"
#include "EtherCatMaster_DC_Internal.h" // Stage 12A.3 - stable DC/RX diagnostic snapshots
#include "EtherCatMaster_DC_Topology.h" // Stage 12A.3 - selected DC reference
#include <cstring>


// ============================================================================
// DC-DIAG.1 - Explicit stack boundaries for Priority-50 diagnostics
// ============================================================================
//
// The supervisory loop has a fixed RTX64 stack.  Keep every diagnostic family
// behind a real call boundary so compiler inlining cannot merge their local
// frames into RunRealTimeCycle_EDM_SINKER_MODE().
// ============================================================================
#if defined(_MSC_VER)
#define OSCARMAX_DIAG_NOINLINE __declspec(noinline)
#elif defined(__GNUC__) || defined(__clang__)
#define OSCARMAX_DIAG_NOINLINE __attribute__((noinline))
#else
#define OSCARMAX_DIAG_NOINLINE
#endif


// ============================================================================
// Stage 12B.1C - OSCARMAX EtherCAT Online Diagnosis Publisher
// ============================================================================
//
// This publisher is the ONLY writer of OSCARMAX_ECAT_DIAG Shared Memory.
// It runs on the existing Priority-50 supervisory loop and NEVER reads
// EtherCatMaster::m_IoMap directly.
//
// Process Image ownership:
//     Priority-64 PDO thread -> fixed RT shadow snapshot (Stage 12B.1B)
//     Priority-50 publisher  -> OSCARMAX_ECAT_DIAG Shared Memory (this stage)
//
// The RT reader is bounded and lock-free. If one 100 Hz capture overlaps the
// Priority-50 read, this publisher keeps the previously published image and
// tries again on the next supervisory iteration. No retry loop is used here.
//
// Publisher cadence (DC-DIAG.1):
//     100 ms, staggered by the Priority-50 diagnostic scheduler.
//
// Shared Memory lifecycle:
//     This publisher runs in the same thread that creates/closes SHMManager,
//     therefore there is no producer-vs-close lifetime race in Stage 12A.
// ============================================================================

// Defined by EtherCatMaster_DC_Runtime.cpp (Stage 12B.1B).
// Priority-50 reads a coherent copy of the Priority-64 owner snapshot through
// this bounded seam. No caller receives a pointer to the RT-owned buffer.
extern "C" bool OSCARMAX_ECAT_DiagRtShadow_Read(
    uint8_t * destination,
    uint32_t destinationCapacity,
    uint32_t * processImageBytes,
    uint32_t * processImageValid,
    int32_t * actualLrwWkc,
    int32_t * dcWkc,
    uint64_t * sourcePdoTick,
    uint64_t * lastValidPdoTick,
    uint64_t * captureAttempts,
    uint64_t * validSnapshots,
    uint64_t * invalidSkips,
    uint64_t * lastCostNs,
    uint64_t * maxCostNs,
    uint64_t * averageCostNs);


// ============================================================================
// Stage 12E.3B - Priority-50 ESC Live Diagnostic Publisher Seam
// ============================================================================
//
// Stage 12E.3A keeps all physical ESC register access in the Priority-64 PDO
// owner.  Priority-50 receives only a coherent per-slave shadow copy through
// this bounded reader.  No NIC access, retry loop, wait or Sleep is introduced
// here.
//
// Existing OSCARMAX_ECAT_DIAG v1.0 fields are reused:
//     AlState / AlStatusCode / LinkUp / RxErrorCount / LostLinkCount
//
// SHM_ECAT_DiagSlaveStatus::Reserved[] is also populated with compact raw ESC
// details for the next ENI Tool presentation stage, without changing ABI:
//     [0]     PhysicalLinkMask
//     [1]     CommunicationMask
//     [2..3]  DL Status (little-endian)
//     [4..7]  ValidMask (little-endian)
//     [8..11] LastTransportResult (int32 little-endian)
//     [12..15] LastUpdateTick low32 (little-endian)
//
// Source fingerprint:
//     OSCARMAX_ESC_DIAG_P50_12E3B_20260826
// ============================================================================
extern "C" bool OSCARMAX_ECAT_EscDiagRt_Read(
    uint16_t slavePosition,
    uint32_t * validMask,
    uint16_t * alState,
    uint16_t * alStatusCode,
    uint16_t * dlStatus,
    uint8_t * physicalLinkMask,
    uint8_t * communicationMask,
    uint32_t * rxErrorCount,
    uint32_t * lostLinkCount,
    int32_t * lastTransportResult,
    uint64_t * lastUpdateTick,
    uint64_t * probeSuccess,
    uint64_t * probeFailure);


// ============================================================================
// Stage 12E.4E - Priority-50 SyncManager Live Diagnostic Publisher Seam
// ============================================================================
//
// Stage 12E.4A owns all physical ESC SyncManager reads in Priority-64.
// Priority-50 receives one coherent, lock-free shadow entry at a time and
// publishes it into the dedicated OSCARMAX_ECAT_SM_DIAG mapping created by
// SHMManager.cpp. Windows remains strictly read-only.
//
// No EtherCAT frame, retry, wait or Sleep is generated by this reader seam.
// A seqlock collision simply returns false and the next scheduled publisher
// pass retries naturally.
//
// Source fingerprint:
//     OSCARMAX_ECAT_SM_DIAG_P50_12E4E_20260826
// ============================================================================
extern "C" bool OSCARMAX_ECAT_SmDiagRt_Read(
    uint16_t slavePosition,
    uint8_t smIndex,
    uint32_t * present,
    uint32_t * valid,
    uint16_t * registerAddress,
    uint16_t * startAddress,
    uint16_t * length,
    uint8_t * controlByte,
    uint8_t * statusByte,
    uint8_t * activateByte,
    uint8_t * pdiControlByte,
    int32_t * lastTransportResult,
    uint64_t * lastUpdateTick,
    uint64_t * probeSuccess,
    uint64_t * probeFailure);


// ============================================================================
// Stage 12E.5E - Priority-50 FMMU Live Diagnostic Publisher Seam
// ============================================================================
//
// Stage 12E.5A owns all physical ESC FMMU reads in Priority-64.
// Priority-50 receives one coherent, lock-free shadow entry at a time and
// publishes it into the dedicated OSCARMAX_ECAT_FMMU_DIAG mapping created by
// SHMManager.cpp. Windows remains strictly read-only.
//
// No EtherCAT frame, retry, wait or Sleep is generated by this reader seam.
// A seqlock collision simply returns false and the next scheduled publisher
// pass retries naturally.
//
// Source fingerprint:
//     OSCARMAX_ECAT_FMMU_DIAG_P50_12E5E_20260826
// ============================================================================
extern "C" bool OSCARMAX_ECAT_FmmuDiagRt_Read(
    uint16_t slavePosition,
    uint8_t fmmuIndex,
    uint32_t * present,
    uint32_t * valid,
    uint16_t * registerAddress,
    uint32_t * logicalStartAddress,
    uint16_t * logicalLength,
    uint8_t * logicalStartBit,
    uint8_t * logicalEndBit,
    uint16_t * physicalStartAddress,
    uint8_t * physicalStartBit,
    uint8_t * type,
    uint8_t * activate,
    int32_t * lastTransportResult,
    uint64_t * lastUpdateTick,
    uint64_t * probeSuccess,
    uint64_t * probeFailure);


namespace
{
    constexpr uint32_t kEcatEscDiagValidAl = 0x00000001u;
    constexpr uint32_t kEcatEscDiagValidDl = 0x00000002u;
    constexpr uint32_t kEcatEscDiagValidErrors = 0x00000004u;

    void EcatDiagStoreU16Le(
        uint8_t* destination,
        uint16_t value)
    {
        destination[0] = static_cast<uint8_t>(value & 0xFFu);
        destination[1] = static_cast<uint8_t>((value >> 8) & 0xFFu);
    }

    void EcatDiagStoreU32Le(
        uint8_t* destination,
        uint32_t value)
    {
        destination[0] = static_cast<uint8_t>(value & 0xFFu);
        destination[1] = static_cast<uint8_t>((value >> 8) & 0xFFu);
        destination[2] = static_cast<uint8_t>((value >> 16) & 0xFFu);
        destination[3] = static_cast<uint8_t>((value >> 24) & 0xFFu);
    }
}



// ============================================================================
// Stage 12E.4E - OSCARMAX_ECAT_SM_DIAG Priority-50 Publisher
// ============================================================================
//
// Writer ownership:
//     Priority-64 : reads ESC SM registers into owner-safe RT shadow only.
//     Priority-50 : this function is the ONLY writer of OSCARMAX_ECAT_SM_DIAG.
//     Windows     : read-only consumer.
//
// Cadence (DC-DIAG.1):
//     250 ms, staggered by the Priority-50 diagnostic scheduler.
//
// Cost:
//     No NIC access occurs here. For the current seven-slave / four-SM system,
//     this function performs at most 112 bounded in-process shadow reads per
//     supervisory pass. A collision is skipped; no retry loop is used.
//
// Shared Memory ABI:
//     EtherCatSmDiagContract.h v1.0, 98368 bytes.
//     Existing EDM_CNC_SHM / OSCARMAX_ECAT_DIAG / OSCARMAX_ECAT_SERVICE are
//     untouched.
// ============================================================================
namespace
{
    OSCARMAX_DIAG_NOINLINE void PublishEtherCatSmDiagHealth(
        EtherCatMaster* masterCore)
    {
        if (masterCore == nullptr)
        {
            return;
        }

        SHM_ECAT_SmDiagData* smDiag =
            GetEtherCatSmDiagSharedMemoryData();

        if (smDiag == nullptr)
        {
            return;
        }

        const auto* runtimeSlaves =
            (masterCore->m_pEni != nullptr)
            ? &masterCore->m_pEni->GetSlaves()
            : nullptr;

        uint32_t slaveCount = 0u;

        if (runtimeSlaves != nullptr)
        {
            slaveCount =
                static_cast<uint32_t>(runtimeSlaves->size());
        }

        if (slaveCount > SHM_ECAT_SM_DIAG_MAX_SLAVES)
        {
            slaveCount = SHM_ECAT_SM_DIAG_MAX_SLAVES;
        }

        static SHM_ECAT_SmDiagData* lastMapping = nullptr;
        static uint32_t lastSlaveCount = 0u;
        static uint64_t shadowReadSuccess = 0ULL;
        static uint64_t shadowReadMiss = 0ULL;

        const bool mappingChanged =
            lastMapping != smDiag;

        const uint32_t previousSlaveCount =
            mappingChanged ? 0u : lastSlaveCount;

        SHM_ECAT_SmDiagHeader& header =
            smDiag->Header;

        // odd = writer active
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(&header.Sequence));

        MemoryBarrier();

        header.Magic = SHM_ECAT_SM_DIAG_MAGIC;
        header.VersionMajor = SHM_ECAT_SM_DIAG_VERSION_MAJOR;
        header.VersionMinor = SHM_ECAT_SM_DIAG_VERSION_MINOR;
        header.StructSize =
            static_cast<uint32_t>(sizeof(SHM_ECAT_SmDiagData));
        header.Heartbeat++;
        header.PublishCount++;
        header.SlaveCount =
            static_cast<uint16_t>(slaveCount);
        header.MaxSyncManagers =
            static_cast<uint16_t>(
                SHM_ECAT_SM_DIAG_MAX_SYNC_MANAGERS);

        for (uint32_t slave = 0u;
            slave < slaveCount;
            ++slave)
        {
            for (uint32_t sm = 0u;
                sm < SHM_ECAT_SM_DIAG_MAX_SYNC_MANAGERS;
                ++sm)
            {
                const uint32_t flatIndex =
                    slave *
                    SHM_ECAT_SM_DIAG_MAX_SYNC_MANAGERS +
                    sm;

                SHM_ECAT_SmDiagEntry& target =
                    smDiag->Entries[flatIndex];

                // Fixed slot identity is refreshed defensively in case the
                // mapping was recreated while the process remained alive.
                target.SlavePosition =
                    static_cast<uint16_t>(slave);
                target.SmIndex =
                    static_cast<uint8_t>(sm);
                target.RegisterAddress =
                    static_cast<uint16_t>(
                        0x0800u +
                        static_cast<uint16_t>(sm * 8u));

                uint32_t present = 0u;
                uint32_t valid = 0u;
                uint16_t registerAddress = 0u;
                uint16_t startAddress = 0u;
                uint16_t length = 0u;
                uint8_t controlByte = 0u;
                uint8_t statusByte = 0u;
                uint8_t activateByte = 0u;
                uint8_t pdiControlByte = 0u;
                int32_t lastTransportResult = 0;
                uint64_t lastUpdateTick = 0ULL;
                uint64_t probeSuccess = 0ULL;
                uint64_t probeFailure = 0ULL;

                const bool readOk =
                    OSCARMAX_ECAT_SmDiagRt_Read(
                        static_cast<uint16_t>(slave),
                        static_cast<uint8_t>(sm),
                        &present,
                        &valid,
                        &registerAddress,
                        &startAddress,
                        &length,
                        &controlByte,
                        &statusByte,
                        &activateByte,
                        &pdiControlByte,
                        &lastTransportResult,
                        &lastUpdateTick,
                        &probeSuccess,
                        &probeFailure);

                if (!readOk)
                {
                    // Keep the previous coherent value. Priority-64 may be in
                    // the middle of its low-rate shadow update; retry next pass.
                    shadowReadMiss++;
                    continue;
                }

                shadowReadSuccess++;

                target.Present =
                    present != 0u ? 1u : 0u;
                target.Valid =
                    valid != 0u ? 1u : 0u;

                if (registerAddress != 0u)
                {
                    target.RegisterAddress = registerAddress;
                }

                if (present == 0u)
                {
                    // Do not expose stale values if a Runtime schema refresh
                    // removes a previously-present SyncManager.
                    target.Valid = 0u;
                    target.StartAddress = 0u;
                    target.Length = 0u;
                    target.ControlByte = 0u;
                    target.StatusByte = 0u;
                    target.ActivateByte = 0u;
                    target.PdiControlByte = 0u;
                    target.LastTransportResult = 0;
                    target.LastUpdateTick = 0ULL;
                    target.ProbeSuccess = 0ULL;
                    target.ProbeFailure = 0ULL;
                    continue;
                }

                // When Valid==0 the Runtime intentionally preserves the last
                // successful register bytes while publishing the failed latest
                // transport status. This lets Windows show STALE/INVALID rather
                // than losing the last-known-good engineering value.
                target.StartAddress = startAddress;
                target.Length = length;
                target.ControlByte = controlByte;
                target.StatusByte = statusByte;
                target.ActivateByte = activateByte;
                target.PdiControlByte = pdiControlByte;
                target.LastTransportResult = lastTransportResult;
                target.LastUpdateTick = lastUpdateTick;
                target.ProbeSuccess = probeSuccess;
                target.ProbeFailure = probeFailure;
            }
        }

        // Defensive cleanup if a future Runtime topology is reloaded with
        // fewer slaves while the same Shared Memory mapping remains open.
        if (previousSlaveCount > slaveCount)
        {
            uint32_t clearEnd = previousSlaveCount;

            if (clearEnd > SHM_ECAT_SM_DIAG_MAX_SLAVES)
            {
                clearEnd = SHM_ECAT_SM_DIAG_MAX_SLAVES;
            }

            for (uint32_t slave = slaveCount;
                slave < clearEnd;
                ++slave)
            {
                for (uint32_t sm = 0u;
                    sm < SHM_ECAT_SM_DIAG_MAX_SYNC_MANAGERS;
                    ++sm)
                {
                    const uint32_t flatIndex =
                        slave *
                        SHM_ECAT_SM_DIAG_MAX_SYNC_MANAGERS +
                        sm;

                    SHM_ECAT_SmDiagEntry& target =
                        smDiag->Entries[flatIndex];

                    std::memset(
                        &target,
                        0,
                        sizeof(target));

                    target.SlavePosition =
                        static_cast<uint16_t>(slave);
                    target.SmIndex =
                        static_cast<uint8_t>(sm);
                    target.RegisterAddress =
                        static_cast<uint16_t>(
                            0x0800u +
                            static_cast<uint16_t>(sm * 8u));
                }
            }
        }

        // Reserved globals remain ABI-safe diagnostic observability. They are
        // optional for Windows v1.0; no presentation dependency is required.
        header.Reserved32[0] =
            shadowReadSuccess > 0xFFFFFFFFULL
            ? 0xFFFFFFFFu
            : static_cast<uint32_t>(shadowReadSuccess);
        header.Reserved32[1] =
            shadowReadMiss > 0xFFFFFFFFULL
            ? 0xFFFFFFFFu
            : static_cast<uint32_t>(shadowReadMiss);
        header.Reserved32[2] = 0x12E0040Eu; // Stage 12E.4E marker

        MemoryBarrier();

        // even = coherent Shared Memory snapshot
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(&header.Sequence));

        lastMapping = smDiag;
        lastSlaveCount = slaveCount;
    }
}


// ============================================================================
// Stage 12E.5E - OSCARMAX_ECAT_FMMU_DIAG Priority-50 Publisher
// ============================================================================
//
// Writer ownership:
//     Priority-64 : reads ESC FMMU registers into owner-safe RT shadow only.
//     Priority-50 : this function is the ONLY writer of OSCARMAX_ECAT_FMMU_DIAG.
//     Windows     : read-only consumer.
//
// Cadence (DC-DIAG.1):
//     250 ms, staggered by the Priority-50 diagnostic scheduler.
//
// Cost:
//     No NIC access occurs here. For the current topology, this function
//     performs bounded in-process shadow reads only. A seqlock collision is
//     skipped; no retry loop is used.
//
// Shared Memory ABI:
//     EtherCatFmmuDiagContract.h v1.0, 114752 bytes.
//     Existing EDM_CNC_SHM / OSCARMAX_ECAT_DIAG / OSCARMAX_ECAT_SM_DIAG /
//     OSCARMAX_ECAT_SERVICE are untouched.
//
// Source fingerprint:
//     OSCARMAX_ECAT_FMMU_DIAG_PUBLISHER_12E5E_20260826
// ============================================================================
namespace
{
    OSCARMAX_DIAG_NOINLINE void PublishEtherCatFmmuDiagHealth(
        EtherCatMaster* masterCore)
    {
        if (masterCore == nullptr)
        {
            return;
        }

        SHM_ECAT_FmmuDiagData* fmmuDiag =
            GetEtherCatFmmuDiagSharedMemoryData();

        if (fmmuDiag == nullptr)
        {
            return;
        }

        const auto* runtimeSlaves =
            (masterCore->m_pEni != nullptr)
            ? &masterCore->m_pEni->GetSlaves()
            : nullptr;

        uint32_t slaveCount = 0u;

        if (runtimeSlaves != nullptr)
        {
            slaveCount =
                static_cast<uint32_t>(
                    runtimeSlaves->size());
        }

        if (slaveCount > SHM_ECAT_FMMU_DIAG_MAX_SLAVES)
        {
            slaveCount =
                SHM_ECAT_FMMU_DIAG_MAX_SLAVES;
        }

        static SHM_ECAT_FmmuDiagData* lastMapping = nullptr;
        static uint32_t lastSlaveCount = 0u;
        static uint64_t shadowReadSuccess = 0ULL;
        static uint64_t shadowReadMiss = 0ULL;

        const bool mappingChanged =
            lastMapping != fmmuDiag;

        const uint32_t previousSlaveCount =
            mappingChanged
            ? 0u
            : lastSlaveCount;

        SHM_ECAT_FmmuDiagHeader& header =
            fmmuDiag->Header;

        // odd = writer active
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        MemoryBarrier();

        header.Magic =
            SHM_ECAT_FMMU_DIAG_MAGIC;

        header.VersionMajor =
            SHM_ECAT_FMMU_DIAG_VERSION_MAJOR;

        header.VersionMinor =
            SHM_ECAT_FMMU_DIAG_VERSION_MINOR;

        header.StructSize =
            static_cast<uint32_t>(
                sizeof(SHM_ECAT_FmmuDiagData));

        header.Heartbeat++;
        header.PublishCount++;

        header.SlaveCount =
            static_cast<uint16_t>(
                slaveCount);

        header.MaxFmmus =
            static_cast<uint16_t>(
                SHM_ECAT_FMMU_DIAG_MAX_FMMUS);

        for (uint32_t slave = 0u;
            slave < slaveCount;
            ++slave)
        {
            for (uint32_t fmmu = 0u;
                fmmu < SHM_ECAT_FMMU_DIAG_MAX_FMMUS;
                ++fmmu)
            {
                const uint32_t flatIndex =
                    slave *
                    SHM_ECAT_FMMU_DIAG_MAX_FMMUS +
                    fmmu;

                SHM_ECAT_FmmuDiagEntry& target =
                    fmmuDiag->Entries[flatIndex];

                // Fixed slot identity is refreshed defensively in case the
                // mapping was recreated while the process remained alive.
                target.SlavePosition =
                    static_cast<uint16_t>(
                        slave);

                target.FmmuIndex =
                    static_cast<uint8_t>(
                        fmmu);

                target.RegisterAddress =
                    static_cast<uint16_t>(
                        0x0600u +
                        static_cast<uint16_t>(
                            fmmu * 16u));

                uint32_t present = 0u;
                uint32_t valid = 0u;
                uint16_t registerAddress = 0u;

                uint32_t logicalStartAddress = 0u;
                uint16_t logicalLength = 0u;
                uint8_t logicalStartBit = 0u;
                uint8_t logicalEndBit = 0u;

                uint16_t physicalStartAddress = 0u;
                uint8_t physicalStartBit = 0u;

                uint8_t type = 0u;
                uint8_t activate = 0u;

                int32_t lastTransportResult = 0;
                uint64_t lastUpdateTick = 0ULL;
                uint64_t probeSuccess = 0ULL;
                uint64_t probeFailure = 0ULL;

                const bool readOk =
                    OSCARMAX_ECAT_FmmuDiagRt_Read(
                        static_cast<uint16_t>(
                            slave),
                        static_cast<uint8_t>(
                            fmmu),
                        &present,
                        &valid,
                        &registerAddress,
                        &logicalStartAddress,
                        &logicalLength,
                        &logicalStartBit,
                        &logicalEndBit,
                        &physicalStartAddress,
                        &physicalStartBit,
                        &type,
                        &activate,
                        &lastTransportResult,
                        &lastUpdateTick,
                        &probeSuccess,
                        &probeFailure);

                if (!readOk)
                {
                    // Keep the previous coherent value. Priority-64 may be
                    // updating its owner-safe shadow. Retry next scheduled pass.
                    shadowReadMiss++;
                    continue;
                }

                shadowReadSuccess++;

                target.Present =
                    present != 0u
                    ? 1u
                    : 0u;

                target.Valid =
                    valid != 0u
                    ? 1u
                    : 0u;

                if (registerAddress != 0u)
                {
                    target.RegisterAddress =
                        registerAddress;
                }

                if (present == 0u)
                {
                    // Do not expose stale values if a Runtime schema refresh
                    // removes a previously-present FMMU.
                    target.Valid = 0u;

                    target.LogicalStartAddress = 0u;
                    target.LogicalLength = 0u;
                    target.LogicalStartBit = 0u;
                    target.LogicalEndBit = 0u;

                    target.PhysicalStartAddress = 0u;
                    target.PhysicalStartBit = 0u;

                    target.Type = 0u;
                    target.Activate = 0u;

                    target.LastTransportResult = 0;
                    target.LastUpdateTick = 0ULL;
                    target.ProbeSuccess = 0ULL;
                    target.ProbeFailure = 0ULL;
                    continue;
                }

                // When Valid==0 the Runtime intentionally preserves the last
                // successful register values while publishing the latest
                // transport status. Windows can therefore show STALE/INVALID
                // without losing the last-known-good engineering values.
                target.LogicalStartAddress =
                    logicalStartAddress;

                target.LogicalLength =
                    logicalLength;

                target.LogicalStartBit =
                    logicalStartBit;

                target.LogicalEndBit =
                    logicalEndBit;

                target.PhysicalStartAddress =
                    physicalStartAddress;

                target.PhysicalStartBit =
                    physicalStartBit;

                target.Type =
                    type;

                target.Activate =
                    activate;

                target.LastTransportResult =
                    lastTransportResult;

                target.LastUpdateTick =
                    lastUpdateTick;

                target.ProbeSuccess =
                    probeSuccess;

                target.ProbeFailure =
                    probeFailure;
            }
        }

        // Defensive cleanup if a future Runtime topology is reloaded with
        // fewer slaves while the same Shared Memory mapping remains open.
        if (previousSlaveCount > slaveCount)
        {
            uint32_t clearEnd =
                previousSlaveCount;

            if (clearEnd >
                SHM_ECAT_FMMU_DIAG_MAX_SLAVES)
            {
                clearEnd =
                    SHM_ECAT_FMMU_DIAG_MAX_SLAVES;
            }

            for (uint32_t slave = slaveCount;
                slave < clearEnd;
                ++slave)
            {
                for (uint32_t fmmu = 0u;
                    fmmu <
                    SHM_ECAT_FMMU_DIAG_MAX_FMMUS;
                    ++fmmu)
                {
                    const uint32_t flatIndex =
                        slave *
                        SHM_ECAT_FMMU_DIAG_MAX_FMMUS +
                        fmmu;

                    SHM_ECAT_FmmuDiagEntry& target =
                        fmmuDiag->Entries[flatIndex];

                    std::memset(
                        &target,
                        0,
                        sizeof(target));

                    target.SlavePosition =
                        static_cast<uint16_t>(
                            slave);

                    target.FmmuIndex =
                        static_cast<uint8_t>(
                            fmmu);

                    target.RegisterAddress =
                        static_cast<uint16_t>(
                            0x0600u +
                            static_cast<uint16_t>(
                                fmmu * 16u));
                }
            }
        }

        // Reserved globals are optional observability only.
        header.Reserved32[0] =
            shadowReadSuccess >
            0xFFFFFFFFULL
            ? 0xFFFFFFFFu
            : static_cast<uint32_t>(
                shadowReadSuccess);

        header.Reserved32[1] =
            shadowReadMiss >
            0xFFFFFFFFULL
            ? 0xFFFFFFFFu
            : static_cast<uint32_t>(
                shadowReadMiss);

        header.Reserved32[2] =
            0x12E0050Eu; // Stage 12E.5E marker

        MemoryBarrier();

        // even = coherent Shared Memory snapshot
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        lastMapping =
            fmmuDiag;

        lastSlaveCount =
            slaveCount;
    }
}


// ============================================================================
// Stage 12F.3E.2B - Runtime-safe SDO transport diagnostics publisher seam
// ============================================================================
//
// EtherCatMaster_DC_Runtime.cpp owns the live P64 mailbox state machine and
// exposes only a bounded, coherent diagnostic snapshot.  Priority-50 copies
// that snapshot into RESERVED words of OSCARMAX_ECAT_SERVICE so the Windows
// ENI Tool can explain intermittent SDO failures without adding EtherCAT
// frames, locks, waits or mailbox work.
//
// IMPORTANT:
//   - Service ABI remains 128 bytes (v1.1 compatible).
//   - RequestReserved[] remains CLIENT-owned and is never touched here.
//   - HeaderReserved[0..2] + ResponseReserved are SERVER-owned diagnostics.
//   - Counter fields are intentionally saturated/packed for this compact v1.1
//     bridge.  A future ABI can expose the full 288-byte RT snapshot if needed.
// ============================================================================
extern "C" bool OSCARMAX_ECAT_SdoRtDiag_Read(
    void* output,
    uint32_t outputBytes);

namespace
{
    struct OSCARMAX_ECAT_SdoRtDiagSnapshot_P50
    {
        volatile LONG Sequence = 0;

        uint32_t StructSize = 0u;
        uint32_t Version = 0u;

        uint32_t Active = 0u;
        uint32_t Phase = 0u;

        int32_t LastTerminalResult = 0;
        uint32_t LastFailureReason = 0u;
        int32_t LastTransportResult = 0;
        uint32_t LastAbortCode = 0u;

        int32_t LastCommandType = 0;
        uint32_t LastSlave = 0u;
        uint32_t LastIndex = 0u;
        uint32_t LastSubIndex = 0u;
        uint32_t LastDataSize = 0u;

        uint64_t LastOperationDurationUs = 0ULL;
        uint64_t MaxOperationDurationUs = 0ULL;

        uint64_t OperationsStarted = 0ULL;
        uint64_t OperationsCompleted = 0ULL;
        uint64_t OperationsFailed = 0ULL;
        uint64_t OperationTimeouts = 0ULL;
        uint64_t InvalidStartCount = 0ULL;
        uint64_t SlotMismatchCount = 0ULL;

        uint64_t SendAttempts = 0ULL;
        uint64_t SendSuccess = 0ULL;
        uint64_t SendWkcZero = 0ULL;
        uint64_t SendDeadlineMiss = 0ULL;
        uint64_t SendTransportFailure = 0ULL;

        uint64_t PollAttempts = 0ULL;
        uint64_t PollWkcPositive = 0ULL;
        uint64_t PollWkcZero = 0ULL;
        uint64_t PollDeadlineMiss = 0ULL;
        uint64_t PollTransportFailure = 0ULL;
        uint64_t PollNotReady = 0ULL;
        uint64_t ResponseMismatchCount = 0ULL;
        uint64_t InvalidResponseCount = 0ULL;

        uint64_t StepsExecuted = 0ULL;
        uint64_t StepsDeferredPdo = 0ULL;
        uint64_t StepsDeferredBudget = 0ULL;
        uint64_t TransportDeadlineMisses = 0ULL;
        uint64_t AbortCount = 0ULL;

        uint64_t StepCostLastNs = 0ULL;
        uint64_t StepCostMaxNs = 0ULL;
        uint64_t StepCostAverageNs = 0ULL;
    };

    static_assert(
        sizeof(OSCARMAX_ECAT_SdoRtDiagSnapshot_P50) == 288,
        "SDO RT diagnostic mirror ABI mismatch.");

    uint16_t EcatServiceDiagClampU16(uint64_t value)
    {
        return (value > 0xFFFFULL)
            ? static_cast<uint16_t>(0xFFFFu)
            : static_cast<uint16_t>(value);
    }

    uint8_t EcatServiceDiagClampSignedI8(int32_t value)
    {
        if (value < -128)
        {
            value = -128;
        }
        else if (value > 127)
        {
            value = 127;
        }

        return static_cast<uint8_t>(static_cast<int8_t>(value));
    }

    OSCARMAX_DIAG_NOINLINE void PublishEtherCatSdoRtDiagnostics()
    {
        SHM_ECAT_ServiceData* service =
            GetEtherCatServiceSharedMemoryData();

        if (service == nullptr)
        {
            return;
        }

        OSCARMAX_ECAT_SdoRtDiagSnapshot_P50 diag = {};

        if (!OSCARMAX_ECAT_SdoRtDiag_Read(
            &diag,
            static_cast<uint32_t>(sizeof(diag))))
        {
            // Read collision is benign. Keep the previous published compact
            // diagnostics and try again on the next 100 ms scheduled pass.
            return;
        }

        // HeaderReserved[0] compact status word:
        //   bits  0..7   LastFailureReason
        //   bits  8..15  Phase
        //   bit      16   Active
        //   bits 17..18  Terminal: 0=None, 1=Success, 2=Error
        //   bits 24..31  LastTransportResult as saturated signed int8
        uint32_t terminalCode = 0u;
        if (diag.LastTerminalResult > 0)
        {
            terminalCode = 1u;
        }
        else if (diag.LastTerminalResult < 0)
        {
            terminalCode = 2u;
        }

        const uint32_t statusWord =
            (diag.LastFailureReason & 0xFFu) |
            ((diag.Phase & 0xFFu) << 8) |
            ((diag.Active != 0u ? 1u : 0u) << 16) |
            ((terminalCode & 0x3u) << 17) |
            (static_cast<uint32_t>(
                EcatServiceDiagClampSignedI8(diag.LastTransportResult)) << 24);

        // HeaderReserved[1]:
        //   low16  = SEND deadline misses
        //   high16 = POLL deadline misses
        const uint32_t deadlineWord =
            static_cast<uint32_t>(
                EcatServiceDiagClampU16(diag.SendDeadlineMiss)) |
            (static_cast<uint32_t>(
                EcatServiceDiagClampU16(diag.PollDeadlineMiss)) << 16);

        // HeaderReserved[2]:
        //   low16  = SEND WKC==0
        //   high16 = POLL WKC==0
        const uint32_t wkcZeroWord =
            static_cast<uint32_t>(
                EcatServiceDiagClampU16(diag.SendWkcZero)) |
            (static_cast<uint32_t>(
                EcatServiceDiagClampU16(diag.PollWkcZero)) << 16);

        // ResponseReserved:
        //   low16  = mailbox POLL NOT READY count (normal wait state)
        //   high16 = maximum bounded mailbox-step cost in microseconds
        const uint64_t stepMaxUs64 =
            (diag.StepCostMaxNs + 999ULL) / 1000ULL;

        const uint32_t responseDiagWord =
            static_cast<uint32_t>(
                EcatServiceDiagClampU16(diag.PollNotReady)) |
            (static_cast<uint32_t>(
                EcatServiceDiagClampU16(stepMaxUs64)) << 16);

        service->HeaderReserved[0] = statusWord;
        service->HeaderReserved[1] = deadlineWord;
        service->HeaderReserved[2] = wkcZeroWord;
        service->ResponseReserved = responseDiagWord;
    }
}

namespace
{
    // Stage 12F.3D.2 R1 - bridge-local Safe SDO Write contract tokens.
    //
    // These values intentionally mirror the v1.1 service contract reserved-field
    // semantics. Keeping the bridge gate self-contained prevents a stale
    // SHM_Types.h from silently disabling the safety check, while the shared
    // memory ABI itself remains unchanged at 128 bytes.
    static constexpr uint32_t kEcatServiceExpertWriteFlag = 0x00000001u;
    static constexpr uint32_t kEcatServiceWriteConfirmMagic = 0x574F4453u; // "SDOW"

    uint32_t EcatDiagClampCounter(
        LONGLONG value)
    {
        if (value <= 0)
        {
            return 0u;
        }

        if ((ULONGLONG)value > 0xFFFFFFFFULL)
        {
            return 0xFFFFFFFFu;
        }

        return static_cast<uint32_t>(value);
    }

    uint16_t EcatDiagClampU16(
        uint32_t value)
    {
        return (value > 0xFFFFu)
            ? 0xFFFFu
            : static_cast<uint16_t>(value);
    }

    void EcatDiagCopyName(
        char* destination,
        size_t destinationSize,
        const char* source)
    {
        if (destination == nullptr || destinationSize == 0)
        {
            return;
        }

        std::memset(destination, 0, destinationSize);

        if (source == nullptr)
        {
            return;
        }

        size_t length = std::strlen(source);

        if (length >= destinationSize)
        {
            length = destinationSize - 1;
        }

        if (length > 0)
        {
            std::memcpy(destination, source, length);
        }
    }

    uint16_t EcatDiagInferMasterState(
        const EtherCatRuntimeSnapshot& runtime)
    {
        // The diagnostic SHM is created after ENTER_OP in the EDM lifecycle.
        // Stages below therefore mean the broadcast OP transition passed.
        switch (runtime.stage)
        {
        case EtherCatRuntimeStage::LinkMotion:
        case EtherCatRuntimeStage::InitSharedMemory:
        case EtherCatRuntimeStage::Running:
        case EtherCatRuntimeStage::Stopping:
        case EtherCatRuntimeStage::Stopped:
            return 0x0008u; // OP, lifecycle-inferred

        default:
            return 0u;
        }
    }

    OSCARMAX_DIAG_NOINLINE void PublishEtherCatDiagHealth(
        EtherCatMaster* masterCore)
    {
        if (masterCore == nullptr)
        {
            return;
        }

        SHM_ECAT_DiagData* diag =
            GetEtherCatDiagSharedMemoryData();

        if (diag == nullptr)
        {
            return;
        }

        // -----------------------------------------------------------------
        // Stage 12B.1B owner-safe RT shadow read.
        // -----------------------------------------------------------------
        // Static local storage avoids per-call allocation and keeps the
        // 4096-byte temporary outside the supervisory thread's stack frame.
        // There is only one caller/writer on the Priority-50 loop.
        static uint8_t rtProcessImage[SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY];

        uint32_t rtImageBytes = 0u;
        uint32_t rtImageValid = 0u;
        int32_t rtLrwWkc = 0;
        int32_t rtDcWkc = 0;
        uint64_t rtSourcePdoTick = 0u;
        uint64_t rtLastValidPdoTick = 0u;
        uint64_t rtCaptureAttempts = 0u;
        uint64_t rtValidSnapshots = 0u;
        uint64_t rtInvalidSkips = 0u;
        uint64_t rtLastCostNs = 0u;
        uint64_t rtMaxCostNs = 0u;
        uint64_t rtAverageCostNs = 0u;

        const bool rtShadowRead =
            OSCARMAX_ECAT_DiagRtShadow_Read(
                rtProcessImage,
                SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY,
                &rtImageBytes,
                &rtImageValid,
                &rtLrwWkc,
                &rtDcWkc,
                &rtSourcePdoTick,
                &rtLastValidPdoTick,
                &rtCaptureAttempts,
                &rtValidSnapshots,
                &rtInvalidSkips,
                &rtLastCostNs,
                &rtMaxCostNs,
                &rtAverageCostNs);

        static uint64_t rtShadowReadSuccess = 0u;
        static uint64_t rtShadowReadMiss = 0u;

        if (rtShadowRead)
        {
            rtShadowReadSuccess++;
        }
        else
        {
            // A miss is expected if the 100 Hz PDO capture overlaps this
            // 10 Hz supervisory read. Keep last published bytes; never spin.
            rtShadowReadMiss++;
        }

        SHM_ECAT_DiagMasterStatus& status =
            diag->Master;

        const EtherCatStartupSnapshot startup =
            masterCore->GetStartupSnapshot();

        const EtherCatRuntimeSnapshot runtime =
            masterCore->GetRuntimeSnapshot();

        const auto* runtimeSlaves =
            (masterCore->m_pEni != nullptr)
            ? &masterCore->m_pEni->GetSlaves()
            : nullptr;

        uint32_t slaveCount = 0u;

        if (runtimeSlaves != nullptr)
        {
            slaveCount =
                static_cast<uint32_t>(
                    runtimeSlaves->size());
        }

        if (slaveCount > SHM_ECAT_DIAG_MAX_SLAVES)
        {
            slaveCount = SHM_ECAT_DIAG_MAX_SLAVES;
        }

        static SHM_ECAT_DiagData* lastDiag = nullptr;
        static uint32_t lastSlaveCount = 0xFFFFFFFFu;
        static bool publisherPrinted = false;

        const bool refreshStaticMetadata =
            diag != lastDiag ||
            slaveCount != lastSlaveCount;

        // -----------------------------------------------------------------
        // Shared-memory seqlock: odd = writing.
        // One writer only: this Priority-50 function.
        // -----------------------------------------------------------------
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &status.Sequence));

        MemoryBarrier();

        status.Magic = SHM_ECAT_DIAG_MAGIC;
        status.VersionMajor = SHM_ECAT_DIAG_VERSION_MAJOR;
        status.VersionMinor = SHM_ECAT_DIAG_VERSION_MINOR;
        status.StructSize = static_cast<uint32_t>(sizeof(SHM_ECAT_DiagData));
        status.ProcessImageCapacity = SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY;

        status.Heartbeat++;
        status.PublishCount++;

        // Current Master runtime is fixed at 250 us.
        status.CycleTimeNs = 250000u;

        // Process Image bytes/value are accepted ONLY from the owner-safe RT
        // shadow. On a transient reader miss the previously published image
        // remains intact and valid/invalid state is preserved.
        if (rtShadowRead)
        {
            const uint32_t previousBytes = status.ProcessImageBytes;

            status.ProcessImageBytes = rtImageBytes;
            status.ProcessImageValid =
                (rtImageValid != 0u && rtImageBytes > 0u)
                ? 1u
                : 0u;

            if (rtImageBytes > 0u)
            {
                std::memcpy(
                    diag->ProcessImage,
                    rtProcessImage,
                    rtImageBytes);
            }

            // Defensive cleanup if a future runtime is reconfigured to a
            // smaller image while the SHM mapping stays alive.
            if (previousBytes > rtImageBytes &&
                previousBytes <= SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY)
            {
                std::memset(
                    diag->ProcessImage + rtImageBytes,
                    0,
                    previousBytes - rtImageBytes);
            }
        }
        else if (status.ProcessImageBytes == 0u && masterCore->m_IoMapSize > 0)
        {
            // Size metadata only; no Process Image bytes are read here.
            uint32_t configuredBytes =
                static_cast<uint32_t>(masterCore->m_IoMapSize);

            if (configuredBytes > SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY)
            {
                configuredBytes = SHM_ECAT_DIAG_PROCESS_IMAGE_CAPACITY;
            }

            status.ProcessImageBytes = configuredBytes;
            status.ProcessImageValid = 0u;
        }

        status.SlaveCount = static_cast<uint16_t>(slaveCount);
        status.MasterState = EcatDiagInferMasterState(runtime);
        status.RuntimeStage = static_cast<uint16_t>(static_cast<LONG>(runtime.stage));
        status.RuntimeErrorCode =
            static_cast<uint16_t>(
                static_cast<uint32_t>(runtime.errorCode) & 0xFFFFu);

        status.ExpectedWkc = masterCore->TotalSlave_WKC_Count;

        // Prefer the same-cycle WKC values bundled with the RT Process Image.
        // If the lower-priority copy overlapped the RT writer, use the existing
        // stable PDO diagnostic scalars for this health publish only.
        if (rtShadowRead)
        {
            status.ActualLrwWkc = rtLrwWkc;
            status.DcWkc = rtDcWkc;
        }
        else
        {
            status.ActualLrwWkc = static_cast<int32_t>(g_pdoRtLrwWkc);
            status.DcWkc = static_cast<int32_t>(g_pdoRtDcWkc);
        }

        status.RxRecentTimeout =
            (g_ecatRxDiagHardTimeout > 0)
            ? static_cast<uint32_t>(g_ecatRxDiagHardTimeout)
            : 0u;

        status.RxTotalHardTimeout =
            EcatDiagClampCounter(g_ecatRxDiagTotalHardTimeout);

        status.RxConsecutiveTimeout =
            (g_ecatRxDiagCurrentConsecutiveTimeout > 0)
            ? static_cast<uint32_t>(g_ecatRxDiagCurrentConsecutiveTimeout)
            : 0u;

        status.RxRecoveryCount =
            (g_ecatRxDiagRecoveryAfterTimeout > 0)
            ? static_cast<uint32_t>(g_ecatRxDiagRecoveryAfterTimeout)
            : 0u;

        status.RxSkipCount =
            (g_pdoRuntimeRecoveryWindowSkippedCycles > 0)
            ? static_cast<uint32_t>(g_pdoRuntimeRecoveryWindowSkippedCycles)
            : 0u;

        status.RxSoftLateCount =
            EcatDiagClampCounter(g_ecatRxDiagTotalSoftLateAccepted);

        status.QpcFailCount =
            (g_ecatRxDiagQpcFail > 0)
            ? static_cast<uint32_t>(g_ecatRxDiagQpcFail)
            : 0u;

        status.DcPhaseErrorNs =
            static_cast<int64_t>(g_qpcPhasePActV0ActualErrNs);

        status.DcDriftState =
            static_cast<int32_t>(g_qpcPhasePActV0RealFfState);

        status.DcRealFfState =
            static_cast<int32_t>(g_qpcRealFfV0State);

        status.DcPhasePState =
            static_cast<int32_t>(g_qpcPhasePActV0State);

        const int dcReferenceSlave =
            GetDcReferenceSlaveIndex();

        if (dcReferenceSlave >= 0 &&
            dcReferenceSlave < static_cast<int>(slaveCount))
        {
            status.DcReferenceSlave =
                static_cast<uint16_t>(dcReferenceSlave);

            status.DcReferenceConfigAddr =
                m_slaveInfo[dcReferenceSlave].configAddr;
        }
        else
        {
            status.DcReferenceSlave = 0xFFFFu;
            status.DcReferenceConfigAddr = 0u;
        }

        const bool startupReady =
            startup.stage == EtherCatStartupStage::Ready &&
            startup.result == EtherCatStartupResult::Pass;

        const bool runtimeRunning =
            runtime.stage == EtherCatRuntimeStage::Running &&
            runtime.result == EtherCatRuntimeResult::Pass;

        const bool lrwHealthy =
            status.ExpectedWkc > 0 &&
            status.ActualLrwWkc == status.ExpectedWkc;

        const bool rxHealthy =
            g_ecatRxDiagCurrentConsecutiveTimeout == 0 &&
            g_ecatRxDiagHardTimeout == 0;

        const bool hasDcReference =
            dcReferenceSlave >= 0;

        const bool phaseGood =
            !hasDcReference || g_qpcRealFfV0PhaseGood != 0;

        const bool phaseGate =
            !hasDcReference || g_qpcPhasePActV0GateGood != 0;

        const bool offsetSat =
            hasDcReference && g_qpcPhasePActV0OffsetSat != 0;

        const bool dcHealthy =
            !hasDcReference ||
            (phaseGood &&
                phaseGate &&
                !offsetSat &&
                g_qpcRealFfV0TripMask == 0);

        status.MasterReady = startupReady ? 1u : 0u;
        status.RuntimeRunning = runtimeRunning ? 1u : 0u;
        status.LrwHealthy = lrwHealthy ? 1u : 0u;
        status.RxHealthy = rxHealthy ? 1u : 0u;
        status.DcHealthy = dcHealthy ? 1u : 0u;
        status.DcPhaseGood = phaseGood ? 1u : 0u;
        status.DcGateOpen = phaseGate ? 1u : 0u;
        status.DcOffsetSaturated = offsetSat ? 1u : 0u;
        status.DcTripMask = static_cast<uint8_t>(g_qpcRealFfV0TripMask & 0xFF);

        // =================================================================
        // Stage 17A.3A - DC Trip Forensics compact bridge
        //
        // Source fingerprint:
        //   OSCARMAX_DC_MAD_QUALIFICATION_RECORDER_17A3C_FIX1_DEDUP_20260828
        //
        // IMPORTANT:
        //   - DIAGNOSTIC ONLY.
        //   - Priority-50 publisher only.
        //   - No EtherCAT frame / SDO / PDO write.
        //   - No control parameter or state-machine behavior is changed.
        //   - SHM_ECAT_DiagMasterStatus size is unchanged.
        //
        // Existing Reserved8[20] is used as a compact ABI-safe payload:
        //
        //   [0]  0xD3 marker
        //   [1]  version = 1
        //   [2]  Frequency FF V2 state
        //   [3]  flags:
        //          bit0 CandidateGood
        //          bit1 ObserverLocked
        //          bit2 PointAccepted
        //          bit3 RealFF ClampActive
        //          bit4 V2 snapshot coherent
        //          bit5 RealFF snapshot coherent
        //          bit6 Drift baseline snapshot coherent + locked
        //   [4]  V2 BadCount
        //   [5]  V2 RecoveryGoodCount
        //   [6]  V2 Points
        //   [7]  V2 Pairs
        //   [8]  RealFF HoldGood
        //   [9]  RealFF HoldBad
        //   [10] RealFF current PhaseRejectMask
        //   [11] RealFF last PhaseRejectMask
        //   [12..13] V2 RecommendedPpb, signed int16 LE
        //   [14..15] RealFF AppliedPpb, signed int16 LE
        //   [16..17] V2 SlopeMadPpb, signed int16 LE
        //   [18..19] startup Drift BaselinePpb, signed int16 LE
        //
        // RealFF PhaseRejectMask semantics in the current controller:
        //   0x01 V2 state != TRACK
        //   0x02 CandidateGood == 0
        //   0x04 ObserverLocked == 0
        //   0x08 PointAccepted == 0
        //   0x10 Points != 16
        //   0x20 Pairs != 120
        //   0x40 Slope MAD > 150 ppb
        //   0x80 Drift Baseline not locked
        // =================================================================

        auto clampForensicU8 = [](LONG value) -> uint8_t
        {
            if (value <= 0)
            {
                return 0u;
            }

            if (value >= 255)
            {
                return 255u;
            }

            return static_cast<uint8_t>(value);
        };

        auto clampForensicI16 = [](LONGLONG value) -> int16_t
        {
            if (value < -32768LL)
            {
                return static_cast<int16_t>(-32768);
            }

            if (value > 32767LL)
            {
                return static_cast<int16_t>(32767);
            }

            return static_cast<int16_t>(value);
        };

        auto storeForensicI16Le =
            [](uint8_t* target, int16_t value)
        {
            const uint16_t bits =
                static_cast<uint16_t>(value);

            target[0] =
                static_cast<uint8_t>(
                    bits &
                    0xFFu);

            target[1] =
                static_cast<uint8_t>(
                    (bits >>
                        8) &
                    0xFFu);
        };


        LONG forensicV2State = 0;
        LONG forensicV2CandidateGood = 0;
        LONG forensicV2BadCount = 0;
        LONG forensicV2RecoveryGood = 0;
        LONG forensicV2Points = 0;
        LONG forensicV2Pairs = 0;
        LONG forensicV2ObserverLocked = 0;
        LONG forensicV2PointAccepted = 0;
        LONGLONG forensicV2RecommendedPpb = 0;
        LONGLONG forensicV2SlopeMadPpb = 0;
        LONG forensicV2SnapshotSequence = 0;
        bool forensicV2Valid = false;


        for (int attempt = 0;
            attempt < 3 && !forensicV2Valid;
            ++attempt)
        {
            const LONG seq1 =
                g_qpcPhaseFfV2DiagSequence;

            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }

            MemoryBarrier();

            forensicV2State =
                g_qpcPhaseFfV2State;

            forensicV2CandidateGood =
                g_qpcPhaseFfV2CandidateGood;

            forensicV2BadCount =
                g_qpcPhaseFfV2BadCount;

            forensicV2RecoveryGood =
                g_qpcPhaseFfV2RecoveryGoodCount;

            forensicV2Points =
                g_qpcPhaseFfV2Points;

            forensicV2Pairs =
                g_qpcPhaseFfV2Pairs;

            forensicV2ObserverLocked =
                g_qpcPhaseFfV2ObserverLocked;

            forensicV2PointAccepted =
                g_qpcPhaseFfV2PointAccepted;

            forensicV2RecommendedPpb =
                g_qpcPhaseFfV2RecommendedPpb;

            forensicV2SlopeMadPpb =
                g_qpcPhaseFfV2SlopeMadPpb;

            MemoryBarrier();

            const LONG seq2 =
                g_qpcPhaseFfV2DiagSequence;

            forensicV2Valid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;


            if (forensicV2Valid)
            {
                forensicV2SnapshotSequence =
                    seq2;
            }
        }


        LONG forensicRealHoldGood = 0;
        LONG forensicRealHoldBad = 0;
        LONG forensicRealRejectMask = 0;
        LONG forensicRealLastRejectMask = 0;
        LONG forensicRealClampActive = 0;
        LONGLONG forensicRealAppliedPpb = 0;
        bool forensicRealValid = false;


        for (int attempt = 0;
            attempt < 3 && !forensicRealValid;
            ++attempt)
        {
            const LONG seq1 =
                g_qpcRealFfV0Seq;

            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }

            MemoryBarrier();

            forensicRealHoldGood =
                g_qpcRealFfV0HoldGood;

            forensicRealHoldBad =
                g_qpcRealFfV0HoldBad;

            forensicRealRejectMask =
                g_qpcRealFfV0PhaseRejectMask;

            forensicRealLastRejectMask =
                g_qpcRealFfV0LastPhaseRejectMask;

            forensicRealClampActive =
                g_qpcRealFfV0ClampActive;

            forensicRealAppliedPpb =
                g_qpcRealFfV0AppliedPpb;

            MemoryBarrier();

            const LONG seq2 =
                g_qpcRealFfV0Seq;

            forensicRealValid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;
        }


        LONGLONG forensicBaselinePpb = 0;
        LONG forensicBaselineState = 0;
        bool forensicBaselineValid = false;


        for (int attempt = 0;
            attempt < 3 && !forensicBaselineValid;
            ++attempt)
        {
            const LONG seq1 =
                g_dcDriftCalibrationDiagSequence;

            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }

            MemoryBarrier();

            forensicBaselinePpb =
                g_dcDriftCalibrationBaselinePpb;

            forensicBaselineState =
                g_dcDriftCalibrationState;

            MemoryBarrier();

            const LONG seq2 =
                g_dcDriftCalibrationDiagSequence;

            forensicBaselineValid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;
        }


        // =================================================================
        // Stage 17A.3B - Sticky DC incident latch (P50 diagnostic only)
        //
        // Why:
        //   Current/Last reject masks can return to 0 after a transient DC
        //   qualification failure recovers. The evidence then disappears
        //   before Windows can export the Diagnostic Package.
        //
        // Behavior:
        //   1. Arm only after 500 ms of healthy TRACK operation.
        //   2. Detect incident edges at the existing ~10 ms P50 cadence.
        //   3. Preserve first incident snapshot + reject OR + latest reject.
        //   4. Never changes any DC controller state or tuning value.
        //   5. Sticky data resets naturally when the RTOS process / SHM mapping
        //      is restarted. There is intentionally no control command here.
        //
        // ABI:
        //   No structure change. High/unused bits of existing Reserved32
        //   diagnostic words are packed while their existing low-bit semantics
        //   remain intact.
        //
        // Reserved32[10]:
        //   bit0      existing RtShadowReadOk
        //   bits1..7  incident count (0..127)
        //   bits8..15 first non-zero reject mask
        //   bits16..23 latest non-zero reject mask
        //   bits24..31 reject OR across all incidents
        //
        // Reserved32[11]:
        //   bit0      existing RtImageValid
        //   bits1..2  first-incident V2 state
        //   bit3      first CandidateGood
        //   bit4      first ObserverLocked
        //   bit5      first PointAccepted
        //   bit6      first BaselineLocked
        //   bit7      latch ARMED
        //   bits8..15 trip-mask OR across all incidents
        //   bits16..31 first Recommended-Baseline delta (signed int16)
        //
        // Reserved32[14] high byte:
        //   first-incident Slope MAD, saturated to 255 ppb.
        //
        // Existing low 24 bits of Reserved32[14] keep the ESC valid counts.
        // =================================================================

        static bool forensicLatchArmed = false;
        static uint32_t forensicLatchArmGoodCount = 0u;
        static bool forensicIncidentActive = false;
        static uint8_t forensicIncidentCount = 0u;

        static uint8_t forensicFirstRejectMask = 0u;
        static uint8_t forensicLatestRejectMask = 0u;
        static uint8_t forensicRejectMaskOr = 0u;
        static uint8_t forensicTripMaskOr = 0u;

        static uint8_t forensicFirstV2State = 0u;
        static bool forensicFirstCandidateGood = false;
        static bool forensicFirstObserverLocked = false;
        static bool forensicFirstPointAccepted = false;
        static bool forensicFirstBaselineLocked = false;

        static int16_t forensicFirstRecommendedDeltaPpb = 0;
        static uint8_t forensicFirstSlopeMadPpb = 0u;


        const bool forensicNewMapping =
            diag != lastDiag;


        if (forensicNewMapping)
        {
            forensicLatchArmed = false;
            forensicLatchArmGoodCount = 0u;
            forensicIncidentActive = false;
            forensicIncidentCount = 0u;

            forensicFirstRejectMask = 0u;
            forensicLatestRejectMask = 0u;
            forensicRejectMaskOr = 0u;
            forensicTripMaskOr = 0u;

            forensicFirstV2State = 0u;
            forensicFirstCandidateGood = false;
            forensicFirstObserverLocked = false;
            forensicFirstPointAccepted = false;
            forensicFirstBaselineLocked = false;

            forensicFirstRecommendedDeltaPpb = 0;
            forensicFirstSlopeMadPpb = 0u;
        }


        const bool forensicHealthyTrack =
            forensicV2Valid &&
            forensicRealValid &&
            forensicBaselineValid &&
            forensicV2State == 1 &&
            forensicV2CandidateGood != 0 &&
            forensicV2ObserverLocked != 0 &&
            forensicV2PointAccepted != 0 &&
            forensicV2Points == 16 &&
            forensicV2Pairs == 120 &&
            forensicRealRejectMask == 0 &&
            status.DcTripMask == 0u &&
            status.DcHealthy != 0u &&
            status.DcPhaseGood != 0u &&
            status.DcGateOpen != 0u;


        if (!forensicLatchArmed)
        {
            if (forensicHealthyTrack)
            {
                if (forensicLatchArmGoodCount < 50u)
                {
                    ++forensicLatchArmGoodCount;
                }

                if (forensicLatchArmGoodCount >= 50u)
                {
                    forensicLatchArmed = true;
                }
            }
            else
            {
                forensicLatchArmGoodCount = 0u;
            }
        }


        const bool forensicQualificationIncident =
            forensicLatchArmed &&
            (
                !forensicV2Valid ||
                !forensicRealValid ||
                forensicV2State != 1 ||
                forensicV2CandidateGood == 0 ||
                forensicV2ObserverLocked == 0 ||
                forensicV2PointAccepted == 0 ||
                forensicV2Points != 16 ||
                forensicV2Pairs != 120 ||
                forensicV2SlopeMadPpb > 150 ||
                forensicRealRejectMask != 0 ||
                status.DcTripMask != 0u ||
                status.DcHealthy == 0u ||
                status.DcPhaseGood == 0u ||
                status.DcGateOpen == 0u
                );


        if (forensicQualificationIncident)
        {
            if (!forensicIncidentActive)
            {
                forensicIncidentActive = true;

                if (forensicIncidentCount < 127u)
                {
                    ++forensicIncidentCount;
                }


                // Capture the first incident snapshot once per RTOS mapping.
                if (forensicIncidentCount == 1u)
                {
                    forensicFirstV2State =
                        static_cast<uint8_t>(
                            forensicV2State &
                            0x03);

                    forensicFirstCandidateGood =
                        forensicV2CandidateGood != 0;

                    forensicFirstObserverLocked =
                        forensicV2ObserverLocked != 0;

                    forensicFirstPointAccepted =
                        forensicV2PointAccepted != 0;

                    forensicFirstBaselineLocked =
                        forensicBaselineValid &&
                        forensicBaselineState != 0;


                    const LONGLONG deltaPpb =
                        forensicV2RecommendedPpb -
                        forensicBaselinePpb;

                    forensicFirstRecommendedDeltaPpb =
                        clampForensicI16(
                            deltaPpb);


                    LONGLONG madPpb =
                        forensicV2SlopeMadPpb;

                    if (madPpb < 0)
                    {
                        madPpb = 0;
                    }

                    if (madPpb > 255)
                    {
                        madPpb = 255;
                    }

                    forensicFirstSlopeMadPpb =
                        static_cast<uint8_t>(
                            madPpb);
                }
            }


            const uint8_t currentReject =
                static_cast<uint8_t>(
                    forensicRealRejectMask &
                    0xFF);

            if (currentReject != 0u)
            {
                if (forensicFirstRejectMask == 0u)
                {
                    forensicFirstRejectMask =
                        currentReject;
                }

                forensicLatestRejectMask =
                    currentReject;

                forensicRejectMaskOr =
                    static_cast<uint8_t>(
                        forensicRejectMaskOr |
                        currentReject);
            }


            forensicTripMaskOr =
                static_cast<uint8_t>(
                    forensicTripMaskOr |
                    status.DcTripMask);
        }
        else
        {
            forensicIncidentActive = false;
        }


        // =================================================================
        // Stage 17A.3C.1 - MAD Qualification Recorder
        //
        // P50 diagnostic only.
        //
        // Ring entry criteria:
        //     MAD >= 120 ppb
        // OR  qualification / DC-chain abnormal.
        //
        // Existing controller threshold 150 ppb is NOT changed.
        // =================================================================

        SHM_ECAT_DcQualDiagData* dcQualDiag =
            GetEtherCatDcQualificationDiagSharedMemoryData();


        if (dcQualDiag != nullptr)
        {
            SHM_ECAT_DcQualDiagHeader& qualHeader =
                dcQualDiag->Header;

            SHM_ECAT_DcQualDiagSummary& qualSummary =
                dcQualDiag->Summary;


            InterlockedIncrement(
                reinterpret_cast<volatile LONG*>(
                    &qualHeader.Sequence));

            MemoryBarrier();


            qualHeader.Magic =
                SHM_ECAT_DC_QUAL_DIAG_MAGIC;

            qualHeader.VersionMajor =
                SHM_ECAT_DC_QUAL_DIAG_VERSION_MAJOR;

            qualHeader.VersionMinor =
                SHM_ECAT_DC_QUAL_DIAG_VERSION_MINOR;

            qualHeader.StructSize =
                static_cast<uint32_t>(
                    sizeof(SHM_ECAT_DcQualDiagData));

            qualHeader.Heartbeat++;
            qualHeader.PublishCount++;

            qualHeader.Capacity =
                SHM_ECAT_DC_QUAL_DIAG_CAPACITY;

            qualHeader.Reserved32[0] =
                static_cast<uint32_t>(
                    SHM_ECAT_DC_QUAL_DIAG_NEAR_MAD_PPB);

            qualHeader.Reserved32[1] =
                static_cast<uint32_t>(
                    SHM_ECAT_DC_QUAL_DIAG_BAD_MAD_PPB);


            static SHM_ECAT_DcQualDiagData*
                lastDcQualMapping =
                nullptr;

            static bool previousQualValid =
                false;

            static LONG previousQualSnapshotSequence =
                0;

            static int previousQualV2State =
                0;

            static bool previousQualCandidateGood =
                false;


            if (lastDcQualMapping != dcQualDiag)
            {
                lastDcQualMapping =
                    dcQualDiag;

                previousQualValid =
                    false;

                previousQualSnapshotSequence =
                    0;

                previousQualV2State =
                    0;

                previousQualCandidateGood =
                    false;
            }


            int32_t currentMadPpb =
                forensicV2Valid
                ? static_cast<int32_t>(
                    forensicV2SlopeMadPpb)
                : 0;


            if (currentMadPpb < 0)
            {
                currentMadPpb =
                    0;
            }


            qualSummary.Armed =
                forensicLatchArmed
                ? 1u
                : 0u;

            qualSummary.CurrentV2State =
                clampForensicU8(
                    forensicV2State);

            qualSummary.CurrentCandidateGood =
                forensicV2CandidateGood != 0
                ? 1u
                : 0u;

            qualSummary.CurrentRejectMask =
                static_cast<uint8_t>(
                    forensicRealRejectMask &
                    0xFF);

            qualSummary.CurrentObserverLocked =
                forensicV2ObserverLocked != 0
                ? 1u
                : 0u;

            qualSummary.CurrentPointAccepted =
                forensicV2PointAccepted != 0
                ? 1u
                : 0u;

            qualSummary.CurrentTripMask =
                status.DcTripMask;

            qualSummary.CurrentSlopeMadPpb =
                currentMadPpb;

            qualSummary.CurrentRecommendedPpb =
                forensicV2Valid
                ? static_cast<int32_t>(
                    clampForensicI16(
                        forensicV2RecommendedPpb))
                : 0;

            qualSummary.CurrentBaselinePpb =
                forensicBaselineValid
                ? static_cast<int32_t>(
                    clampForensicI16(
                        forensicBaselinePpb))
                : 0;

            qualSummary.CurrentRecommendedDeltaPpb =
                static_cast<int32_t>(
                    clampForensicI16(
                        forensicV2RecommendedPpb -
                        forensicBaselinePpb));


            const bool newV2QualificationSnapshot =
                forensicV2Valid &&
                forensicV2SnapshotSequence !=
                0 &&
                forensicV2SnapshotSequence !=
                previousQualSnapshotSequence;


            if (forensicLatchArmed &&
                newV2QualificationSnapshot)
            {
                const uint32_t madUnsigned =
                    static_cast<uint32_t>(
                        currentMadPpb);


                if (madUnsigned >
                    qualSummary.PeakMadPpb)
                {
                    qualSummary.PeakMadPpb =
                        madUnsigned;
                }


                const bool nearThreshold =
                    currentMadPpb >=
                    SHM_ECAT_DC_QUAL_DIAG_NEAR_MAD_PPB;

                const bool aboveThreshold =
                    currentMadPpb >
                    SHM_ECAT_DC_QUAL_DIAG_BAD_MAD_PPB;


                const bool qualificationAbnormal =
                    !forensicRealValid ||
                    forensicV2State != 1 ||
                    forensicV2CandidateGood == 0 ||
                    forensicV2ObserverLocked == 0 ||
                    forensicV2PointAccepted == 0 ||
                    forensicV2Points != 16 ||
                    forensicV2Pairs != 120 ||
                    forensicRealRejectMask != 0 ||
                    status.DcTripMask != 0u ||
                    status.DcHealthy == 0u ||
                    status.DcPhaseGood == 0u ||
                    status.DcGateOpen == 0u;


                if (nearThreshold &&
                    qualSummary.NearThresholdSamples <
                    0xFFFFFFFFu)
                {
                    ++qualSummary.NearThresholdSamples;
                }


                if (aboveThreshold)
                {
                    if (qualSummary.AboveThresholdSamples <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.AboveThresholdSamples;
                    }


                    if (qualSummary.FirstBadMadPpb == 0u)
                    {
                        qualSummary.FirstBadMadPpb =
                            madUnsigned;
                    }


                    if (madUnsigned >
                        qualSummary.WorstBadMadPpb)
                    {
                        qualSummary.WorstBadMadPpb =
                            madUnsigned;
                    }


                    if (qualSummary.CurrentBadStreak <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.CurrentBadStreak;
                    }


                    if (qualSummary.CurrentBadStreak >
                        qualSummary.LongestBadStreak)
                    {
                        qualSummary.LongestBadStreak =
                            qualSummary.CurrentBadStreak;
                    }
                }
                else
                {
                    qualSummary.CurrentBadStreak =
                        0u;
                }


                if (previousQualValid)
                {
                    if (previousQualCandidateGood &&
                        forensicV2CandidateGood == 0 &&
                        qualSummary.CandidateBadTransitions <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.CandidateBadTransitions;
                    }


                    if (previousQualV2State == 1 &&
                        forensicV2State == 2 &&
                        qualSummary.TrackToHoldCount <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.TrackToHoldCount;
                    }


                    if (previousQualV2State == 2 &&
                        forensicV2State == 1 &&
                        qualSummary.HoldToTrackCount <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.HoldToTrackCount;
                    }


                    if (previousQualV2State == 2 &&
                        forensicV2State == 3 &&
                        qualSummary.HoldToFallbackCount <
                        0xFFFFFFFFu)
                    {
                        ++qualSummary.HoldToFallbackCount;
                    }
                }


                qualSummary.RejectMaskOr |=
                    static_cast<uint32_t>(
                        forensicRealRejectMask &
                        0xFF);


                if (nearThreshold ||
                    qualificationAbnormal)
                {
                    const uint32_t slot =
                        qualHeader.WriteIndex %
                        SHM_ECAT_DC_QUAL_DIAG_CAPACITY;


                    SHM_ECAT_DcQualDiagEntry& entry =
                        dcQualDiag->Entries[slot];


                    std::memset(
                        &entry,
                        0,
                        sizeof(entry));


                    // Stage 17A.3C-FIX1:
                    // Use one publisher-count domain for both RTX and
                    // Windows. Do not subtract RTX/Windows GetTickCount64.
                    //
                    // CaptureTickMs keeps its ABI slot but now carries the
                    // qualification P50 publish ordinal.
                    entry.CaptureTickMs =
                        qualHeader.PublishCount;

                    entry.SampleOrdinal =
                        static_cast<uint32_t>(
                            qualHeader.PublishCount &
                            0xFFFFFFFFULL);

                    entry.SlopeMadPpb =
                        currentMadPpb;

                    entry.RecommendedPpb =
                        clampForensicI16(
                            forensicV2RecommendedPpb);

                    entry.RecommendedDeltaPpb =
                        clampForensicI16(
                            forensicV2RecommendedPpb -
                            forensicBaselinePpb);


                    LONGLONG phaseErrorNs =
                        status.DcPhaseErrorNs;


                    if (phaseErrorNs <
                        -2147483648LL)
                    {
                        phaseErrorNs =
                            -2147483648LL;
                    }
                    else if (phaseErrorNs >
                        2147483647LL)
                    {
                        phaseErrorNs =
                            2147483647LL;
                    }


                    entry.PhaseErrorNs =
                        static_cast<int32_t>(
                            phaseErrorNs);

                    entry.V2State =
                        clampForensicU8(
                            forensicV2State);


                    uint8_t entryFlags =
                        0u;

                    if (forensicV2CandidateGood != 0)
                        entryFlags |= 0x01u;

                    if (forensicV2ObserverLocked != 0)
                        entryFlags |= 0x02u;

                    if (forensicV2PointAccepted != 0)
                        entryFlags |= 0x04u;

                    if (forensicBaselineValid &&
                        forensicBaselineState != 0)
                    {
                        entryFlags |= 0x08u;
                    }


                    entry.Flags =
                        entryFlags;

                    entry.RejectMask =
                        static_cast<uint8_t>(
                            forensicRealRejectMask &
                            0xFF);

                    entry.TripMask =
                        status.DcTripMask;

                    entry.RealFfState =
                        clampForensicU8(
                            status.DcRealFfState);

                    entry.PhasePState =
                        clampForensicU8(
                            status.DcPhasePState);


                    uint8_t eventFlags =
                        0u;

                    if (nearThreshold)
                        eventFlags |= 0x01u;

                    if (aboveThreshold)
                        eventFlags |= 0x02u;

                    if (qualificationAbnormal)
                        eventFlags |= 0x04u;


                    entry.EventFlags =
                        eventFlags;


                    ++qualHeader.WriteIndex;


                    if (qualHeader.EntryCount <
                        SHM_ECAT_DC_QUAL_DIAG_CAPACITY)
                    {
                        ++qualHeader.EntryCount;
                    }
                }


                previousQualSnapshotSequence =
                    forensicV2SnapshotSequence;

                previousQualV2State =
                    static_cast<int>(
                        forensicV2State);

                previousQualCandidateGood =
                    forensicV2CandidateGood != 0;

                previousQualValid =
                    true;
            }


            MemoryBarrier();


            InterlockedIncrement(
                reinterpret_cast<volatile LONG*>(
                    &qualHeader.Sequence));
        }


        std::memset(
            status.Reserved8,
            0,
            sizeof(status.Reserved8));

        status.Reserved8[0] =
            0xD3u;

        status.Reserved8[1] =
            2u;

        status.Reserved8[2] =
            clampForensicU8(
                forensicV2State);


        uint8_t forensicFlags =
            0u;

        if (forensicV2CandidateGood != 0)
            forensicFlags |= 0x01u;

        if (forensicV2ObserverLocked != 0)
            forensicFlags |= 0x02u;

        if (forensicV2PointAccepted != 0)
            forensicFlags |= 0x04u;

        if (forensicRealClampActive != 0)
            forensicFlags |= 0x08u;

        if (forensicV2Valid)
            forensicFlags |= 0x10u;

        if (forensicRealValid)
            forensicFlags |= 0x20u;

        if (forensicBaselineValid &&
            forensicBaselineState != 0)
        {
            forensicFlags |= 0x40u;
        }


        status.Reserved8[3] =
            forensicFlags;

        status.Reserved8[4] =
            clampForensicU8(
                forensicV2BadCount);

        status.Reserved8[5] =
            clampForensicU8(
                forensicV2RecoveryGood);

        status.Reserved8[6] =
            clampForensicU8(
                forensicV2Points);

        status.Reserved8[7] =
            clampForensicU8(
                forensicV2Pairs);

        status.Reserved8[8] =
            clampForensicU8(
                forensicRealHoldGood);

        status.Reserved8[9] =
            clampForensicU8(
                forensicRealHoldBad);

        status.Reserved8[10] =
            static_cast<uint8_t>(
                forensicRealRejectMask &
                0xFF);

        status.Reserved8[11] =
            static_cast<uint8_t>(
                forensicRealLastRejectMask &
                0xFF);


        storeForensicI16Le(
            &status.Reserved8[12],
            clampForensicI16(
                forensicV2RecommendedPpb));

        storeForensicI16Le(
            &status.Reserved8[14],
            clampForensicI16(
                forensicRealAppliedPpb));

        storeForensicI16Le(
            &status.Reserved8[16],
            clampForensicI16(
                forensicV2SlopeMadPpb));

        storeForensicI16Le(
            &status.Reserved8[18],
            clampForensicI16(
                forensicBaselinePpb));

        // Exposed in a later stable release-snapshot accessor.
        status.UnifiedRcReady = 0u;
        status.UnifiedRcReleased = 0u;

        // -----------------------------------------------------------------
        // Stage 12B.1C RT snapshot performance counters.
        // Keep ABI v1.0 unchanged by using reserved words. Stage 12B.2 can
        // optionally expose these as an "RT Snapshot Cost" engineering card.
        // -----------------------------------------------------------------
        auto clampU64ToU32 = [](uint64_t value) -> uint32_t
        {
            return (value > 0xFFFFFFFFULL)
                ? 0xFFFFFFFFu
                : static_cast<uint32_t>(value);
        };

        status.Reserved32[0] = clampU64ToU32(rtShadowReadSuccess);
        status.Reserved32[1] = clampU64ToU32(rtShadowReadMiss);
        status.Reserved32[2] = clampU64ToU32(rtCaptureAttempts);
        status.Reserved32[3] = clampU64ToU32(rtValidSnapshots);
        status.Reserved32[4] = clampU64ToU32(rtInvalidSkips);
        status.Reserved32[5] = clampU64ToU32(rtLastCostNs);
        status.Reserved32[6] = clampU64ToU32(rtMaxCostNs);
        status.Reserved32[7] = clampU64ToU32(rtAverageCostNs);
        status.Reserved32[8] = static_cast<uint32_t>(rtSourcePdoTick & 0xFFFFFFFFULL);
        status.Reserved32[9] = static_cast<uint32_t>(rtLastValidPdoTick & 0xFFFFFFFFULL);
        // Stage 17A.3B packs sticky incident evidence into previously
        // unused high bits while preserving the legacy low-bit meanings.
        status.Reserved32[10] =
            (rtShadowRead ? 1u : 0u) |
            ((static_cast<uint32_t>(
                forensicIncidentCount) &
                0x7Fu) << 1) |
            (static_cast<uint32_t>(
                forensicFirstRejectMask) << 8) |
            (static_cast<uint32_t>(
                forensicLatestRejectMask) << 16) |
            (static_cast<uint32_t>(
                forensicRejectMaskOr) << 24);


        uint32_t forensicLatchWord11 =
            (rtImageValid != 0u ? 1u : 0u) |
            ((static_cast<uint32_t>(
                forensicFirstV2State) &
                0x03u) << 1) |
            (forensicFirstCandidateGood
                ? (1u << 3)
                : 0u) |
            (forensicFirstObserverLocked
                ? (1u << 4)
                : 0u) |
            (forensicFirstPointAccepted
                ? (1u << 5)
                : 0u) |
            (forensicFirstBaselineLocked
                ? (1u << 6)
                : 0u) |
            (forensicLatchArmed
                ? (1u << 7)
                : 0u) |
            (static_cast<uint32_t>(
                forensicTripMaskOr) << 8);


        forensicLatchWord11 |=
            static_cast<uint32_t>(
                static_cast<uint16_t>(
                    forensicFirstRecommendedDeltaPpb)) <<
            16;


        status.Reserved32[11] =
            forensicLatchWord11;

        if (refreshStaticMetadata && runtimeSlaves != nullptr)
        {
            for (uint32_t i = 0u; i < slaveCount; ++i)
            {
                SHM_ECAT_DiagSlaveStatus& target = diag->Slaves[i];
                const EtherCatSlave& source = (*runtimeSlaves)[i];

                std::memset(&target, 0, sizeof(target));

                target.Position = static_cast<uint16_t>(i);
                target.ConfiguredAddress = m_slaveInfo[i].configAddr;
                target.VendorId = m_slaveInfo[i].Vendor_ID;
                target.ProductCode = m_slaveInfo[i].Product_Code;
                target.Revision = m_slaveInfo[i].Revision_No;

                // Static initialization uses the lifecycle-inferred state as a
                // temporary fallback only. Stage 12E.3B overwrites these fields
                // below as soon as the owner-safe ESC live shadow is valid.
                target.AlState = status.MasterState;
                target.AlStatusCode = 0u;

                if (source.runtimeProcessImageBinding.present)
                {
                    target.OutputOffset =
                        source.runtimeProcessImageBinding.outputOffset;
                    target.OutputBytes =
                        EcatDiagClampU16(source.runtimeProcessImageBinding.outputBytes);

                    target.InputOffset =
                        source.runtimeProcessImageBinding.inputOffset;
                    target.InputBytes =
                        EcatDiagClampU16(source.runtimeProcessImageBinding.inputBytes);
                }
                else
                {
                    target.OutputOffset = -1;
                    target.InputOffset = -1;
                }

                target.SmCount =
                    EcatDiagClampU16(
                        static_cast<uint32_t>(source.runtimeSyncManagers.size()));

                target.FmmuCount =
                    EcatDiagClampU16(
                        static_cast<uint32_t>(source.runtimeFmmus.size()));

                target.HasMailbox = source.runtimeMailbox.present ? 1u : 0u;
                target.DcEnabled =
                    (source.runtimeDc.present &&
                        std::strcmp(source.runtimeDc.mode, "DC") == 0)
                    ? 1u
                    : 0u;

                target.IsDcReference =
                    (dcReferenceSlave == static_cast<int>(i)) ? 1u : 0u;

                target.LinkUp = 0u;
                target.RxErrorCount = 0u;
                target.LostLinkCount = 0u;

                EcatDiagCopyName(
                    target.Name,
                    sizeof(target.Name),
                    source.name);
            }

            if (slaveCount < SHM_ECAT_DIAG_MAX_SLAVES)
            {
                SHM_ECAT_DiagSlaveStatus& firstUnused =
                    diag->Slaves[slaveCount];

                std::memset(&firstUnused, 0, sizeof(firstUnused));
                firstUnused.Position = static_cast<uint16_t>(slaveCount);
                firstUnused.OutputOffset = -1;
                firstUnused.InputOffset = -1;
            }

            lastDiag = diag;
            lastSlaveCount = slaveCount;
        }

        // -----------------------------------------------------------------
        // Stage 12E.3B - Publish real per-slave ESC live state.
        //
        // A transient seqlock collision is benign: keep the previous SHM value
        // for that slave and try again on the next 100 ms scheduled pass.
        // -----------------------------------------------------------------
        static uint64_t escDiagReadSuccess = 0ULL;
        static uint64_t escDiagReadMiss = 0ULL;
        uint32_t escDiagAlValidThisPass = 0u;
        uint32_t escDiagDlValidThisPass = 0u;
        uint32_t escDiagErrorValidThisPass = 0u;

        for (uint32_t i = 0u; i < slaveCount; ++i)
        {
            uint32_t validMask = 0u;
            uint16_t alState = 0u;
            uint16_t alStatusCode = 0u;
            uint16_t dlStatus = 0u;
            uint8_t physicalLinkMask = 0u;
            uint8_t communicationMask = 0u;
            uint32_t rxErrorCount = 0u;
            uint32_t lostLinkCount = 0u;
            int32_t lastTransportResult = 0;
            uint64_t lastUpdateTick = 0ULL;
            uint64_t probeSuccess = 0ULL;
            uint64_t probeFailure = 0ULL;

            const bool escRead =
                OSCARMAX_ECAT_EscDiagRt_Read(
                    static_cast<uint16_t>(i),
                    &validMask,
                    &alState,
                    &alStatusCode,
                    &dlStatus,
                    &physicalLinkMask,
                    &communicationMask,
                    &rxErrorCount,
                    &lostLinkCount,
                    &lastTransportResult,
                    &lastUpdateTick,
                    &probeSuccess,
                    &probeFailure);

            if (!escRead)
            {
                escDiagReadMiss++;
                continue;
            }

            escDiagReadSuccess++;

            SHM_ECAT_DiagSlaveStatus& target = diag->Slaves[i];

            if ((validMask & kEcatEscDiagValidAl) != 0u)
            {
                // AL Status register carries state in the low nibble; expose
                // only INIT/PREOP/BOOT/SAFEOP/OP state bits in this field.
                target.AlState = static_cast<uint16_t>(alState & 0x000Fu);
                target.AlStatusCode = alStatusCode;
                escDiagAlValidThisPass++;
            }

            if ((validMask & kEcatEscDiagValidDl) != 0u)
            {
                // Communication-active is the strongest simple LinkUp signal
                // for the existing v1.0 boolean field. Raw per-port masks are
                // preserved in Reserved[] for the ENI Tool detail view.
                target.LinkUp = communicationMask != 0u ? 1u : 0u;
                escDiagDlValidThisPass++;
            }

            if ((validMask & kEcatEscDiagValidErrors) != 0u)
            {
                target.RxErrorCount = rxErrorCount;
                target.LostLinkCount = lostLinkCount;
                escDiagErrorValidThisPass++;
            }

            target.Reserved[0] = physicalLinkMask;
            target.Reserved[1] = communicationMask;
            EcatDiagStoreU16Le(&target.Reserved[2], dlStatus);
            EcatDiagStoreU32Le(&target.Reserved[4], validMask);
            EcatDiagStoreU32Le(
                &target.Reserved[8],
                static_cast<uint32_t>(lastTransportResult));
            EcatDiagStoreU32Le(
                &target.Reserved[12],
                static_cast<uint32_t>(lastUpdateTick & 0xFFFFFFFFULL));

            // probeSuccess/probeFailure are intentionally consumed only by the
            // RT shadow at this ABI level. The live validity + transport result
            // are enough for Windows to distinguish pending/stale/failure.
            (void)probeSuccess;
            (void)probeFailure;
        }

        // Master Reserved32[12..15] were unused in v1.0. Publish compact P50
        // bridge observability without changing the shared-memory contract.
        status.Reserved32[12] = clampU64ToU32(escDiagReadSuccess);
        status.Reserved32[13] = clampU64ToU32(escDiagReadMiss);
        status.Reserved32[14] =
            (escDiagAlValidThisPass & 0xFFu) |
            ((escDiagDlValidThisPass & 0xFFu) << 8) |
            ((escDiagErrorValidThisPass & 0xFFu) << 16) |
            (static_cast<uint32_t>(
                forensicFirstSlopeMadPpb) << 24);
        status.Reserved32[15] = 0x12E0030Bu; // Stage 12E.3B marker

        MemoryBarrier();

        // even = stable Shared Memory snapshot
        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &status.Sequence));

        if (!publisherPrinted)
        {
            publisherPrinted = true;

            DEBUG_PRINT(
                "[ECAT-DIAG-PUBLISHER] ACTIVE | "
                "Name:OSCARMAX_ECAT_DIAG | Cadence:100ms | "
                "Health:YES | SlaveMetadata:YES | "
                "ProcessImage:RT_SHADOW_100HZ | "
                "ESC_Live:P64_SHADOW_TO_P50 | "
                "RTWriter:P64_SHADOW | SHMWriter:P50 | "
                "ControlWrite:NO\n");
        }

    }

    // =====================================================================
    // Stage 12F.3D.2 - OSCARMAX_ECAT_SERVICE Safe SDO Read / Write Bridge
    // Stage 12F.3F.1 - SDO AbortCode propagation to existing SHM response
    // =====================================================================
    //
    // Priority / ownership model:
    //   Windows ENI Tool
    //       -> OSCARMAX_ECAT_SERVICE request
    //       -> this Priority-50 supervisory bridge (NON-BLOCKING)
    //       -> EtherCatMaster::m_asyncCmd
    //       -> Priority-64 PDO owner
    //       -> CMD_SDO_READ / ecx_SDOread()
    //       -> response published back to Shared Memory
    //
    // IMPORTANT:
    //   - This bridge NEVER calls ecx_SDOread/ecx_SDOwrite directly.
    //   - This bridge NEVER sleeps or waits for the mailbox transaction.
    //   - One outstanding engineering request is allowed at a time.
    //   - SDO WRITE is accepted only when the v1.1 Safe Write contract gate
    //     is satisfied: EXPERT_WRITE flag + WRITE_CONFIRM_MAGIC.
    //   - Windows UI confirmation is an additional human-facing guard; this
    //     bridge gate is authoritative on the RTX64 side.
    // =====================================================================

    uint32_t ClampEcatServiceTimeoutMs(
        uint32_t requestedMs)
    {
        // 0 means "use server default".
        if (requestedMs == 0u)
        {
            return 1000u;
        }

        if (requestedMs < 100u)
        {
            return 100u;
        }

        if (requestedMs > 5000u)
        {
            return 5000u;
        }

        return requestedMs;
    }

    uint32_t EcatServiceDurationUs(
        ULONGLONG startMs,
        ULONGLONG endMs)
    {
        const ULONGLONG elapsedMs =
            (endMs >= startMs)
            ? (endMs - startMs)
            : 0ULL;

        const ULONGLONG elapsedUs =
            elapsedMs * 1000ULL;

        return (elapsedUs > 0xFFFFFFFFULL)
            ? 0xFFFFFFFFu
            : static_cast<uint32_t>(elapsedUs);
    }

    void PublishEcatServiceResponse(
        SHM_ECAT_ServiceData* service,
        uint32_t requestId,
        int32_t resultCode,
        int32_t resultWkc,
        uint32_t dataValue,
        uint32_t dataSize,
        uint32_t abortCode,
        uint32_t durationUs)
    {
        if (service == nullptr || requestId == 0u)
        {
            return;
        }

        // ResponseId is the publication fence.  Everything else must be
        // complete before the client is allowed to accept this response.
        service->ResultCode = resultCode;
        service->ResultWkc = resultWkc;
        service->ResponseDataValue = dataValue;
        service->ResponseDataSize = dataSize;
        // Stage 12F.3F.1 - propagate the terminal CoE/SDO abort code from
        // the Priority-64 runtime-safe mailbox state machine. Transport or
        // validation failures keep this field at zero.
        service->AbortCode = abortCode;
        service->DurationUs = durationUs;
        service->ResponseReserved = 0u;
        service->LastProcessedRequestId = requestId;

        MemoryBarrier();

        // Publish LAST.
        service->ResponseId = requestId;
    }

    // =====================================================================
    // Stage 12F.3F.1 - Terminal SDO Abort propagation
    // =====================================================================
    //
    // The Priority-64 SDO state machine already preserves the most recent
    // terminal AbortCode and request identity in its 288-byte diagnostic
    // snapshot.  The engineering-service bridge reads that snapshot only
    // after the async command becomes DONE/ERROR, then accepts the abort code
    // only when slave/index/subindex/command type all match the request being
    // completed.  This prevents an older SDO abort from leaking into a later
    // request while keeping the existing 128-byte Shared Memory ABI intact.
    // =====================================================================
    uint32_t ReadMatchingTerminalSdoAbortCode(
        EtherCatMaster* masterCore,
        uint32_t activeOperation)
    {
        if (masterCore == nullptr)
        {
            return 0u;
        }

        const int expectedCommandType =
            (activeOperation == SHM_ECAT_SERVICE_OP_SDO_WRITE)
            ? (int)EcatCmdType::CMD_SDO_WRITE
            : (activeOperation == SHM_ECAT_SERVICE_OP_SDO_READ)
            ? (int)EcatCmdType::CMD_SDO_READ
            : (int)EcatCmdType::CMD_NONE;

        if (expectedCommandType == (int)EcatCmdType::CMD_NONE)
        {
            return 0u;
        }

        OSCARMAX_ECAT_SdoRtDiagSnapshot_P50 diag = {};

        if (!OSCARMAX_ECAT_SdoRtDiag_Read(
            &diag,
            static_cast<uint32_t>(sizeof(diag))))
        {
            return 0u;
        }

        const bool identityMatches =
            diag.LastTerminalResult != 0 &&
            diag.LastCommandType == expectedCommandType &&
            diag.LastSlave == static_cast<uint32_t>(masterCore->m_asyncCmd.slaveAddr) &&
            diag.LastIndex == static_cast<uint32_t>(masterCore->m_asyncCmd.index) &&
            diag.LastSubIndex == static_cast<uint32_t>(masterCore->m_asyncCmd.subIndex);

        if (!identityMatches)
        {
            return 0u;
        }

        return diag.LastAbortCode;
    }

    OSCARMAX_DIAG_NOINLINE void ProcessEtherCatEngineeringService(
        EtherCatMaster* masterCore)
    {
        if (masterCore == nullptr)
        {
            return;
        }

        SHM_ECAT_ServiceData* service =
            GetEtherCatServiceSharedMemoryData();

        if (service == nullptr)
        {
            return;
        }

        static bool bridgePrinted = false;
        static uint32_t activeRequestId = 0u;
        static uint32_t activeOperation = SHM_ECAT_SERVICE_OP_NONE;
        static uint32_t activeTimeoutMs = 1000u;
        static ULONGLONG activeStartMs = 0ULL;
        static bool drainingTimedOutCommand = false;

        // Heartbeat is supervisory only; wraparound is harmless.
        service->ServerHeartbeat++;

        const EtherCatRuntimeSnapshot runtime =
            masterCore->GetRuntimeSnapshot();

        const bool runtimeReady =
            runtime.stage == EtherCatRuntimeStage::Running &&
            runtime.result != EtherCatRuntimeResult::Fail;

        if (!bridgePrinted)
        {
            bridgePrinted = true;

            DEBUG_PRINT(
                "[ECAT-SERVICE-BRIDGE] ACTIVE | "
                "Name:OSCARMAX_ECAT_SERVICE | Cadence:10ms | "
                "SDORead:YES | SDOWrite:YES_SAFE_GATE | "
                "Bridge:P50_NONBLOCKING | MailboxOwner:P64_PDO | "
                "OneOutstanding:YES\n");
        }

        // -----------------------------------------------------------------
        // Drain an async command that exceeded the engineering-service
        // timeout.  We already returned TIMEOUT to the Windows client, but
        // we must NOT forcibly set a PENDING PDO-owned command to IDLE.
        // Wait until the PDO owner naturally finishes, then reclaim the slot.
        // -----------------------------------------------------------------
        if (drainingTimedOutCommand)
        {
            const int asyncStatus =
                masterCore->m_asyncCmd.status;

            if (asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_DONE ||
                asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_ERROR)
            {
                MemoryBarrier();
                masterCore->m_asyncCmd.status =
                    (int)EcatCmdStatus::ECAT_STATUS_IDLE;

                drainingTimedOutCommand = false;
                service->ServerState = runtimeReady
                    ? SHM_ECAT_SERVICE_SERVER_READY
                    : SHM_ECAT_SERVICE_SERVER_OFFLINE;
            }
            else
            {
                service->ServerState =
                    SHM_ECAT_SERVICE_SERVER_PROCESSING;
            }

            return;
        }

        // -----------------------------------------------------------------
        // Active request: poll the existing async slot without blocking.
        // -----------------------------------------------------------------
        if (activeRequestId != 0u)
        {
            service->ServerState =
                SHM_ECAT_SERVICE_SERVER_PROCESSING;

            const int asyncStatus =
                masterCore->m_asyncCmd.status;

            if (asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_DONE ||
                asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_ERROR)
            {
                MemoryBarrier();

                const int resultWkc =
                    masterCore->m_asyncCmd.resultWKC;

                const uint32_t responseValue =
                    masterCore->m_asyncCmd.dataValue;

                const int responseSizeRaw =
                    masterCore->m_asyncCmd.dataSize;

                const uint32_t responseSize =
                    (responseSizeRaw == 1 ||
                        responseSizeRaw == 2 ||
                        responseSizeRaw == 4)
                    ? static_cast<uint32_t>(responseSizeRaw)
                    : 0u;

                // Stage 12F.3F.1 - capture the terminal CoE abort before
                // reclaiming the async slot. A matching SDO abort is exposed
                // to Windows through the existing AbortCode field.
                const uint32_t terminalAbortCode =
                    ReadMatchingTerminalSdoAbortCode(
                        masterCore,
                        activeOperation);

                // Reclaim command slot only after all response fields have
                // been copied locally.
                masterCore->m_asyncCmd.status =
                    (int)EcatCmdStatus::ECAT_STATUS_IDLE;

                const uint32_t completedRequestId =
                    activeRequestId;

                const uint32_t durationUs =
                    EcatServiceDurationUs(
                        activeStartMs,
                        GetTickCount64());

                int32_t resultCode =
                    SHM_ECAT_SERVICE_RESULT_SUCCESS;

                if (asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_ERROR)
                {
                    resultCode =
                        SHM_ECAT_SERVICE_RESULT_WKC_ERROR;
                }
                else if (resultWkc <= 0)
                {
                    resultCode =
                        SHM_ECAT_SERVICE_RESULT_WKC_ERROR;
                }
                else if (responseSize == 0u)
                {
                    resultCode =
                        SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST;
                }

                if (resultCode == SHM_ECAT_SERVICE_RESULT_SUCCESS)
                {
                    if (activeOperation == SHM_ECAT_SERVICE_OP_SDO_READ)
                    {
                        service->SdoReadCount++;
                    }
                    else if (activeOperation == SHM_ECAT_SERVICE_OP_SDO_WRITE)
                    {
                        service->SdoWriteCount++;
                    }
                    else
                    {
                        resultCode =
                            SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST;
                        service->ErrorCount++;
                    }
                }
                else
                {
                    service->ErrorCount++;
                }

                // For WRITE, the async slot retains the submitted scalar in
                // dataValue/dataSize.  Echoing it here is acknowledgement only;
                // Stage 12F.3D.3 performs an independent SDO READBACK before
                // the ENI Tool reports VERIFY PASS.
                PublishEcatServiceResponse(
                    service,
                    completedRequestId,
                    resultCode,
                    resultWkc,
                    (resultCode == SHM_ECAT_SERVICE_RESULT_SUCCESS)
                    ? responseValue
                    : 0u,
                    (resultCode == SHM_ECAT_SERVICE_RESULT_SUCCESS)
                    ? responseSize
                    : 0u,
                    terminalAbortCode,
                    durationUs);

                activeRequestId = 0u;
                activeOperation = SHM_ECAT_SERVICE_OP_NONE;
                activeStartMs = 0ULL;
                activeTimeoutMs = 1000u;

                service->ServerState = runtimeReady
                    ? SHM_ECAT_SERVICE_SERVER_READY
                    : SHM_ECAT_SERVICE_SERVER_OFFLINE;

                return;
            }

            const ULONGLONG nowMs =
                GetTickCount64();

            const ULONGLONG elapsedMs =
                (nowMs >= activeStartMs)
                ? (nowMs - activeStartMs)
                : 0ULL;

            if (elapsedMs > activeTimeoutMs)
            {
                const uint32_t timedOutRequestId =
                    activeRequestId;

                PublishEcatServiceResponse(
                    service,
                    timedOutRequestId,
                    SHM_ECAT_SERVICE_RESULT_TIMEOUT,
                    0,
                    0u,
                    0u,
                    0u,
                    EcatServiceDurationUs(activeStartMs, nowMs));

                service->ErrorCount++;

                activeRequestId = 0u;
                activeOperation = SHM_ECAT_SERVICE_OP_NONE;
                activeStartMs = 0ULL;
                activeTimeoutMs = 1000u;

                // Critical ownership rule: if PDO still owns a PENDING
                // command, do not force it back to IDLE from Priority-50.
                if (masterCore->m_asyncCmd.status ==
                    (int)EcatCmdStatus::ECAT_STATUS_PENDING)
                {
                    drainingTimedOutCommand = true;
                    service->ServerState =
                        SHM_ECAT_SERVICE_SERVER_PROCESSING;
                }
                else
                {
                    masterCore->m_asyncCmd.status =
                        (int)EcatCmdStatus::ECAT_STATUS_IDLE;

                    service->ServerState = runtimeReady
                        ? SHM_ECAT_SERVICE_SERVER_READY
                        : SHM_ECAT_SERVICE_SERVER_OFFLINE;
                }

                return;
            }

            return;
        }

        // No active service request.
        service->ServerState = runtimeReady
            ? SHM_ECAT_SERVICE_SERVER_READY
            : SHM_ECAT_SERVICE_SERVER_OFFLINE;

        // RequestId is published last by the Windows client.  Snapshot the
        // request around a full memory barrier and reject a torn update.
        const uint32_t requestIdBefore =
            service->RequestId;

        if (requestIdBefore == 0u ||
            requestIdBefore == service->LastProcessedRequestId)
        {
            return;
        }

        MemoryBarrier();

        const uint32_t operation = service->Operation;
        const uint16_t slavePosition = service->SlavePosition;
        const uint16_t index = service->Index;
        const uint8_t subIndex = service->SubIndex;
        const uint8_t completeAccess = service->CompleteAccess;
        const uint8_t dataSize = service->DataSize;
        const uint32_t dataValue = service->DataValue;
        const uint32_t timeoutMs = service->TimeoutMs;
        const uint32_t flags = service->Flags;
        const uint32_t writeConfirmMagic =
            service->RequestReserved[0];

        MemoryBarrier();

        const uint32_t requestIdAfter =
            service->RequestId;

        if (requestIdBefore != requestIdAfter)
        {
            // Client was still publishing; consume nothing this iteration.
            return;
        }

        const uint32_t requestId =
            requestIdBefore;

        // Clear stale response publication while this new request is being
        // evaluated.  Client only accepts ResponseId == current RequestId.
        service->ResponseId = 0u;
        service->ResultCode =
            SHM_ECAT_SERVICE_RESULT_NONE;
        service->ResultWkc = 0;
        service->ResponseDataValue = 0u;
        service->ResponseDataSize = 0u;
        service->AbortCode = 0u;
        service->DurationUs = 0u;

        const ULONGLONG requestStartMs =
            GetTickCount64();

        auto rejectRequest =
            [&](int32_t resultCode)
        {
            service->ErrorCount++;

            PublishEcatServiceResponse(
                service,
                requestId,
                resultCode,
                0,
                0u,
                0u,
                0u,
                EcatServiceDurationUs(
                    requestStartMs,
                    GetTickCount64()));

            service->ServerState = runtimeReady
                ? SHM_ECAT_SERVICE_SERVER_READY
                : SHM_ECAT_SERVICE_SERVER_OFFLINE;
        };

        if (!runtimeReady)
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_RUNTIME_NOT_READY);
            return;
        }

        const bool isSdoRead =
            operation == SHM_ECAT_SERVICE_OP_SDO_READ;

        const bool isSdoWrite =
            operation == SHM_ECAT_SERVICE_OP_SDO_WRITE;

        if (!isSdoRead && !isSdoWrite)
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_UNSUPPORTED);
            return;
        }

        if (completeAccess != 0u ||
            (dataSize != 1u && dataSize != 2u && dataSize != 4u))
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST);
            return;
        }

        if (isSdoRead)
        {
            // READ must remain completely unprivileged.  Reject stale write
            // flags rather than silently ignoring them.
            if (flags != 0u)
            {
                rejectRequest(
                    SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST);
                return;
            }
        }
        else
        {
            // Stage 12F.3D.1 authoritative Safe Write contract gate.
            // Both the exact Expert flag and the confirmation magic are
            // required.  Unknown flag bits are not accepted.
            const bool expertFlagOk =
                flags == kEcatServiceExpertWriteFlag;

            const bool confirmMagicOk =
                writeConfirmMagic ==
                kEcatServiceWriteConfirmMagic;

            if (!expertFlagOk || !confirmMagicOk)
            {
                rejectRequest(
                    SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST);
                return;
            }
        }

        if (masterCore->m_pEni == nullptr)
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_RUNTIME_NOT_READY);
            return;
        }

        const auto& slaves =
            masterCore->m_pEni->GetSlaves();

        if (slavePosition >= slaves.size())
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_INVALID_REQUEST);
            return;
        }

        if (!slaves[slavePosition].runtimeMailbox.present)
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_NO_MAILBOX);
            return;
        }

        const int asyncStatus =
            masterCore->m_asyncCmd.status;

        if (asyncStatus != (int)EcatCmdStatus::ECAT_STATUS_IDLE &&
            asyncStatus != (int)EcatCmdStatus::ECAT_STATUS_DONE)
        {
            rejectRequest(
                SHM_ECAT_SERVICE_RESULT_BUSY);
            return;
        }

        // DONE may be a stale completed command from another engineering
        // path.  Reclaim it before publishing our new order.
        if (asyncStatus == (int)EcatCmdStatus::ECAT_STATUS_DONE)
        {
            masterCore->m_asyncCmd.status =
                (int)EcatCmdStatus::ECAT_STATUS_IDLE;
        }

        // Fill command payload first.
        masterCore->m_asyncCmd.type =
            isSdoWrite
            ? (int)EcatCmdType::CMD_SDO_WRITE
            : (int)EcatCmdType::CMD_SDO_READ;

        masterCore->m_asyncCmd.slaveAddr =
            slavePosition;

        masterCore->m_asyncCmd.index =
            index;

        masterCore->m_asyncCmd.subIndex =
            subIndex;

        masterCore->m_asyncCmd.dataValue =
            isSdoWrite ? dataValue : 0u;

        masterCore->m_asyncCmd.dataSize =
            static_cast<int>(dataSize);
        masterCore->m_asyncCmd.resultWKC = 0;

        activeRequestId = requestId;
        activeOperation = operation;
        activeStartMs = requestStartMs;
        activeTimeoutMs =
            ClampEcatServiceTimeoutMs(timeoutMs);

        service->ServerState =
            SHM_ECAT_SERVICE_SERVER_PROCESSING;

        MemoryBarrier();

        // Publish command LAST to the Priority-64 PDO owner.
        masterCore->m_asyncCmd.status =
            (int)EcatCmdStatus::ECAT_STATUS_PENDING;
    }
}

// ============================================================================
// Stage 17A.5.1 - V1A Observer Forensics Publisher
//
// Source fingerprint:
//     OSCARMAX_DC_V1A_OBSERVER_FORENSICS_17A5_20260828
//
// Reads the existing coherent V1A seqlock snapshot from Priority-64.
// Priority-50 appends one ring entry ONLY when V1A sequence changes.
//
// No EtherCAT transaction / SDO / PDO write / tuning change.
// ============================================================================
namespace
{
    OSCARMAX_DIAG_NOINLINE void PublishEtherCatDcV1aObserverDiagnostics()
    {
        SHM_ECAT_DcV1aDiagData* diag =
            GetEtherCatDcV1aDiagSharedMemoryData();

        if (diag == nullptr)
        {
            return;
        }

        LONG sequence = 0;
        LONG initialized = 0;
        LONGLONG meanPhaseNs = 0;
        LONGLONG phaseSpanNs = 0;
        LONG pointAccepted = 0;
        LONG meanSamples = 0;
        LONG pointCount = 0;
        LONG pairCount = 0;
        LONGLONG theilSenPpb = 0;
        LONGLONG slopeMadPpb = 0;
        LONGLONG timeSpanNs = 0;
        LONG locked = 0;
        LONGLONG recommendedPpb = 0;
        LONGLONG trustedDriftPpb = 0;
        LONGLONG trustedMinusRecommendedPpb = 0;
        LONGLONG windowElapsedNs = 0;
        LONGLONG windowRttMaxNs = 0;
        LONG acceptedPointTotal = 0;
        LONG rejectedPointTotal = 0;
        LONG rejectSamplesTotal = 0;
        LONG rejectElapsedTotal = 0;
        LONG rejectRttTotal = 0;
        LONG rejectSpanTotal = 0;
        LONGLONG slopeMinPpb = 0;
        LONGLONG slopeMaxPpb = 0;

        bool snapshotValid = false;

        for (int attempt = 0;
            attempt < 3 && !snapshotValid;
            ++attempt)
        {
            const LONG seq1 =
                g_qpcDcPhaseResidualV1ADiagSequence;

            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }

            MemoryBarrier();

            initialized =
                g_qpcDcPhaseResidualV1AInitialized;
            meanPhaseNs =
                g_qpcDcPhaseResidualV1AMeanPhaseNs;
            phaseSpanNs =
                g_qpcDcPhaseResidualV1APhaseSpanNs;
            pointAccepted =
                g_qpcDcPhaseResidualV1APointAccepted;
            meanSamples =
                g_qpcDcPhaseResidualV1AMeanSamples;
            pointCount =
                g_qpcDcPhaseResidualV1APointBufferCount;
            pairCount =
                g_qpcDcPhaseResidualV1APairSlopeCount;
            theilSenPpb =
                g_qpcDcPhaseResidualV1ATheilSenPpb;
            slopeMadPpb =
                g_qpcDcPhaseResidualV1ASlopeMadPpb;
            timeSpanNs =
                g_qpcDcPhaseResidualV1ATimeSpanNs;
            locked =
                g_qpcDcPhaseResidualV1ALocked;
            recommendedPpb =
                g_qpcDcPhaseResidualV1ARecommendedSchedulerPpb;
            trustedDriftPpb =
                g_qpcDcPhaseResidualV1ATrustedDriftPpb;
            trustedMinusRecommendedPpb =
                g_qpcDcPhaseResidualV1ATrustedMinusRecommendedPpb;
            windowElapsedNs =
                g_qpcDcPhaseResidualV1AWindowElapsedNs;
            windowRttMaxNs =
                g_qpcDcPhaseResidualV1AWindowRttMaxNs;
            acceptedPointTotal =
                g_qpcDcPhaseResidualV1AAcceptedPointTotal;
            rejectedPointTotal =
                g_qpcDcPhaseResidualV1ARejectedPointTotal;
            rejectSamplesTotal =
                g_qpcDcPhaseResidualV1ARejectSamplesTotal;
            rejectElapsedTotal =
                g_qpcDcPhaseResidualV1ARejectElapsedTotal;
            rejectRttTotal =
                g_qpcDcPhaseResidualV1ARejectRttTotal;
            rejectSpanTotal =
                g_qpcDcPhaseResidualV1ARejectSpanTotal;
            slopeMinPpb =
                g_qpcDcPhaseResidualV1ASlopeMinPpb;
            slopeMaxPpb =
                g_qpcDcPhaseResidualV1ASlopeMaxPpb;

            MemoryBarrier();

            const LONG seq2 =
                g_qpcDcPhaseResidualV1ADiagSequence;

            snapshotValid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;

            if (snapshotValid)
            {
                sequence =
                    seq2;
            }
        }

        if (!snapshotValid)
        {
            return;
        }

        auto clampI32 =
            [](LONGLONG value) -> int32_t
        {
            if (value < -2147483648LL)
                return static_cast<int32_t>(-2147483647 - 1);
            if (value > 2147483647LL)
                return static_cast<int32_t>(2147483647);
            return static_cast<int32_t>(value);
        };

        auto clampU32 =
            [](LONGLONG value) -> uint32_t
        {
            if (value <= 0)
                return 0u;
            if (static_cast<ULONGLONG>(value) > 0xFFFFFFFFULL)
                return 0xFFFFFFFFu;
            return static_cast<uint32_t>(value);
        };

        auto clampU16 =
            [](LONG value) -> uint16_t
        {
            if (value <= 0)
                return 0u;
            if (value >= 65535)
                return 65535u;
            return static_cast<uint16_t>(value);
        };

        auto clampU8 =
            [](LONG value) -> uint8_t
        {
            if (value <= 0)
                return 0u;
            if (value >= 255)
                return 255u;
            return static_cast<uint8_t>(value);
        };


        SHM_ECAT_DcV1aDiagHeader& header =
            diag->Header;
        SHM_ECAT_DcV1aDiagSummary& summary =
            diag->Summary;

        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        MemoryBarrier();

        header.Magic =
            SHM_ECAT_DC_V1A_DIAG_MAGIC;
        header.VersionMajor =
            SHM_ECAT_DC_V1A_DIAG_VERSION_MAJOR;
        header.VersionMinor =
            SHM_ECAT_DC_V1A_DIAG_VERSION_MINOR;
        header.StructSize =
            static_cast<uint32_t>(
                sizeof(SHM_ECAT_DcV1aDiagData));
        header.Heartbeat++;
        header.PublishCount++;
        header.Capacity =
            SHM_ECAT_DC_V1A_DIAG_CAPACITY;


        summary.Initialized =
            initialized != 0 ? 1u : 0u;
        summary.PointAccepted =
            pointAccepted != 0 ? 1u : 0u;
        summary.Locked =
            locked != 0 ? 1u : 0u;
        summary.CurrentV2State =
            clampU8(g_qpcPhaseFfV2State);
        summary.CurrentCandidateGood =
            g_qpcPhaseFfV2CandidateGood != 0 ? 1u : 0u;
        summary.CurrentRejectMask =
            static_cast<uint8_t>(
                g_qpcRealFfV0PhaseRejectMask & 0xFF);

        summary.MeanPhaseNs =
            static_cast<int64_t>(meanPhaseNs);
        summary.PhaseSpanNs =
            static_cast<int64_t>(phaseSpanNs);
        summary.WindowElapsedNs =
            static_cast<int64_t>(windowElapsedNs);
        summary.WindowRttMaxNs =
            static_cast<int64_t>(windowRttMaxNs);
        summary.TimeSpanNs =
            static_cast<int64_t>(timeSpanNs);

        summary.TheilSenPpb =
            clampI32(theilSenPpb);
        summary.SlopeMadPpb =
            clampI32(slopeMadPpb);
        summary.SlopeMinPpb =
            clampI32(slopeMinPpb);
        summary.SlopeMaxPpb =
            clampI32(slopeMaxPpb);
        summary.RecommendedPpb =
            clampI32(recommendedPpb);
        summary.TrustedDriftPpb =
            clampI32(trustedDriftPpb);
        summary.TrustedMinusRecommendedPpb =
            clampI32(trustedMinusRecommendedPpb);

        summary.MeanSamples =
            clampU32(meanSamples);
        summary.PointBufferCount =
            clampU32(pointCount);
        summary.PairSlopeCount =
            clampU32(pairCount);
        summary.AcceptedPointTotal =
            clampU32(acceptedPointTotal);
        summary.RejectedPointTotal =
            clampU32(rejectedPointTotal);
        summary.RejectSamplesTotal =
            clampU32(rejectSamplesTotal);
        summary.RejectElapsedTotal =
            clampU32(rejectElapsedTotal);
        summary.RejectRttTotal =
            clampU32(rejectRttTotal);
        summary.RejectSpanTotal =
            clampU32(rejectSpanTotal);

        const uint32_t madAbs =
            slopeMadPpb <= 0 ? 0u : clampU32(slopeMadPpb);
        const uint32_t spanAbs =
            phaseSpanNs <= 0 ? 0u : clampU32(phaseSpanNs);
        const uint32_t rttAbs =
            windowRttMaxNs <= 0 ? 0u : clampU32(windowRttMaxNs);

        LONGLONG spread =
            slopeMaxPpb -
            slopeMinPpb;
        if (spread < 0)
            spread = -spread;

        const uint32_t spreadAbs =
            clampU32(spread);

        if (madAbs > summary.PeakMadPpb)
            summary.PeakMadPpb = madAbs;
        if (spanAbs > summary.PeakPhaseSpanNs)
            summary.PeakPhaseSpanNs = spanAbs;
        if (rttAbs > summary.PeakRttNs)
            summary.PeakRttNs = rttAbs;
        if (spreadAbs > summary.PeakSlopeSpreadPpb)
            summary.PeakSlopeSpreadPpb = spreadAbs;


        static SHM_ECAT_DcV1aDiagData* lastMapping =
            nullptr;
        static LONG lastSequence =
            0;

        if (lastMapping != diag)
        {
            lastMapping =
                diag;
            lastSequence =
                0;
        }

        if (sequence != 0 &&
            sequence != lastSequence)
        {
            const uint32_t slot =
                header.WriteIndex %
                SHM_ECAT_DC_V1A_DIAG_CAPACITY;

            SHM_ECAT_DcV1aDiagEntry& entry =
                diag->Entries[slot];

            std::memset(
                &entry,
                0,
                sizeof(entry));

            entry.CapturePublishCount =
                header.PublishCount;
            entry.V1aSequence =
                static_cast<uint32_t>(sequence);

            uint32_t flags =
                0u;
            if (initialized != 0) flags |= 0x01u;
            if (pointAccepted != 0) flags |= 0x02u;
            if (locked != 0) flags |= 0x04u;
            if (g_qpcPhaseFfV2CandidateGood != 0) flags |= 0x08u;

            flags |=
                (static_cast<uint32_t>(
                    g_qpcPhaseFfV2State) & 0x03u) << 4;
            flags |=
                (static_cast<uint32_t>(
                    g_qpcRealFfV0PhaseRejectMask) & 0xFFu) << 8;

            entry.Flags =
                flags;
            entry.MeanPhaseNs =
                static_cast<int64_t>(meanPhaseNs);
            entry.PhaseSpanNs =
                static_cast<int64_t>(phaseSpanNs);
            entry.WindowElapsedNs =
                static_cast<int64_t>(windowElapsedNs);
            entry.WindowRttMaxNs =
                static_cast<int64_t>(windowRttMaxNs);
            entry.TimeSpanNs =
                static_cast<int64_t>(timeSpanNs);
            entry.TheilSenPpb =
                clampI32(theilSenPpb);
            entry.SlopeMadPpb =
                clampI32(slopeMadPpb);
            entry.SlopeMinPpb =
                clampI32(slopeMinPpb);
            entry.SlopeMaxPpb =
                clampI32(slopeMaxPpb);
            entry.RecommendedPpb =
                clampI32(recommendedPpb);
            entry.TrustedDriftPpb =
                clampI32(trustedDriftPpb);
            entry.TrustedMinusRecommendedPpb =
                clampI32(trustedMinusRecommendedPpb);
            entry.MeanSamples =
                clampU16(meanSamples);
            entry.PointBufferCount =
                clampU8(pointCount);
            entry.PairSlopeCount =
                clampU8(pairCount);
            entry.AcceptedPointTotal =
                clampU32(acceptedPointTotal);
            entry.RejectedPointTotal =
                clampU32(rejectedPointTotal);
            entry.RejectSamplesTotal =
                clampU32(rejectSamplesTotal);
            entry.RejectElapsedTotal =
                clampU32(rejectElapsedTotal);
            entry.RejectRttTotal =
                clampU32(rejectRttTotal);
            entry.RejectSpanTotal =
                clampU32(rejectSpanTotal);

            ++header.WriteIndex;

            if (header.EntryCount <
                SHM_ECAT_DC_V1A_DIAG_CAPACITY)
            {
                ++header.EntryCount;
            }

            lastSequence =
                sequence;
        }

        MemoryBarrier();

        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));
    }
}


// ============================================================================
// Stage 17A.8.1 - RX Deadline / V1A Correlation Publisher
//
// Source fingerprint:
//     OSCARMAX_RX_V1A_CORRELATION_17A8_20260828
//
// One ring entry is appended only when the coherent RX diagnostic sequence
// changes (~1 second).
//
// The same row captures nearest V1A, PDO RT, and DC state diagnostics.
//
// No EtherCAT frame / SDO / PDO write / deadline / tuning change.
// ============================================================================
namespace
{
    OSCARMAX_DIAG_NOINLINE void PublishEtherCatRxV1aCorrelationDiagnostics()
    {
        SHM_ECAT_RxCorrDiagData* diag =
            GetEtherCatRxCorrelationDiagSharedMemoryData();


        if (diag == nullptr)
        {
            return;
        }


        LONG rxSequence = 0;

        LONG rxCalls = 0;
        LONG rxFirstRxSuccess = 0;
        LONG rxEmptyRx = 0;
        LONG rxInvalidFrame = 0;

        LONG rxSoftLateAccepted = 0;
        LONGLONG rxTotalSoftLateAccepted = 0;
        LONGLONG rxSoftLateElapsedMaxNs = 0;

        LONG rxHardTimeout = 0;
        LONG rxPostReceiveLate = 0;

        LONG rxCurrentConsecutiveTimeout = 0;
        LONG rxMaxConsecutiveTimeout = 0;

        LONGLONG rxTotalHardTimeout = 0;

        LONG rxRecoveryAfterTimeout = 0;
        LONG rxQpcFail = 0;
        LONG rxSleepCount = 0;

        LONG rxElapsedValid = 0;
        LONGLONG rxElapsedAvgNs = 0;
        LONGLONG rxElapsedMaxNs = 0;

        LONG rxTimeoutPreReceive = 0;
        LONG rxTimeoutSleep0 = 0;
        LONG rxTimeoutSleep1 = 0;
        LONG rxTimeoutSleep2 = 0;

        LONG rxTimeoutAttemptAvg = 0;
        LONG rxTimeoutAttemptMax = 0;

        LONGLONG rxReceiveCallMaxNs = 0;
        LONGLONG rxTimeoutReceiveCallMaxNs = 0;

        LONG rxSoftDeadlineNs = 0;
        LONG rxHardDeadlineNs = 0;

        bool rxSnapshotValid = false;


        for (int attempt = 0;
            attempt < 3 && !rxSnapshotValid;
            ++attempt)
        {
            const LONG seq1 =
                g_ecatRxDiagSequence;


            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }


            MemoryBarrier();


            rxCalls =
                g_ecatRxDiagCalls;

            rxFirstRxSuccess =
                g_ecatRxDiagFirstRxSuccess;

            rxEmptyRx =
                g_ecatRxDiagEmptyRx;

            rxInvalidFrame =
                g_ecatRxDiagInvalidFrame;

            rxSoftLateAccepted =
                g_ecatRxDiagSoftLateAccepted;

            rxTotalSoftLateAccepted =
                g_ecatRxDiagTotalSoftLateAccepted;

            rxSoftLateElapsedMaxNs =
                g_ecatRxDiagSoftLateElapsedMaxNs;

            rxHardTimeout =
                g_ecatRxDiagHardTimeout;

            rxPostReceiveLate =
                g_ecatRxDiagPostReceiveLate;

            rxCurrentConsecutiveTimeout =
                g_ecatRxDiagCurrentConsecutiveTimeout;

            rxMaxConsecutiveTimeout =
                g_ecatRxDiagMaxConsecutiveTimeout;

            rxTotalHardTimeout =
                g_ecatRxDiagTotalHardTimeout;

            rxRecoveryAfterTimeout =
                g_ecatRxDiagRecoveryAfterTimeout;

            rxQpcFail =
                g_ecatRxDiagQpcFail;

            rxSleepCount =
                g_ecatRxDiagSleepCount;

            rxElapsedValid =
                g_ecatRxDiagElapsedValid;

            rxElapsedAvgNs =
                g_ecatRxDiagElapsedAvgNs;

            rxElapsedMaxNs =
                g_ecatRxDiagElapsedMaxNs;

            rxTimeoutPreReceive =
                g_ecatRxDiagTimeoutPreReceive;

            rxTimeoutSleep0 =
                g_ecatRxDiagTimeoutSleep0;

            rxTimeoutSleep1 =
                g_ecatRxDiagTimeoutSleep1;

            rxTimeoutSleep2 =
                g_ecatRxDiagTimeoutSleep2;

            rxTimeoutAttemptAvg =
                g_ecatRxDiagTimeoutAttemptAvg;

            rxTimeoutAttemptMax =
                g_ecatRxDiagTimeoutAttemptMax;

            rxReceiveCallMaxNs =
                g_ecatRxDiagReceiveCallMaxNs;

            rxTimeoutReceiveCallMaxNs =
                g_ecatRxDiagTimeoutReceiveCallMaxNs;

            rxSoftDeadlineNs =
                g_ecatRxDiagSoftDeadlineNs;

            rxHardDeadlineNs =
                g_ecatRxDiagHardDeadlineNs;


            MemoryBarrier();


            const LONG seq2 =
                g_ecatRxDiagSequence;


            rxSnapshotValid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;


            if (rxSnapshotValid)
            {
                rxSequence =
                    seq2;
            }
        }


        if (!rxSnapshotValid)
        {
            return;
        }


        static SHM_ECAT_RxCorrDiagData*
            lastMapping =
            nullptr;

        static LONG
            lastRxSequence =
            0;


        if (lastMapping != diag)
        {
            lastMapping =
                diag;

            lastRxSequence =
                0;
        }


        if (rxSequence == 0 ||
            rxSequence == lastRxSequence)
        {
            return;
        }


        // Nearest coherent V1A.
        LONG v1aSequence = 0;

        LONGLONG v1aMeanPhaseNs = 0;
        LONGLONG v1aPhaseSpanNs = 0;
        LONGLONG v1aWindowRttMaxNs = 0;

        LONGLONG v1aSlopeMadPpb = 0;
        LONGLONG v1aTheilSenPpb = 0;
        LONGLONG v1aSlopeMinPpb = 0;
        LONGLONG v1aSlopeMaxPpb = 0;

        LONG v1aPointAccepted = 0;
        LONG v1aLocked = 0;

        bool v1aSnapshotValid = false;


        for (int attempt = 0;
            attempt < 3 && !v1aSnapshotValid;
            ++attempt)
        {
            const LONG seq1 =
                g_qpcDcPhaseResidualV1ADiagSequence;


            if (seq1 == 0 ||
                (seq1 & 1) != 0)
            {
                continue;
            }


            MemoryBarrier();


            v1aMeanPhaseNs =
                g_qpcDcPhaseResidualV1AMeanPhaseNs;

            v1aPhaseSpanNs =
                g_qpcDcPhaseResidualV1APhaseSpanNs;

            v1aWindowRttMaxNs =
                g_qpcDcPhaseResidualV1AWindowRttMaxNs;

            v1aSlopeMadPpb =
                g_qpcDcPhaseResidualV1ASlopeMadPpb;

            v1aTheilSenPpb =
                g_qpcDcPhaseResidualV1ATheilSenPpb;

            v1aSlopeMinPpb =
                g_qpcDcPhaseResidualV1ASlopeMinPpb;

            v1aSlopeMaxPpb =
                g_qpcDcPhaseResidualV1ASlopeMaxPpb;

            v1aPointAccepted =
                g_qpcDcPhaseResidualV1APointAccepted;

            v1aLocked =
                g_qpcDcPhaseResidualV1ALocked;


            MemoryBarrier();


            const LONG seq2 =
                g_qpcDcPhaseResidualV1ADiagSequence;


            v1aSnapshotValid =
                seq1 == seq2 &&
                (seq2 & 1) == 0;


            if (v1aSnapshotValid)
            {
                v1aSequence =
                    seq2;
            }
        }


        auto clampU32 =
            [](LONGLONG value) -> uint32_t
        {
            if (value <= 0)
            {
                return 0u;
            }

            if (static_cast<ULONGLONG>(value) >
                0xFFFFFFFFULL)
            {
                return 0xFFFFFFFFu;
            }

            return
                static_cast<uint32_t>(
                    value);
        };


        auto clampU64 =
            [](LONGLONG value) -> uint64_t
        {
            return
                value <= 0
                ? 0ULL
                : static_cast<uint64_t>(
                    value);
        };


        auto clampI32 =
            [](LONGLONG value) -> int32_t
        {
            if (value < -2147483648LL)
            {
                return
                    static_cast<int32_t>(
                        -2147483647 - 1);
            }

            if (value > 2147483647LL)
            {
                return
                    static_cast<int32_t>(
                        2147483647);
            }

            return
                static_cast<int32_t>(
                    value);
        };


        SHM_ECAT_RxCorrDiagHeader& header =
            diag->Header;


        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        MemoryBarrier();


        header.Magic =
            SHM_ECAT_RX_CORR_DIAG_MAGIC;

        header.VersionMajor =
            SHM_ECAT_RX_CORR_DIAG_VERSION_MAJOR;

        header.VersionMinor =
            SHM_ECAT_RX_CORR_DIAG_VERSION_MINOR;

        header.StructSize =
            static_cast<uint32_t>(
                sizeof(SHM_ECAT_RxCorrDiagData));

        header.Heartbeat++;
        header.PublishCount++;

        header.Capacity =
            SHM_ECAT_RX_CORR_DIAG_CAPACITY;


        const uint32_t slot =
            header.WriteIndex %
            SHM_ECAT_RX_CORR_DIAG_CAPACITY;


        SHM_ECAT_RxCorrDiagEntry& entry =
            diag->Entries[slot];


        std::memset(
            &entry,
            0,
            sizeof(entry));


        entry.CapturePublishCount =
            header.PublishCount;

        entry.RxSequence =
            static_cast<uint32_t>(
                rxSequence);

        entry.V1aSequence =
            v1aSnapshotValid
            ? static_cast<uint32_t>(
                v1aSequence)
            : 0u;


        uint32_t flags =
            0x00000001u;


        if (v1aSnapshotValid)
            flags |= 0x00000002u;

        if (rxHardTimeout > 0)
            flags |= 0x00000004u;

        if (rxPostReceiveLate > 0)
            flags |= 0x00000008u;

        if (rxTimeoutPreReceive > 0)
            flags |= 0x00000010u;

        if (g_qpcPhaseFfV2CandidateGood != 0)
            flags |= 0x00000020u;

        if (g_qpcPhasePActV0GateGood != 0)
            flags |= 0x00000040u;

        if (v1aPointAccepted != 0)
            flags |= 0x00000080u;


        entry.Flags =
            flags;


        entry.Calls = clampU32(rxCalls);
        entry.FirstRxSuccess = clampU32(rxFirstRxSuccess);
        entry.EmptyRx = clampU32(rxEmptyRx);
        entry.InvalidFrame = clampU32(rxInvalidFrame);

        entry.SoftLateAccepted = clampU32(rxSoftLateAccepted);
        entry.HardTimeout = clampU32(rxHardTimeout);
        entry.PostReceiveLate = clampU32(rxPostReceiveLate);

        entry.CurrentConsecutiveTimeout =
            clampU32(rxCurrentConsecutiveTimeout);

        entry.MaxConsecutiveTimeout =
            clampU32(rxMaxConsecutiveTimeout);

        entry.RecoveryAfterTimeout =
            clampU32(rxRecoveryAfterTimeout);

        entry.QpcFail = clampU32(rxQpcFail);
        entry.SleepCount = clampU32(rxSleepCount);
        entry.ElapsedValid = clampU32(rxElapsedValid);

        entry.TimeoutPreReceive =
            clampU32(rxTimeoutPreReceive);

        entry.TimeoutSleep0 =
            clampU32(rxTimeoutSleep0);

        entry.TimeoutSleep1 =
            clampU32(rxTimeoutSleep1);

        entry.TimeoutSleep2 =
            clampU32(rxTimeoutSleep2);

        entry.TimeoutAttemptAvg =
            clampU32(rxTimeoutAttemptAvg);

        entry.TimeoutAttemptMax =
            clampU32(rxTimeoutAttemptMax);

        entry.SoftDeadlineNs =
            clampU32(rxSoftDeadlineNs);

        entry.HardDeadlineNs =
            clampU32(rxHardDeadlineNs);


        entry.TotalSoftLateAccepted =
            clampU64(rxTotalSoftLateAccepted);

        entry.SoftLateElapsedMaxNs =
            clampU64(rxSoftLateElapsedMaxNs);

        entry.TotalHardTimeout =
            clampU64(rxTotalHardTimeout);

        entry.ElapsedAvgNs =
            clampU64(rxElapsedAvgNs);

        entry.ElapsedMaxNs =
            clampU64(rxElapsedMaxNs);

        entry.ReceiveCallMaxNs =
            clampU64(rxReceiveCallMaxNs);

        entry.TimeoutReceiveCallMaxNs =
            clampU64(rxTimeoutReceiveCallMaxNs);


        if (v1aSnapshotValid)
        {
            entry.V1aMeanPhaseNs =
                static_cast<int64_t>(
                    v1aMeanPhaseNs);

            entry.V1aPhaseSpanNs =
                static_cast<int64_t>(
                    v1aPhaseSpanNs);

            entry.V1aWindowRttMaxNs =
                static_cast<int64_t>(
                    v1aWindowRttMaxNs);

            entry.V1aSlopeMadPpb =
                clampI32(v1aSlopeMadPpb);

            entry.V1aTheilSenPpb =
                clampI32(v1aTheilSenPpb);

            entry.V1aSlopeMinPpb =
                clampI32(v1aSlopeMinPpb);

            entry.V1aSlopeMaxPpb =
                clampI32(v1aSlopeMaxPpb);
        }


        entry.PdoExecAvgNs =
            clampI32(g_pdoRtExecAvgNs);

        entry.PdoExecMaxNs =
            clampI32(g_pdoRtExecMaxNs);

        entry.PdoCombinedMaxNs =
            clampI32(g_pdoRtCombinedMaxNs);

        entry.DcPhaseErrorNs =
            clampI32(g_qpcPhasePActV0ActualErrNs);

        entry.LrwWkc =
            static_cast<int32_t>(
                g_pdoRtLrwWkc);

        entry.DcWkc =
            static_cast<int32_t>(
                g_pdoRtDcWkc);

        entry.PdoExecOver250Count =
            clampU32(g_pdoRtExecOver250Count);

        entry.PdoExecOver300Count =
            clampU32(g_pdoRtExecOver300Count);

        entry.PdoExecOver400Count =
            clampU32(g_pdoRtExecOver400Count);


        entry.V1aPointAccepted =
            v1aPointAccepted != 0
            ? 1u
            : 0u;

        entry.V1aLocked =
            v1aLocked != 0
            ? 1u
            : 0u;

        entry.V2State =
            static_cast<uint8_t>(
                g_qpcPhaseFfV2State &
                0xFF);

        entry.V2CandidateGood =
            g_qpcPhaseFfV2CandidateGood != 0
            ? 1u
            : 0u;

        entry.RealFfRejectMask =
            static_cast<uint8_t>(
                g_qpcRealFfV0PhaseRejectMask &
                0xFF);

        entry.DcGateOpen =
            g_qpcPhasePActV0GateGood != 0
            ? 1u
            : 0u;

        entry.RealFfState =
            static_cast<uint8_t>(
                g_qpcRealFfV0State &
                0xFF);

        entry.PhasePState =
            static_cast<uint8_t>(
                g_qpcPhasePActV0State &
                0xFF);

        entry.TripMask =
            static_cast<uint8_t>(
                g_qpcRealFfV0TripMask &
                0xFF);


        ++header.WriteIndex;


        if (header.EntryCount <
            SHM_ECAT_RX_CORR_DIAG_CAPACITY)
        {
            ++header.EntryCount;
        }


        lastRxSequence =
            rxSequence;


        MemoryBarrier();


        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));
    }
}


// ============================================================================
// DC-RX.4B - RX Incident Forensics -> Dedicated Shared Memory
//
// Priority-50 is the only writer. This publisher performs ZERO EtherCAT
// transactions and only copies the already-existing DC-RX.4A owner-safe
// incident ring and ESC per-port snapshots.
//
// Publish policy (DC-DIAG.1):
//     - check IncidentId / ESC ChangeSerial every supervisory pass
//     - rebuild the 65 KB incident/ESC payload only when it changes
//     - refresh only the compact summary/header at approximately 1 second
//
// Existing OSCARMAX_ECAT_DIAG and all control/safety ABIs remain unchanged.
// ============================================================================
namespace
{
    void CopyRx4bIncident(
        SHM_ECAT_RxForensicsIncident& destination,
        const EtherCatRxIncidentRecord& source)
    {
        std::memset(
            &destination,
            0,
            sizeof(destination));

        destination.IncidentId = source.IncidentId;
        destination.RelatedIncidentId = source.RelatedIncidentId;
        destination.BurstId = source.BurstId;
        destination.PdoTick = source.PdoTick;
        destination.Qpc = source.Qpc;
        destination.QpcFrequency = source.QpcFrequency;
        destination.TotalHardTimeout = source.TotalHardTimeout;
        destination.RxElapsedNs = source.RxElapsedNs;
        destination.ReceiveCallNs = source.ReceiveCallNs;
        destination.ReceiveCallMaxNs = source.ReceiveCallMaxNs;
        destination.SchedulerRecoveryTotal = source.SchedulerRecoveryTotal;
        destination.EscPortChangeSerial = source.EscPortChangeSerial;
        destination.NalCallSequence = source.NalCallSequence;

        destination.PhaseErrorNs = source.PhaseErrorNs;
        destination.AppliedPpb = source.AppliedPpb;
        destination.RecommendedPpb = source.RecommendedPpb;

        destination.Kind = source.Kind;
        destination.Reason = source.Reason;
        destination.Classification = source.Classification;
        destination.ConsecutiveTimeout = source.ConsecutiveTimeout;
        destination.AttemptCount = source.AttemptCount;
        destination.CoarseWaitCount = source.CoarseWaitCount;
        destination.EventSignaledCount = source.EventSignaledCount;
        destination.EventTimeoutCount = source.EventTimeoutCount;
        destination.EventFailedCount = source.EventFailedCount;
        destination.EventFallbackSleepCount = source.EventFallbackSleepCount;
        destination.LastEventResult = source.LastEventResult;
        destination.LastEventError = source.LastEventError;
        destination.NalOutcome = source.NalOutcome;
        destination.NalCallSucceeded = source.NalCallSucceeded;
        destination.NalError = source.NalError;
        destination.NalLength = source.NalLength;

        destination.RxLength = source.RxLength;
        destination.LrwWkc = source.LrwWkc;
        destination.DcWkc = source.DcWkc;
        destination.ExpectedLrwWkc = source.ExpectedLrwWkc;

        destination.ResyncAttempted = source.ResyncAttempted;
        destination.ResyncDrainCount = source.ResyncDrainCount;
        destination.ResyncDrainLimitHit = source.ResyncDrainLimitHit;
        destination.HoldMask = source.HoldMask;
        destination.TripMask = source.TripMask;
        destination.ProcessDataValid = source.ProcessDataValid;
        destination.DcTransportValid = source.DcTransportValid;
    }


    void CopyRx4bEscPort(
        SHM_ECAT_RxForensicsEscPort& destination,
        const EtherCatEscPortErrorSnapshot& source)
    {
        std::memset(
            &destination,
            0,
            sizeof(destination));

        destination.Valid = source.Valid;
        destination.SlavePosition = source.SlavePosition;
        destination.ConfiguredAddress = source.ConfiguredAddress;
        destination.BaselineValid = source.BaselineValid;

        destination.SampleTick = source.SampleTick;
        destination.InitialBaselineTick = source.InitialBaselineTick;
        destination.RxBaselineTick = source.RxBaselineTick;
        destination.EcatProcessingUnitBaselineTick = source.EcatProcessingUnitBaselineTick;
        destination.PdiBaselineTick = source.PdiBaselineTick;
        destination.LostLinkBaselineTick = source.LostLinkBaselineTick;
        destination.LastChangeTick = source.LastChangeTick;
        destination.SampleCount = source.SampleCount;
        destination.RxGroupResetCount = source.RxGroupResetCount;
        destination.EcatProcessingUnitResetCount = source.EcatProcessingUnitResetCount;
        destination.PdiResetCount = source.PdiResetCount;
        destination.LostLinkGroupResetCount = source.LostLinkGroupResetCount;
        destination.ChangeSerial = source.ChangeSerial;

        for (uint32_t port = 0u;
            port < SHM_ECAT_RX_FORENSICS_PORT_COUNT;
            ++port)
        {
            destination.InvalidFrame[port] = source.InvalidFrame[port];
            destination.PhysicalRxError[port] = source.PhysicalRxError[port];
            destination.ForwardedRxError[port] = source.ForwardedRxError[port];
            destination.LostLink[port] = source.LostLink[port];

            destination.BaselineInvalidFrame[port] = source.BaselineInvalidFrame[port];
            destination.BaselinePhysicalRxError[port] = source.BaselinePhysicalRxError[port];
            destination.BaselineForwardedRxError[port] = source.BaselineForwardedRxError[port];
            destination.BaselineLostLink[port] = source.BaselineLostLink[port];

            destination.DeltaInvalidFrame[port] = source.DeltaInvalidFrame[port];
            destination.DeltaPhysicalRxError[port] = source.DeltaPhysicalRxError[port];
            destination.DeltaForwardedRxError[port] = source.DeltaForwardedRxError[port];
            destination.DeltaLostLink[port] = source.DeltaLostLink[port];
        }

        destination.EcatProcessingUnitError = source.EcatProcessingUnitError;
        destination.PdiError = source.PdiError;
        destination.BaselineEcatProcessingUnitError = source.BaselineEcatProcessingUnitError;
        destination.BaselinePdiError = source.BaselinePdiError;
        destination.DeltaEcatProcessingUnitError = source.DeltaEcatProcessingUnitError;
        destination.DeltaPdiError = source.DeltaPdiError;

        destination.SaturatedInvalidFrameMask = source.SaturatedInvalidFrameMask;
        destination.SaturatedPhysicalRxErrorMask = source.SaturatedPhysicalRxErrorMask;
        destination.SaturatedForwardedRxErrorMask = source.SaturatedForwardedRxErrorMask;
        destination.SaturatedLostLinkMask = source.SaturatedLostLinkMask;
        destination.SaturatedMiscMask = source.SaturatedMiscMask;
    }


    bool ReadRx4bWindowSummary(
        SHM_ECAT_RxForensicsSummary& summary)
    {
        for (int attempt = 0;
            attempt < 3;
            ++attempt)
        {
            const LONG sequenceBefore =
                g_ecatRxDiagSequence;

            if (sequenceBefore == 0 ||
                (sequenceBefore & 1) != 0)
            {
                continue;
            }

            MemoryBarrier();

            summary.TotalHardTimeout =
                g_ecatRxDiagTotalHardTimeout > 0
                ? static_cast<uint64_t>(g_ecatRxDiagTotalHardTimeout)
                : 0ULL;

            summary.TotalSoftLateAccepted =
                g_ecatRxDiagTotalSoftLateAccepted > 0
                ? static_cast<uint64_t>(g_ecatRxDiagTotalSoftLateAccepted)
                : 0ULL;

            summary.RxRecentTimeout =
                g_ecatRxDiagHardTimeout > 0
                ? static_cast<uint32_t>(g_ecatRxDiagHardTimeout)
                : 0u;

            summary.RxConsecutiveTimeout =
                g_ecatRxDiagCurrentConsecutiveTimeout > 0
                ? static_cast<uint32_t>(g_ecatRxDiagCurrentConsecutiveTimeout)
                : 0u;

            summary.RxRecoveryWindow =
                g_ecatRxDiagRecoveryAfterTimeout > 0
                ? static_cast<uint32_t>(g_ecatRxDiagRecoveryAfterTimeout)
                : 0u;

            summary.RxSkipWindow =
                g_ecatRxDiagSleepCount > 0
                ? static_cast<uint32_t>(g_ecatRxDiagSleepCount)
                : 0u;

            summary.RxSoftLateWindow =
                g_ecatRxDiagSoftLateAccepted > 0
                ? static_cast<uint32_t>(g_ecatRxDiagSoftLateAccepted)
                : 0u;

            summary.QpcFailWindow =
                g_ecatRxDiagQpcFail > 0
                ? static_cast<uint32_t>(g_ecatRxDiagQpcFail)
                : 0u;

            summary.NalFrame = g_ecatRx4aNalFrame > 0 ? static_cast<uint32_t>(g_ecatRx4aNalFrame) : 0u;
            summary.NalNoData = g_ecatRx4aNalNoData > 0 ? static_cast<uint32_t>(g_ecatRx4aNalNoData) : 0u;
            summary.NalApiError = g_ecatRx4aNalApiError > 0 ? static_cast<uint32_t>(g_ecatRx4aNalApiError) : 0u;
            summary.NalInvalidLength = g_ecatRx4aNalInvalidLength > 0 ? static_cast<uint32_t>(g_ecatRx4aNalInvalidLength) : 0u;
            summary.NalUnavailable = g_ecatRx4aNalUnavailable > 0 ? static_cast<uint32_t>(g_ecatRx4aNalUnavailable) : 0u;
            summary.NalLastError = g_ecatRx4aNalLastError > 0 ? static_cast<uint32_t>(g_ecatRx4aNalLastError) : 0u;

            summary.CallOver50us = g_ecatRx4aCallOver50us > 0 ? static_cast<uint32_t>(g_ecatRx4aCallOver50us) : 0u;
            summary.CallOver100us = g_ecatRx4aCallOver100us > 0 ? static_cast<uint32_t>(g_ecatRx4aCallOver100us) : 0u;
            summary.CallOver150us = g_ecatRx4aCallOver150us > 0 ? static_cast<uint32_t>(g_ecatRx4aCallOver150us) : 0u;
            summary.CallOver200us = g_ecatRx4aCallOver200us > 0 ? static_cast<uint32_t>(g_ecatRx4aCallOver200us) : 0u;

            summary.TimeoutNoFrame = g_ecatRx4aTimeoutNoFrame > 0 ? static_cast<uint32_t>(g_ecatRx4aTimeoutNoFrame) : 0u;
            summary.TimeoutNalStall = g_ecatRx4aTimeoutNalStall > 0 ? static_cast<uint32_t>(g_ecatRx4aTimeoutNalStall) : 0u;
            summary.TimeoutLateFrame = g_ecatRx4aTimeoutLateFrame > 0 ? static_cast<uint32_t>(g_ecatRx4aTimeoutLateFrame) : 0u;

            summary.ResyncEvents = g_ecatRx4aResyncEvents > 0 ? static_cast<uint32_t>(g_ecatRx4aResyncEvents) : 0u;
            summary.ResyncFrames = g_ecatRx4aResyncFrames > 0 ? static_cast<uint32_t>(g_ecatRx4aResyncFrames) : 0u;
            summary.ResyncLimitHit = g_ecatRx4aResyncLimitHit > 0 ? static_cast<uint32_t>(g_ecatRx4aResyncLimitHit) : 0u;

            MemoryBarrier();

            const LONG sequenceAfter =
                g_ecatRxDiagSequence;

            if (sequenceBefore == sequenceAfter &&
                (sequenceAfter & 1) == 0)
            {
                return true;
            }
        }

        return false;
    }


    OSCARMAX_DIAG_NOINLINE void PublishEtherCatRxForensicsDiagnostics(
        EtherCatMaster* masterCore)
    {
        SHM_ECAT_RxForensicsData* diag =
            GetEtherCatRxForensicsSharedMemoryData();

        if (diag == nullptr ||
            masterCore == nullptr)
        {
            return;
        }

        const uint64_t latestIncidentId =
            EtherCatRx4aIncidentLatestId();

        const uint64_t escChangeSerial =
            g_ecatRx4aEscPortChangeSerial > 0
            ? static_cast<uint64_t>(g_ecatRx4aEscPortChangeSerial)
            : 0ULL;

        static SHM_ECAT_RxForensicsData* lastMapping = nullptr;
        static uint64_t lastIncidentId = 0ULL;
        static uint64_t lastEscChangeSerial = 0ULL;
        static uint32_t summaryCadence = 100u;

        constexpr uint32_t kSummaryCadenceCalls = 100u;

        const bool mappingChanged =
            lastMapping != diag;

        const bool changed =
            latestIncidentId != lastIncidentId ||
            escChangeSerial != lastEscChangeSerial;

        if (summaryCadence < kSummaryCadenceCalls)
        {
            ++summaryCadence;
        }

        const bool fullPayloadRefresh =
            mappingChanged || changed;

        const bool summaryRefresh =
            summaryCadence >= kSummaryCadenceCalls;

        if (!fullPayloadRefresh &&
            !summaryRefresh)
        {
            return;
        }

        // Fixed, process-lifetime workspaces keep the three forensic transfer
        // structures off the fixed RTX64 supervisory-thread stack. There is
        // exactly one Priority-50 caller and no recursion or re-entry.
        static SHM_ECAT_RxForensicsSummary summaryWorkspace;
        static EtherCatRxIncidentRecord incidentWorkspace;
        static EtherCatEscPortErrorSnapshot escPortWorkspace;

        std::memset(
            &summaryWorkspace,
            0,
            sizeof(summaryWorkspace));

        SHM_ECAT_RxForensicsSummary& summary =
            summaryWorkspace;

        if (!ReadRx4bWindowSummary(summary))
        {
            // A collision is benign. Do not spin in Priority-50; the next
            // 10 ms pass will naturally retry.
            return;
        }

        LARGE_INTEGER qpc = {};
        LARGE_INTEGER qpcFrequency = {};

        if (QueryPerformanceCounter(&qpc) != FALSE)
        {
            summary.CaptureQpc =
                static_cast<uint64_t>(qpc.QuadPart);
        }

        if (QueryPerformanceFrequency(&qpcFrequency) != FALSE)
        {
            summary.QpcFrequency =
                static_cast<uint64_t>(qpcFrequency.QuadPart);
        }

        summary.SchedulerRecoveryTotal =
            g_pdoRuntimeRecoveryTotalEvents > 0
            ? static_cast<uint64_t>(g_pdoRuntimeRecoveryTotalEvents)
            : 0ULL;

        summary.SchedulerSkippedCyclesTotal =
            g_pdoRuntimeRecoveryTotalSkippedCycles > 0
            ? static_cast<uint64_t>(g_pdoRuntimeRecoveryTotalSkippedCycles)
            : 0ULL;

        summary.EscPortChangeSerial =
            escChangeSerial;

        summary.PhaseErrorNs =
            static_cast<int64_t>(
                g_qpcPhasePActV0ActualErrNs);

        summary.AppliedPpb =
            static_cast<int64_t>(
                g_qpcRealFfV0AppliedPpb);

        summary.RecommendedPpb =
            static_cast<int64_t>(
                g_qpcRealFfV0RecommendedPpb);

        summary.LrwWkc =
            static_cast<int32_t>(
                g_pdoRtLrwWkc);

        summary.DcWkc =
            static_cast<int32_t>(
                g_pdoRtDcWkc);

        summary.ExpectedLrwWkc =
            static_cast<int32_t>(
                masterCore->EXPECTED_WKC_PDO);

        summary.HoldMask =
            static_cast<uint32_t>(
                g_qpcRealFfV0HoldMask);

        summary.TripMask =
            static_cast<uint32_t>(
                g_qpcRealFfV0TripMask);

        if (g_pdoRtProcessDataValid != 0)
        {
            summary.Flags |=
                SHM_ECAT_RX_FORENSICS_SUMMARY_PROCESS_DATA_VALID;
        }

        if (g_pdoRtDcTransportValid != 0)
        {
            summary.Flags |=
                SHM_ECAT_RX_FORENSICS_SUMMARY_DC_TRANSPORT_VALID;
        }

        if (summary.RxRecentTimeout == 0u &&
            summary.RxConsecutiveTimeout == 0u)
        {
            summary.Flags |=
                SHM_ECAT_RX_FORENSICS_SUMMARY_RX_HEALTHY;
        }

        if (summary.HoldMask == 0u &&
            summary.TripMask == 0u)
        {
            summary.Flags |=
                SHM_ECAT_RX_FORENSICS_SUMMARY_DC_HEALTHY;
        }

        SHM_ECAT_RxForensicsHeader& header =
            diag->Header;

        // Summary-only heartbeats retain the coherence state of the last
        // completed large payload. A changed payload starts with no retained
        // coherence bits and earns them again after all bounded reads finish.
        const uint32_t retainedPayloadFlags =
            fullPayloadRefresh
            ? 0u
            : header.Flags &
            (
                SHM_ECAT_RX_FORENSICS_FLAG_INCIDENTS_COHERENT |
                SHM_ECAT_RX_FORENSICS_FLAG_PORTS_COHERENT
                );

        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        MemoryBarrier();

        header.Magic =
            SHM_ECAT_RX_FORENSICS_MAGIC;

        header.VersionMajor =
            SHM_ECAT_RX_FORENSICS_VERSION_MAJOR;

        header.VersionMinor =
            SHM_ECAT_RX_FORENSICS_VERSION_MINOR;

        header.StructSize =
            static_cast<uint32_t>(
                sizeof(SHM_ECAT_RxForensicsData));

        header.Heartbeat++;
        header.PublishCount++;
        header.IncidentCapacity =
            SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY;
        header.SlaveCapacity =
            SHM_ECAT_RX_FORENSICS_SLAVE_CAPACITY;
        header.LatestIncidentId =
            latestIncidentId;

        header.Flags =
            SHM_ECAT_RX_FORENSICS_FLAG_PUBLISHER_ACTIVE |
            SHM_ECAT_RX_FORENSICS_FLAG_SUMMARY_COHERENT |
            retainedPayloadFlags;

        diag->Summary =
            summary;

        bool payloadCoherent =
            !fullPayloadRefresh;

        if (fullPayloadRefresh)
        {
            std::memset(
                diag->Incidents,
                0,
                sizeof(diag->Incidents));

            std::memset(
                diag->Slaves,
                0,
                sizeof(diag->Slaves));

            uint32_t incidentCount = 0u;
            uint64_t firstIncidentId = 0ULL;
            uint32_t expectedIncidentCount = 0u;

            if (latestIncidentId > 0ULL)
            {
                expectedIncidentCount =
                    latestIncidentId >
                    SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY
                    ? SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY
                    : static_cast<uint32_t>(latestIncidentId);

                const uint64_t oldestCandidate =
                    latestIncidentId >
                    SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY
                    ? latestIncidentId -
                    SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY +
                    1ULL
                    : 1ULL;

                for (uint64_t incidentId = oldestCandidate;
                    incidentId <= latestIncidentId &&
                    incidentCount < SHM_ECAT_RX_FORENSICS_INCIDENT_CAPACITY;
                    ++incidentId)
                {
                    if (!EtherCatRx4aIncidentRead(
                        incidentId,
                        &incidentWorkspace))
                    {
                        continue;
                    }

                    if (firstIncidentId == 0ULL)
                    {
                        firstIncidentId =
                            incidentWorkspace.IncidentId;
                    }

                    CopyRx4bIncident(
                        diag->Incidents[incidentCount],
                        incidentWorkspace);

                    ++incidentCount;
                }
            }

            header.IncidentCount =
                incidentCount;

            header.FirstIncidentId =
                firstIncidentId;

            const bool incidentsCoherent =
                incidentCount == expectedIncidentCount;

            if (incidentsCoherent)
            {
                header.Flags |=
                    SHM_ECAT_RX_FORENSICS_FLAG_INCIDENTS_COHERENT;
            }

            uint32_t sourceSlaveCount =
                EtherCatRx4aEscPortSlaveCount();

            if (sourceSlaveCount >
                SHM_ECAT_RX_FORENSICS_SLAVE_CAPACITY)
            {
                sourceSlaveCount =
                    SHM_ECAT_RX_FORENSICS_SLAVE_CAPACITY;
            }

            uint32_t expectedSlaveCount = 0u;

            if (masterCore->m_pEni != nullptr)
            {
                expectedSlaveCount =
                    static_cast<uint32_t>(
                        masterCore->m_pEni->GetSlaves().size());

                if (expectedSlaveCount >
                    SHM_ECAT_RX_FORENSICS_SLAVE_CAPACITY)
                {
                    expectedSlaveCount =
                        SHM_ECAT_RX_FORENSICS_SLAVE_CAPACITY;
                }
            }

            // The count reader returns zero both for a real zero-slave
            // topology and for a bounded seqlock collision. At this running
            // lifecycle point the ENI count disambiguates those cases, so a
            // collision cannot be committed as an empty coherent payload.
            const bool sourceSlaveCountCoherent =
                expectedSlaveCount == 0u ||
                sourceSlaveCount == expectedSlaveCount;

            uint32_t slaveCount = 0u;

            for (uint32_t slavePosition = 0u;
                slavePosition < sourceSlaveCount;
                ++slavePosition)
            {
                if (!EtherCatRx4aEscPortRead(
                    static_cast<uint16_t>(slavePosition),
                    &escPortWorkspace))
                {
                    continue;
                }

                CopyRx4bEscPort(
                    diag->Slaves[slaveCount],
                    escPortWorkspace);

                ++slaveCount;
            }

            header.SlaveCount =
                slaveCount;

            const bool portsCoherent =
                sourceSlaveCountCoherent &&
                slaveCount == sourceSlaveCount;

            if (portsCoherent)
            {
                header.Flags |=
                    SHM_ECAT_RX_FORENSICS_FLAG_PORTS_COHERENT;
            }

            payloadCoherent =
                incidentsCoherent && portsCoherent;
        }

        MemoryBarrier();

        InterlockedIncrement(
            reinterpret_cast<volatile LONG*>(
                &header.Sequence));

        summaryCadence = 0u;

        // A partial seqlock read is published as explicitly non-coherent and
        // retried on the next 10 ms pass. Commit the change tokens only after
        // the complete fixed payload has been captured.
        if (payloadCoherent)
        {
            lastMapping =
                diag;

            lastIncidentId =
                latestIncidentId;

            lastEscChangeSerial =
                escChangeSerial;
        }
    }
}


// ============================================================================
// DC-DIAG.1 - Priority-50 diagnostic cadence compaction
// ============================================================================
//
// The 10 ms engineering command bridge is intentionally NOT included here;
// command submit/poll responsiveness remains unchanged. This scheduler handles
// read-only diagnostic publishers only and runs at most one periodic family on
// each pass. RX forensic change tokens are checked every pass, while its large
// fixed payload is rebuilt only by the publisher's change-driven policy.
//
// 10 Hz: generic health/process image, V1A, RX correlation, SDO diagnostics
//  4 Hz: SM, FMMU and Watchdog register-shadow mirrors
// ============================================================================
namespace
{
    OSCARMAX_DIAG_NOINLINE void ReportEtherCatP64DeferredDiagnostic()
    {
        // Fixed process-lifetime workspace: no 88-byte aggregate is placed on
        // the Priority-50 stack. Normally this function exits after the token
        // comparison without formatting or output.
        static EtherCatP64DeferredDiagSnapshot snapshot{};
        static uint64_t lastEventSerial = 0ULL;

        if (!TryReadEtherCatP64DeferredDiagnostic(snapshot) ||
            snapshot.EventSerial == 0ULL ||
            snapshot.EventSerial == lastEventSerial)
        {
            return;
        }

        if (snapshot.EventSerial > lastEventSerial + 1ULL)
        {
            RtPrintf(
                "[P64-DIAG] Newest event retained | Skipped:%llu\n",
                static_cast<unsigned long long>(
                    snapshot.EventSerial - lastEventSerial - 1ULL));
        }

        lastEventSerial = snapshot.EventSerial;

        const EtherCatP64DeferredDiagKind kind =
            static_cast<EtherCatP64DeferredDiagKind>(snapshot.Kind);

        switch (kind)
        {
        case EtherCatP64DeferredDiagKind::HalBurstStart:
            RtPrintf(
                "[DC-HAL-BURST-START] Current:%llu | Base:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0),
                static_cast<unsigned long long>(snapshot.Value1));
            RtPrintf(
                "[DC-HAL-BURST-START] Command:%lld ppb\n",
                static_cast<long long>(snapshot.Value2));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstGetCountsFailed:
            RtPrintf(
                "[DC-HAL-BURST-FAULT] GetHalTimerPeriodCounts FAILED | Error:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstAltCyclesInvalid:
            RtPrintf(
                "[DC-HAL-BURST-FAULT] AltCycles invalid:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstPlan:
            RtPrintf(
                "[DC-HAL-BURST-PLAN] AltCycles:%llu | BaseCycles:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0),
                static_cast<unsigned long long>(snapshot.Value1));
            RtPrintf(
                "[DC-HAL-BURST-PLAN] Remainder:%llu | Step:%llu\n",
                static_cast<unsigned long long>(snapshot.Value2),
                static_cast<unsigned long long>(snapshot.Value3));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstSetFailed:
            RtPrintf(
                "[DC-HAL-BURST-FAULT] Set:%llu FAILED | Error:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0),
                static_cast<unsigned long long>(snapshot.Value1));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstBaseRestored:
            RtPrintf(
                "[DC-HAL-BURST-FAULT] Base restored:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstBaseRestoreFailed:
            RtPrintf(
                "[DC-HAL-BURST-FAULT] BASE RESTORE FAILED | Error:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstSummary:
            RtPrintf(
                "[DC-HAL-BURST] BaseCycles:%llu | AltCycles:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0),
                static_cast<unsigned long long>(snapshot.Value1));
            RtPrintf(
                "[DC-HAL-BURST] Duty:%llu.%03llu %% | Applied:%llu\n",
                static_cast<unsigned long long>(snapshot.Value2 / 1000LL),
                static_cast<unsigned long long>(snapshot.Value2 % 1000LL),
                static_cast<unsigned long long>(snapshot.Value3));
            RtPrintf(
                "[DC-HAL-BURST] SetOK:%llu | SetFail:%llu | Remainder:%llu\n",
                static_cast<unsigned long long>(snapshot.Value4),
                static_cast<unsigned long long>(snapshot.Value5),
                static_cast<unsigned long long>(snapshot.Value6));
            break;

        case EtherCatP64DeferredDiagKind::HalBurstDisabledBaseRestored:
            RtPrintf(
                "[DC-HAL-BURST] Actuator disabled | Base restored:%llu\n",
                static_cast<unsigned long long>(snapshot.Value0));
            break;

        case EtherCatP64DeferredDiagKind::DcSlaveSample:
            RtPrintf(
                "[DC] Servo:%lld | Slave:%lld | Diff:%lld ns\n",
                static_cast<long long>(snapshot.Value0),
                static_cast<long long>(snapshot.Value1),
                static_cast<long long>(snapshot.Value2));
            RtPrintf(
                "[DC] Delay:%llu ns | DelayWKC:%lld\n",
                static_cast<unsigned long long>(snapshot.Value3),
                static_cast<long long>(snapshot.Value4));
            RtPrintf(
                "[DC] Raw:0x%08X\n",
                static_cast<unsigned int>(snapshot.Value5));
            break;

        case EtherCatP64DeferredDiagKind::DcSlaveReadFailed:
            RtPrintf(
                "[DC] Servo:%lld | Slave:%lld | Read 0x092C FAILED\n",
                static_cast<long long>(snapshot.Value0),
                static_cast<long long>(snapshot.Value1));
            break;

        case EtherCatP64DeferredDiagKind::AsyncStateWithoutFullPdoWkc:
            RtPrintf(
                "[ASYNC-STATE-TRANSITION] ALLOW_WITHOUT_FULL_PDO_WKC | State:0x%04X\n",
                static_cast<unsigned int>(snapshot.Value0));
            RtPrintf(
                "[ASYNC-STATE-TRANSITION] LRW:%lld/%lld | DCWKC:%lld | PDOValid:NO\n",
                static_cast<long long>(snapshot.Value1),
                static_cast<long long>(snapshot.Value2),
                static_cast<long long>(snapshot.Value3));
            break;

        default:
            RtPrintf(
                "[P64-DIAG] Unknown kind:%u | Event:%llu\n",
                static_cast<unsigned int>(snapshot.Kind),
                static_cast<unsigned long long>(snapshot.EventSerial));
            break;
        }
    }


    OSCARMAX_DIAG_NOINLINE void PublishEtherCatWatchdogDiagHealthBounded(
        EtherCatMaster* masterCore)
    {
        // The legacy publisher is header-inline. This non-inline wrapper keeps
        // its local frame outside both the cadence scheduler and main loop.
        PublishEtherCatWatchdogDiagHealth(
            masterCore);
    }


    OSCARMAX_DIAG_NOINLINE void RunEtherCatDiagnosticPublishers(
        EtherCatMaster* masterCore)
    {
        if (masterCore == nullptr)
        {
            return;
        }

        // DC-DIAG.2: a cheap 10 ms token read. Text work occurs only when the
        // Priority-64 event serial changes, and remains behind a no-inline
        // frame separate from every large diagnostic publisher.
        ReportEtherCatP64DeferredDiagnostic();

        // Cheap token check every 10 ms; normally returns before taking a
        // summary or touching either large Shared Memory array.
        PublishEtherCatRxForensicsDiagnostics(
            masterCore);

        static uint32_t phase50 = 0u;

        const uint32_t phase =
            phase50;

        phase50 =
            phase >= 49u
            ? 0u
            : phase + 1u;

        switch (phase)
        {
        case 0u:
        case 10u:
        case 20u:
        case 30u:
        case 40u:
            PublishEtherCatDiagHealth(
                masterCore);
            break;

        case 2u:
        case 12u:
        case 22u:
        case 32u:
        case 42u:
            PublishEtherCatDcV1aObserverDiagnostics();
            break;

        case 4u:
        case 14u:
        case 24u:
        case 34u:
        case 44u:
            PublishEtherCatRxV1aCorrelationDiagnostics();
            break;

        case 6u:
        case 16u:
        case 26u:
        case 36u:
        case 46u:
            PublishEtherCatSdoRtDiagnostics();
            break;

        case 8u:
        case 33u:
            PublishEtherCatSmDiagHealth(
                masterCore);
            break;

        case 13u:
        case 38u:
            PublishEtherCatFmmuDiagHealth(
                masterCore);
            break;

        case 18u:
        case 43u:
            PublishEtherCatWatchdogDiagHealthBounded(
                masterCore);
            break;

        default:
            break;
        }
    }
}


int EtherCatMaster::RunRealTimeCycle_EDM_SINKER_MODE()//主要程式迴圈執行 EDM模式
{
    DEBUG_PRINT(
        "[MASTER-RUNTIME] ENTRY RunRealTimeCycle_EDM_SINKER_MODE\n");


    GlobalConfig& globalConfig = GlobalConfig::GetInstance();


    // =========================================================
    // Stage 4B - Runtime Lifecycle
    // =========================================================

    ResetRuntimeState();


    // =========================================================
    // PREPARE
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::Prepare);


    Get_TotalSlave_WKC_Count();//取得從站WKC 分數


    PassRuntimeStage(
        EtherCatRuntimeStage::Prepare);


    // =========================================================
    // START_PDO_RUNTIME
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::StartPdoRuntime);


    if (StartDcPdoRuntime() != 0)//啟動PDO作業 DC同步
    {
        FailRuntimeStage(
            EtherCatRuntimeStage::StartPdoRuntime,
            EcatRuntimeErrorPdoStart,
            "PDO_RUNTIME_START_FAILED");

        return -1;
    }


    PassRuntimeStage(
        EtherCatRuntimeStage::StartPdoRuntime);


    // =========================================================
    // START_PLC_RUNTIME
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::StartPlcRuntime);


    if (StartPLCRuntime() != 0)//啟動PLC作業 
    {
        FailRuntimeStage(
            EtherCatRuntimeStage::StartPlcRuntime,
            EcatRuntimeErrorPlcStart,
            "PLC_RUNTIME_START_FAILED");

        return -1;
    }


    PassRuntimeStage(
        EtherCatRuntimeStage::StartPlcRuntime);


    // =========================================================
    // ENTER_OP
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::EnterOp);


    bool isSuccess = PDO_SendCommandAndWait(EcatCmdType::CMD_SET_STATE, 0x0000, 0x0000, 0x00, 0x0008, 2, 1000);//廣播切換OP狀態 PDO傳送

    if (isSuccess == true)
    {
        DEBUG_PRINT("[System] System is now in OP Mode. (Success)\n");

        PassRuntimeStage(
            EtherCatRuntimeStage::EnterOp);
    }
    else
    {
        DEBUG_PRINT("[Error] Failed to switch to OP Mode! (Timeout or Error)\n");

        FailRuntimeStage(
            EtherCatRuntimeStage::EnterOp,
            EcatRuntimeErrorEnterOp,
            "ENTER_OP_FAILED");

        return -1;
    }




    // =========================================================
    // LINK_MOTION
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::LinkMotion);


    m_Motion.Link(&m_ServoList, &m_Axes);//綁定硬體指標


    // 檢查硬體數量與設定檔是否一致
    if (m_ServoList.size() != m_Axes.size())
    {
        DEBUG_PRINT("Error Servo Count !>>m_ServoList>>%d>>m_Axes>>%d\n", m_ServoList.size(), m_Axes.size());

        FailRuntimeStage(
            EtherCatRuntimeStage::LinkMotion,
            EcatRuntimeErrorServoAxisCount,
            "SERVO_AXIS_COUNT_MISMATCH");

        return -1;
    }


    PassRuntimeStage(
        EtherCatRuntimeStage::LinkMotion);


    // =========================================================
    // INIT_SHARED_MEMORY
    // =========================================================

    BeginRuntimeStage(
        EtherCatRuntimeStage::InitSharedMemory);


    //共享記憶體初始化-------------------------------------------
    if (!SHMManager::GetInstance().Initialize("EDM_SINKER_MODE"))
    {
        FailRuntimeStage(
            EtherCatRuntimeStage::InitSharedMemory,
            EcatRuntimeErrorSharedMemory,
            "SHARED_MEMORY_INITIALIZE_FAILED");

        return -1;
    }


    SHM_Data* pShm = SHMManager::GetInstance().GetData();// 把指針交給 NCManager


    if (pShm == nullptr)
    {
        FailRuntimeStage(
            EtherCatRuntimeStage::InitSharedMemory,
            EcatRuntimeErrorSharedMemory,
            "SHARED_MEMORY_POINTER_NULL");

        return -1;
    }


    PassRuntimeStage(
        EtherCatRuntimeStage::InitSharedMemory);



    m_Motion.ResetAllFaults();//全軸 清除異常狀態

    NCPLCManager ncPLCManager(*m_NC, m_Motion, m_plcManager);// PLC <-> NC Interface Manager


    // =========================================================
    // RUNNING
    // =========================================================

    MarkRuntimeRunning();


    //主控迴圈-------------------------------------------------------------
    while (1)
    {

        if (m_NC->Close_System_Com_flag == true)//關閉核心命令
        {
            MarkRuntimeStopping();


            m_NC->CoordSys.SaveAllParameters();//儲存座標系統相關參數

            // 關機前最後 Flush 一次 HOME Snapshot / History。
            HomePersistenceManager::GetInstance().FlushPending();

            g_PLC->Close_PLC();//關閉PLC作業
            SHMManager::GetInstance().Shutdown();//關閉共享記憶體


            MarkRuntimeStopped();


            DEBUG_PRINT("Close System！\n");
            return 0;
        }

        RtSleep(10);

        // DC-DIAG.1 - bounded, staggered Priority-50 diagnostic publishing.
        // The scheduler performs no EtherCAT transaction and keeps every
        // diagnostic family behind an explicit non-inline call boundary.
        RunEtherCatDiagnosticPublishers(this);

        // Stage 12F.3B.3 - non-blocking CoE/SDO engineering service bridge.
        // It only submits/polls the existing PDO-owner async command slot.
        ProcessEtherCatEngineeringService(this);

        HMI_Bridge::ProcessTask(m_NC);//高速API共享記憶體作業任務
        ncPLCManager.Process();
        m_NC->ProcessTask();//NC系統作業呼叫


        tickCount_RunRealTimeCycle += 40;
        timer_10ms += 10;
        timer_100ms += 10;
        timer_500ms += 10;   // 🌟 增加 500ms 的計時器累加
        timer_1000ms += 10;
        timer_5000ms += 10;
        timer_10000ms += 10;
        Debug_test_timer += 10; // 測試專用時間軸 


        //1s
        if (tickCount_RunRealTimeCycle % 4000 == 0)
        {
            //DEBUG_PRINT(">>> [1s] WKC:%d | Timeouts:%d | Err:%d |\n", wkc_PDO, timeout_count_PDO, wkc_error_count_PDO);
        }




        //10ms
        if (timer_10ms >= 10)
        {
            timer_10ms = 0; // 執行完立刻歸零
            timer_10ms_Count += 1;
            //DEBUG_PRINT("10ms\n");
        }

        //100ms
        if (timer_100ms >= 100)
        {
            timer_100ms = 0; // 執行完立刻歸零
            timer_100ms_Count += 1;
            HMI_Bridge::ProcessTask_100ms(m_NC); // 呼叫 100ms 任務
            //DEBUG_PRINT("100ms\n");
        }

        // 🌟 500ms 新增區塊
        if (timer_500ms >= 500)
        {
            timer_500ms = 0;
            timer_500ms_Count += 1;
            HMI_Bridge::ProcessTask_500ms(m_NC); // 呼叫 500ms 任務
        }

        //1000ms
        if (timer_1000ms >= 1000)
        {
            timer_1000ms = 0; // 執行完立刻歸零
            timer_1000ms_Count += 1;
            HMI_Bridge::ProcessTask_1000ms(m_NC); // 呼叫 1000ms 任務

            // HOME 成功時 HomingManager 只 Queue 記憶體資料。
            // 這裡以 1000ms 低頻率寫入 Snapshot / History，
            // 避免在 HOME State Machine 當下直接做磁碟 I/O。
            HomePersistenceManager::GetInstance().FlushPending();

            //DEBUG_PRINT("1000ms\n");


            //PrintDcRuntimeDiagnostics();//DC診斷訊息


            // Stage 11C.9:
            // Low-frequency compatibility retirement diagnostics.
            //
            // This is the existing 1000ms supervisory loop, NOT the
            // 250us PDO loop and NOT PlcCore's 1ms input bridge.
            //m_Plc.PrintGenericInputCompatibilityRetirementShadow();
        }

        //5000ms
        if (timer_5000ms >= 5000)
        {
            timer_5000ms = 0; // 執行完立刻歸零
            timer_5000ms_Count += 1;

            //DEBUG_PRINT("5000ms\n");


            //PrintDcRuntimeDiagnostics();//DC診斷訊息
        }

        //10000ms
        if (timer_10000ms >= 10000)
        {
            timer_10000ms = 0; // 執行完立刻歸零
            timer_10000ms_Count += 1;

            //DEBUG_PRINT("5000ms\n");



        }

        if (Debug_test_timer >= 1000)
        {
            Debug_test_timer = 0; // 執行完立刻歸零
            Debug_test_timer_Count += 1;
            //DEBUG_PRINT("Debug_test_timer ms\n");
        }

    }



}
