// ==========================================================
// �ɮסGNCManager_PLCSync.cpp
// �\��G�B�z NCManager �N�j���P�b���A�P�B�� PLC �� S �I
// ==========================================================

#include "NCManager.h"
#include "MotionCore.h"
#include "PLCManager.h"
#include "NCPLCMap.h"
#include "AlarmManager.h"

extern PLCManager* g_PLC; // �ޤJ PLC �j��

void NCManager::SyncNCStateToPLC()
{
    if (g_PLC == nullptr) return; // ���b

    // =========================================================
    // 1. ���x��X���A (S0 ~ S5)
    // =========================================================
    g_PLC->Set_S(0, (m_edmState == EDMState::READY || m_edmState == EDMState::START)); // �t�γƧ�
    g_PLC->Set_S(1, (m_edmState == EDMState::START)); // ���椤
    g_PLC->Set_S(2, (m_edmState == EDMState::HOLD));  // �Ȱ���
    g_PLC->Set_S(3, (m_state == NCState::P_END));     // �{������
    g_PLC->Set_S(4, (m_state == NCState::RESET_STATE)); // �t�έ��m��
    g_PLC->Set_S(5, AlarmManager::GetInstance().HasAlarm()); // �t��ĵ����

    // =========================================================
    // 2. �ާ@�Ҧ����A (S10 ~ S13)
    // =========================================================
    g_PLC->Set_S(10, (m_mode == NCOperationMode::MEMORY));
    g_PLC->Set_S(11, (m_mode == NCOperationMode::MDI));
    g_PLC->Set_S(12, (m_mode == NCOperationMode::MANUAL));
    g_PLC->Set_S(13, (m_mode == NCOperationMode::EDIT));

    // =========================================================
    // 3. NC �\��ҥΪ��A (S20 ~ S26) - �o�Ǳz�i�H����A���W UI �ܼ�
    // =========================================================
    g_PLC->Set_S(20, m_isSingleBlockEnabled);
    // g_PLC->Set_S(21, m_isDryRunEnabled);
    g_PLC->Set_S(22, m_isOptionalStopEnabled);
    g_PLC->Set_S(23, m_isBlockSkipEnabled);
    // g_PLC->Set_S(24, m_isMachineLockEnabled);
    // g_PLC->Set_S(25, m_isZAxisLockEnabled);
    // g_PLC->Set_S(26, false); // �w�d

    // =========================================================
    // 4. M/S/T �X���檬�A (S30 ~ S34)
    // =========================================================
    // �`�N�G�ثe M/S/T �X�� GCodeHandlers �B�z�A�p�G�� M �X�d������ (FIN)�A
    // �ڭ̥i�H�z�L�ˬd m_waitCallback �O�_���Ȩ�²��P�_�C
    // �p�G���ӱz���M���� M-Code Manager�A�i�H����Ū���������A�C
    bool isWaitingForMCode = (m_waitCallback != nullptr);
    g_PLC->Set_S(30, isWaitingForMCode); // M �X���ݤ�

    // (M00, M01 �o�Ǫ��A�ݭn�z�b GCodeHandlers �B�z M00 �ɳ]�w�@�ӺX�Ш�Ū��)
    // g_PLC->Set_S(33, m_isM00Active);
    // g_PLC->Set_S(34, m_isM01Active);

    // =========================================================
    // 5. G81 HOME ������檬�A
    //
    // S203 = HOME Request �٦s�b
    // S204 = Feed Hold ���b Controlled Stop
    // S205 = �w��������A���� Cycle Start Resume
    // =========================================================

    g_PLC->Set_S(
        NCPLC::S::HOME_ACTIVE,
        Homing.IsActive());

    g_PLC->Set_S(
        NCPLC::S::HOME_HOLD_DECEL,
        Homing.IsHoldDecelerating());

    g_PLC->Set_S(
        NCPLC::S::HOME_PAUSED,
        Homing.IsPaused());


    // =========================================================
    // 6. �U�b�W�ߪ��A (S100 ~ S157)
    // =========================================================
    for (int i = 0; i < 8; i++)
    {
        auto& axis = m_motion.GetAxisContext(i);

        // �u���Ӷb�s�b�ɤ~��s�A�_�h�� 0
        if (axis.isExist)
        {
            g_PLC->Set_S(100 + i, axis.isServoOn);      // S100~107: �b�ҥΪ��A
            g_PLC->Set_S(110 + i, axis.isHomed);        // S110~117: �M���I���� (�ݭn�z�b AxisContext �[�o�ܼ�)
            g_PLC->Set_S(150 + i, axis.isLagAlarm);     // S150~157: �l�H�~�t���~

            const HomeState homeState = axis.homeRuntime.state;
            const bool homeSearchSwitch = axis.homeRuntime.active &&
                (homeState == HomeState::SEARCH_SWITCH || homeState == HomeState::SWITCH_DECEL_STOP || homeState == HomeState::BACK_OFF || homeState == HomeState::VALIDATE_RELEASE || homeState == HomeState::WAIT_GROUP_BACKOFF);
            const bool homeSearchIndex = axis.homeRuntime.active &&
                (homeState == HomeState::ARM_REFERENCE || homeState == HomeState::SEARCH_INDEX || homeState == HomeState::INDEX_CAPTURED || homeState == HomeState::INDEX_DECEL_STOP || homeState == HomeState::WAIT_GROUP_INDEX_STOP);

            g_PLC->Set_S(NCPLC::S::AxisPoint(NCPLC::S::HOME_SEARCH_DOG_BASE, i), homeSearchSwitch);
            g_PLC->Set_S(NCPLC::S::AxisPoint(NCPLC::S::HOME_SEARCH_INDEX_BASE, i), homeSearchIndex);

            // =====================================================
            // Software Travel Limit Warning State
            //
            // S210~217 = +Software Limit
            // S220~227 = -Software Limit
            //
            // �u���� PLC / HMI ���ĵ�T�C
            // ���i AlarmManager�C
            // =====================================================

            const bool softwarePositiveLimit =
                axis.travelLimit1PositiveActive ||
                axis.travelLimit2PositiveActive ||
                axis.travelLimit3PositiveActive;

            const bool softwareNegativeLimit =
                axis.travelLimit1NegativeActive ||
                axis.travelLimit2NegativeActive ||
                axis.travelLimit3NegativeActive;

            g_PLC->Set_S(
                NCPLC::S::AxisPoint(
                    NCPLC::S::SOFTWARE_POSITIVE_LIMIT_BASE,
                    i),
                softwarePositiveLimit);

            g_PLC->Set_S(
                NCPLC::S::AxisPoint(
                    NCPLC::S::SOFTWARE_NEGATIVE_LIMIT_BASE,
                    i),
                softwareNegativeLimit);
        }
        else
        {
            g_PLC->Set_S(100 + i, false);
            g_PLC->Set_S(110 + i, false);
            g_PLC->Set_S(150 + i, false);
            g_PLC->Set_S(NCPLC::S::AxisPoint(NCPLC::S::HOME_SEARCH_DOG_BASE, i), false);
            g_PLC->Set_S(NCPLC::S::AxisPoint(NCPLC::S::HOME_SEARCH_INDEX_BASE, i), false);

            g_PLC->Set_S(
                NCPLC::S::AxisPoint(
                    NCPLC::S::SOFTWARE_POSITIVE_LIMIT_BASE,
                    i),
                false);

            g_PLC->Set_S(
                NCPLC::S::AxisPoint(
                    NCPLC::S::SOFTWARE_NEGATIVE_LIMIT_BASE,
                    i),
                false);
        }
    }
}