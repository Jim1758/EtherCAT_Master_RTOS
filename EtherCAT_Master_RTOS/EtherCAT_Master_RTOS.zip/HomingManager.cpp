#include "HomingManager.h"
#include "MotionCore.h"
#include "NCManager.h"
#include "AlarmManager.h"
#include "HomePersistenceManager.h"
#include "PLCManager.h"
#include "NCPLCMap.h"
#include <cmath>
#include <rtapi.h>
#include <rtssapi.h>

namespace
{
    // ========================================================
    // HOME Error -> Alarm Code
    //
    // HomeErrorReason�G
    //     HomingManager �������Բӥ��ѭ�]�C
    //
    // Alarm Code�G
    //     ���� NC / HMI / Alarm History �ϥΡC
    //
    // �h�Ӥ�����]�i�H������P�@�ӹ�~ Alarm�C
    // ========================================================

    int GetHomeAlarmCode(
        HomeErrorReason error)
    {
        switch (error)
        {
            // ----------------------------------------------------
            // HOME �Ѽ� / �Ұʱ�����~
            // ----------------------------------------------------

        case HomeErrorReason::INVALID_CONFIG:
        case HomeErrorReason::AXIS_NOT_EXIST:

            return
                AlarmManager::HOME_INVALID_CONFIG;


            // ----------------------------------------------------
            // �䤣�� DOG / �w����V LIMIT
            // ----------------------------------------------------

        case HomeErrorReason::SEARCH_TIMEOUT:
        case HomeErrorReason::SEARCH_MAX_DISTANCE:
        case HomeErrorReason::DOG_NOT_FOUND:

            return
                AlarmManager::HOME_SEARCH_NOT_FOUND;


            // ----------------------------------------------------
            // DOG / LIMIT Ĳ�o��Ʀ�Z���L�j
            // ----------------------------------------------------

        case HomeErrorReason::SWITCH_STOP_MAX_DISTANCE:

            return
                AlarmManager::HOME_SWITCH_STOP_DISTANCE;


            // ----------------------------------------------------
            // Backoff ����
            // ----------------------------------------------------

        case HomeErrorReason::BACKOFF_TIMEOUT:
        case HomeErrorReason::BACKOFF_MAX_DISTANCE:

            return
                AlarmManager::HOME_BACKOFF_FAILED;


            // ----------------------------------------------------
            // Backoff ������T�����Ѱ�
            // ----------------------------------------------------

        case HomeErrorReason::DOG_NOT_RELEASED:

            return
                AlarmManager::HOME_DOG_NOT_RELEASED;


        case HomeErrorReason::HARD_LIMIT_NOT_RELEASED:

            return
                AlarmManager::HOME_LIMIT_NOT_RELEASED;


            // ----------------------------------------------------
            // �䤣�� INDEX
            // ----------------------------------------------------

        case HomeErrorReason::INDEX_TIMEOUT:
        case HomeErrorReason::INDEX_MAX_DISTANCE:
        case HomeErrorReason::INDEX_NOT_FOUND:

            return
                AlarmManager::HOME_INDEX_NOT_FOUND;


            // ----------------------------------------------------
            // Reference Capture �L��
            // ----------------------------------------------------

        case HomeErrorReason::REFERENCE_NOT_ARMED:
        case HomeErrorReason::REFERENCE_INVALID:

            return
                AlarmManager::HOME_REFERENCE_INVALID;


            // ----------------------------------------------------
            // HOME �L�{���줣���\�� Hard Limit
            // ----------------------------------------------------

        case HomeErrorReason::OPPOSITE_HARD_LIMIT:

            return
                AlarmManager::HOME_OPPOSITE_LIMIT;


        case HomeErrorReason::BOTH_HARD_LIMITS:

            return
                AlarmManager::HOME_BOTH_LIMITS;


            // ----------------------------------------------------
            // Servo / Motion ���沧�`
            // ----------------------------------------------------

        case HomeErrorReason::SERVO_NOT_READY:
        case HomeErrorReason::MOTION_BUSY:
        case HomeErrorReason::SERVO_FAULT:
        case HomeErrorReason::MOTION_FAULT:

            return
                AlarmManager::HOME_MOTION_FAULT;


            // ----------------------------------------------------
            // ���`�������O Alarm
            // ----------------------------------------------------

        case HomeErrorReason::CANCELLED:
        case HomeErrorReason::NONE:
        default:

            return 0;
        }
    }
}


// ============================================================
// Constructor
// ============================================================

HomingManager::HomingManager(
    MotionCore& motion)
    : m_motion(motion)
{
}


// ============================================================
// System Link
// ============================================================

void HomingManager::LinkNCManager(
    NCManager* nc)
{
    m_nc = nc;
}


void HomingManager::LinkPLCManager(
    PLCManager* plc)
{
    m_plc = plc;
}

// ============================================================================
// Stage NC-0.1F - HOME Motion Owner and RT Axis Command Mailbox
// ============================================================================
bool HomingManager::AcquireHomeMotionOwner() noexcept
{
    m_homeMotionLease = MotionOwnerLease{};
    m_returnMotionOwner = MotionOwner::NONE;

    const MotionOwnerLease currentLease = m_motion.GetMotionOwnerLease();

    if (currentLease.owner == MotionOwner::NONE)
    {
        return m_motion.TryAcquireMotionOwner(
            MotionOwner::HOME, m_homeMotionLease);
    }

    if (currentLease.owner == MotionOwner::HOME &&
        m_motion.IsMotionOwnerLeaseCurrent(currentLease))
    {
        m_homeMotionLease = currentLease;
        return true;
    }

    if (currentLease.owner == MotionOwner::AUTO ||
        currentLease.owner == MotionOwner::MDI ||
        currentLease.owner == MotionOwner::MANUAL_AUTO)
    {
        MotionOwnerLease homeLease{};
        if (!m_motion.TryTransferMotionOwner(
            currentLease, MotionOwner::HOME, homeLease))
        {
            return false;
        }

        m_returnMotionOwner = currentLease.owner;
        m_homeMotionLease = homeLease;
        return true;
    }

    return false;
}

void HomingManager::RestoreOrReleaseHomeMotionOwner() noexcept
{
    const MotionOwnerLease homeLease = m_homeMotionLease;
    const MotionOwner returnOwner = m_returnMotionOwner;

    if (!homeLease.IsValid())
    {
        m_homeMotionLease = MotionOwnerLease{};
        m_returnMotionOwner = MotionOwner::NONE;
        return;
    }

    if (!m_motion.IsMotionOwnerLeaseCurrent(homeLease))
    {
        // Safety / Reset already owns a newer Generation.
        m_homeMotionLease = MotionOwnerLease{};
        m_returnMotionOwner = MotionOwner::NONE;
        for (int i = 0; i < HOME_AXIS_COUNT; ++i)
        {
            m_pendingProbeDisarmSequence[i] =
                MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
        }
        return;
    }

    // A zero queue depth is not sufficient: RT may already have popped the
    // command but not yet applied it. Wait for each exact result before
    // changing Owner Generation.
    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        const MotionAxisCommandSequence sequence =
            m_pendingProbeDisarmSequence[i];

        if (sequence == MOTION_AXIS_COMMAND_SEQUENCE_INVALID)
        {
            continue;
        }

        MotionAxisCommandResult result{};
        if (!m_motion.TryGetAxisCommandResult(sequence, result))
        {
            return;
        }

        m_pendingProbeDisarmSequence[i] =
            MOTION_AXIS_COMMAND_SEQUENCE_INVALID;

        if (result.resultType != MotionAxisCommandResultType::APPLIED)
        {
            m_hasError = true;
            m_completed = false;
            m_lastError = HomeErrorReason::REFERENCE_INVALID;
            m_lastErrorAxis = result.axisIndex;

            if (!AlarmManager::GetInstance().HasAlarm())
            {
                AlarmManager::GetInstance().Trigger(
                    AlarmManager::HOME_MOTION_FAULT, 0, result.axisIndex);
            }

            m_motion.RequestEmergencyStopAllAxes();
            if (m_nc != nullptr)
            {
                m_nc->ChangeState(NCState::ALARM);
            }

            m_homeMotionLease = MotionOwnerLease{};
            m_returnMotionOwner = MotionOwner::NONE;
            return;
        }
    }

    if (returnOwner == MotionOwner::AUTO ||
        returnOwner == MotionOwner::MDI ||
        returnOwner == MotionOwner::MANUAL_AUTO)
    {
        MotionOwnerLease restoredLease{};
        if (m_motion.TryTransferMotionOwner(
            homeLease, returnOwner, restoredLease))
        {
            const bool adopted =
                m_nc != nullptr &&
                m_nc->AdoptProgramMotionLease(restoredLease);

            if (!adopted)
            {
                // Do not leave an owner with no corresponding NC program lease.
                m_motion.ReleaseMotionOwner(restoredLease);
            }
        }
    }
    else
    {
        m_motion.ReleaseMotionOwner(homeLease);
    }

    m_homeMotionLease = MotionOwnerLease{};
    m_returnMotionOwner = MotionOwner::NONE;
}


MotionOwnerLease HomingManager::GetProbeCommandLease() const noexcept
{
    if (m_motion.IsMotionOwnerLeaseCurrent(m_homeMotionLease))
    {
        return m_homeMotionLease;
    }

    const MotionOwnerLease currentLease = m_motion.GetMotionOwnerLease();
    if (currentLease.owner == MotionOwner::SAFETY &&
        m_motion.IsMotionOwnerLeaseCurrent(currentLease))
    {
        return currentLease;
    }

    return MotionOwnerLease{};
}

bool HomingManager::QueueHomeStop(
    int axisIndex, double decelerationTime) noexcept
{
    return m_motion.SubmitAxisStopMove(
        axisIndex, decelerationTime, MotionCommandSource::HOME,
        m_homeMotionLease);
}

bool HomingManager::QueueHomeVelocity(
    int axisIndex, double velocity, double accelerationTime) noexcept
{
    return m_motion.SubmitAxisVelocityMove(
        axisIndex, velocity, accelerationTime, MotionCommandSource::HOME,
        m_homeMotionLease);
}

bool HomingManager::QueueHomeMove(
    int axisIndex, double targetPosition, double targetVelocity,
    double accelerationTime, double decelerationTime,
    bool useShortestPath) noexcept
{
    return m_motion.SubmitAxisMoveToPosition(
        axisIndex, targetPosition, targetVelocity, accelerationTime,
        decelerationTime, useShortestPath, MotionCommandSource::HOME,
        m_homeMotionLease);
}

bool HomingManager::QueueHomeProbeFunction(
    int axisIndex, uint16_t value,
    MotionAxisCommandSequence* outSequence) noexcept
{
    const MotionOwnerLease lease = GetProbeCommandLease();
    if (!lease.IsValid()) return false;
    return m_motion.SubmitDriveTouchProbeFunction(
        axisIndex, value, lease, outSequence);
}


// ============================================================
// Start HOME Request
//
// �إߥ��� G81 / Panel HOME�G
//
// - ��b
// - P0 / P1 �Ƶ{
// - HomeRuntime
// - HOME Motion Ownership
//
// �u���� DOG / LIMIT / INDEX / Backoff �B�ʡA
// �� Process() �g���ʰ��槹�㪬�A���C
// ============================================================

bool HomingManager::Start(
    const HomeRequest& request)
{
    // �w�g�� HOME Request �b����ɡA
    // �����\�ĤG�� Request �m�����v�C
    if (m_active)
    {
        return false;
    }


    // �M���W�@�� Request �����G�C
    m_completed = false;
    m_hasError = false;
    m_cancelRequested = false;
    ClearResumeRequest();
    m_runControlState = HomeRunControlState::IDLE;

    m_lastError =
        HomeErrorReason::NONE;

    m_lastErrorAxis =
        -1;

    m_selectedAxisMask =
        0;

    m_activeAxisMask =
        0;

    m_currentOrder =
        -1;

    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        m_pendingApplyHomeSequence[i] =
            MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
        m_pendingProbeDisarmSequence[i] =
            MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
    }


    // --------------------------------------------------------
    // axisMask == 0
    //
    // �۰ʿ���G
    //
    // isExist
    // &&
    // home.enabled
    // --------------------------------------------------------

    uint8_t selectedAxisMask =
        request.axisMask;

    if (selectedAxisMask == 0)
    {
        selectedAxisMask =
            BuildEnabledAxisMask();
    }


    // �S������i HOME �b�C
    if (selectedAxisMask == 0)
    {
        m_lastError =
            HomeErrorReason::INVALID_CONFIG;

        return false;
    }


    // --------------------------------------------------------
    // ���Ҩê�l�ƥ��� Selected Axis�C
    // --------------------------------------------------------

    if (!AcquireHomeMotionOwner())
    {
        m_lastError = HomeErrorReason::MOTION_BUSY;
        return false;
    }

    if (!ValidateAndInitializeRequest(
        request,
        selectedAxisMask))
    {
        RestoreOrReleaseHomeMotionOwner();
        return false;
    }


    m_sequenceMode =
        request.sequenceMode;

    m_selectedAxisMask =
        selectedAxisMask;

    m_active =
        true;

    m_runControlState =
        HomeRunControlState::RUNNING;


    // --------------------------------------------------------
    // �ҰʲĤ@�� HOME Group�C
    //
    // P0�G
    //     ���� Selected Axis
    //
    // P1�G
    //     �̤p HomeOrder Group
    // --------------------------------------------------------

    ActivateInitialGroup();


    // �p�G�Ƶ{���S�����\��X Active Axis�A
    // ���� Request �L�ġC
    if (m_activeAxisMask == 0)
    {
        m_active =
            false;

        m_runControlState =
            HomeRunControlState::IDLE;

        m_lastError =
            HomeErrorReason::INVALID_CONFIG;

        RestoreOrReleaseHomeMotionOwner();
        return false;
    }


    return true;
}


// ============================================================
// Cyclic Process
//
// �g�����槹�� HOME State Machine�BP0/P1 Scheduler
// �P�h�b Backoff / INDEX Barrier�C
// ============================================================

void HomingManager::Process(
    double cycleTimeSec)
{
    if (!m_active)
    {
        // Completion may leave the final Probe Disarm in the mailbox.
        // Retry the owner hand-off on each 10 ms pass until RT consumes it.
        if (m_homeMotionLease.IsValid())
        {
            RestoreOrReleaseHomeMotionOwner();
        }
        return;
    }

    if (!std::isfinite(cycleTimeSec) ||
        cycleTimeSec < 0.0)
    {
        cycleTimeSec = 0.0;
    }


    // Reset / Abort �û��� Hold �u���C
    if (m_cancelRequested)
    {
        ProcessCancel();
        return;
    }


    // �~�� E-Stop / Safety / Servo Alarm �b RUNNING�BHold ��t�B
    // PAUSED ���@���A�������� HOME ���ġA���i Resume�C
    if (AlarmManager::GetInstance().HasAlarm() ||
        (m_nc != nullptr &&
            m_nc->GetState() == NCState::ALARM))
    {
        for (int i = 0;
            i < HOME_AXIS_COUNT;
            ++i)
        {
            if (!IsAxisRequested(
                m_selectedAxisMask,
                i))
            {
                continue;
            }

            AxisContext& axis =
                m_motion.GetAxisContext(i);

            if (axis.homeRuntime.completed)
            {
                continue;
            }

            SetAxisError(
                i,
                axis,
                HomeErrorReason::MOTION_FAULT);

            break;
        }

        return;
    }


    // Feed Hold�G�u�B�z Controlled Stop�BSensor / INDEX Capture�C
    // �����楿�` State Machine�A�]���֥[ State Timeout�C
    if (m_runControlState ==
        HomeRunControlState::HOLD_DECEL_STOP)
    {
        ProcessHold(cycleTimeSec);
        return;
    }


    // �����Ȱ���Ҧ� HOME Timeout �P�Z�� State Machine �ᵲ�C
    // Hard Limit / E-Stop ���� NCPLCManager::ProcessSafetyInputs() �ʱ��C
    if (m_runControlState ==
        HomeRunControlState::PAUSED)
    {
        if (m_resumeRequested)
        {
            (void)TryResumeFromPaused();
        }
        return;
    }


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        ProcessAxis(
            i,
            axis,
            cycleTimeSec);

        if (!m_active ||
            m_hasError)
        {
            return;
        }
    }


    ProcessBackoffBarrier();

    if (!m_active ||
        m_hasError)
    {
        return;
    }


    ProcessIndexStopBarrier();

    if (!m_active ||
        m_hasError)
    {
        return;
    }


    if (IsActiveGroupComplete())
    {
        AdvanceScheduler();
    }
}


// ============================================================
// Hold / Resume / Cancel / Reset
// ============================================================

bool HomingManager::RequestHold()
{
    if (!m_active ||
        m_hasError ||
        m_cancelRequested)
    {
        return false;
    }

    if (m_runControlState ==
        HomeRunControlState::HOLD_DECEL_STOP ||
        m_runControlState ==
        HomeRunControlState::PAUSED)
    {
        return true;
    }

    ClearResumeRequest();

    m_runControlState =
        HomeRunControlState::HOLD_DECEL_STOP;

    return true;
}


void HomingManager::ClearResumeRequest() noexcept
{
    m_resumeRequested = false;
    m_resumeAlarmUpdateCount = 0U;
    m_resumeAlarmIntentBaseState = 0ULL;
    m_resumeHomeMotionLease = MotionOwnerLease{};
    m_resumeAdmissionTicketValid = false;
}


HomingManager::ResumeResult HomingManager::Resume() noexcept
{
    if (!m_active ||
        m_hasError ||
        m_cancelRequested ||
        (m_runControlState !=
            HomeRunControlState::HOLD_DECEL_STOP &&
            m_runControlState !=
            HomeRunControlState::PAUSED) ||
        m_nc == nullptr ||
        !m_homeMotionLease.IsValid() ||
        !m_motion.IsMotionOwnerLeaseCurrent(m_homeMotionLease))
    {
        ClearResumeRequest();
        return ResumeResult::REJECTED;
    }

    if (!m_resumeRequested)
    {
        // Capture the button edge once.  MotionAdmissionBaseState removes only
        // a benign concurrent reservation; Alarm/Clear sequence and active
        // intent bits remain part of the immutable identity.
        AlarmManager& alarms = AlarmManager::GetInstance();
        const std::uint32_t updateBefore = alarms.GetUpdateCount();
        const std::uint64_t intentBefore =
            AlarmManager::MotionAdmissionBaseState(
                alarms.GetMotionSafetyIntentState());
        const bool alarmPresent = alarms.HasAlarm();
        const std::uint32_t updateAfter = alarms.GetUpdateCount();
        const std::uint64_t intentAfter =
            AlarmManager::MotionAdmissionBaseState(
                alarms.GetMotionSafetyIntentState());

        if (alarmPresent ||
            updateBefore != updateAfter ||
            intentBefore != intentAfter)
        {
            ClearResumeRequest();
            return ResumeResult::SUPERSEDED;
        }

        m_resumeAlarmUpdateCount = updateAfter;
        m_resumeAlarmIntentBaseState = intentAfter;
        m_resumeHomeMotionLease = m_homeMotionLease;
        m_resumeAdmissionTicketValid = true;
        m_resumeRequested = true;
    }

    if (!m_resumeAdmissionTicketValid ||
        !m_resumeHomeMotionLease.Matches(m_homeMotionLease))
    {
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    // �ާ@���i�H�b Controlled Stop �|�����������e���� Start�C
    // �Ҧ� Active Axis ������|�۰� Resume�C
    if (m_runControlState ==
        HomeRunControlState::HOLD_DECEL_STOP)
    {
        return ResumeResult::DEFERRED;
    }

    return TryResumeFromPaused();
}


void HomingManager::Cancel()
{
    if (!m_active)
    {
        return;
    }


    m_cancelRequested =
        true;
}


void HomingManager::Reset()
{
    RestoreOrReleaseHomeMotionOwner();
    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        m_pendingApplyHomeSequence[i] =
            MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
        m_pendingProbeDisarmSequence[i] =
            MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
    }

    m_sequenceMode =
        HomeSequenceMode::SIMULTANEOUS;

    m_selectedAxisMask =
        0;

    m_activeAxisMask =
        0;

    m_currentOrder =
        -1;

    m_active =
        false;

    m_completed =
        false;

    m_hasError =
        false;

    m_cancelRequested =
        false;

    ClearResumeRequest();

    m_runControlState =
        HomeRunControlState::IDLE;

    m_lastError =
        HomeErrorReason::NONE;

    m_lastErrorAxis =
        -1;


    // --------------------------------------------------------
    // �u�M�� HOME Runtime�C
    //
    // ����G
    //
    // axis.isHomed
    // MotionState
    // Position
    //
    // �]�� HomingManager Reset �������O Motion Reset�C
    // --------------------------------------------------------

    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (!axis.isExist)
        {
            continue;
        }

        DisarmDriveProbe(
            i,
            axis);

        ResetAxisRuntime(axis);
    }
}


// ============================================================
// Global State Query
// ============================================================

bool HomingManager::IsActive() const
{
    return m_active;
}


bool HomingManager::IsCompleted() const
{
    return m_completed;
}


bool HomingManager::HasError() const
{
    return m_hasError;
}


bool HomingManager::IsCancelRequested() const
{
    return m_cancelRequested;
}


bool HomingManager::IsHoldDecelerating() const
{
    return
        m_active &&
        m_runControlState ==
        HomeRunControlState::HOLD_DECEL_STOP;
}


bool HomingManager::IsPaused() const
{
    return
        m_active &&
        m_runControlState ==
        HomeRunControlState::PAUSED;
}


bool HomingManager::IsResumeRequested() const
{
    return m_resumeRequested;
}


HomeRunControlState HomingManager::GetRunControlState() const
{
    return m_runControlState;
}


// ============================================================
// Scheduler Query
// ============================================================

uint8_t HomingManager::GetSelectedAxisMask() const
{
    return m_selectedAxisMask;
}


uint8_t HomingManager::GetActiveAxisMask() const
{
    return m_activeAxisMask;
}


HomeSequenceMode HomingManager::GetSequenceMode() const
{
    return m_sequenceMode;
}


int HomingManager::GetCurrentOrder() const
{
    return m_currentOrder;
}


// ============================================================
// Error Query
// ============================================================

HomeErrorReason HomingManager::GetLastError() const
{
    return m_lastError;
}


int HomingManager::GetLastErrorAxis() const
{
    return m_lastErrorAxis;
}


// ============================================================
// Per-Axis Query
// ============================================================

bool HomingManager::IsAxisSelected(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return false;
    }


    return IsAxisRequested(
        m_selectedAxisMask,
        axisIndex);
}


bool HomingManager::IsAxisActive(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return false;
    }


    if (!IsAxisRequested(
        m_activeAxisMask,
        axisIndex))
    {
        return false;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    return
        axis.homeRuntime.active;
}


bool HomingManager::IsAxisCompleted(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return false;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    return
        axis.homeRuntime.completed;
}


bool HomingManager::IsAxisHoming(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return false;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    if (!axis.homeRuntime.selected ||
        !axis.homeRuntime.active)
    {
        return false;
    }


    if (axis.homeRuntime.state ==
        HomeState::IDLE ||
        axis.homeRuntime.state ==
        HomeState::DONE ||
        axis.homeRuntime.state ==
        HomeState::HOME_ERROR)
    {
        return false;
    }


    return true;
}


HomeState HomingManager::GetAxisState(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return
            HomeState::IDLE;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    return
        axis.homeRuntime.state;
}


HomeErrorReason HomingManager::GetAxisError(
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return
            HomeErrorReason::INVALID_CONFIG;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    return
        axis.homeRuntime.error;
}


// ============================================================
// Expected HOME Hard Limit
// ============================================================

bool HomingManager::IsExpectedPositiveHardLimit(
    int axisIndex) const
{
    return IsExpectedHomeHardLimit(
        axisIndex,
        true);
}


bool HomingManager::IsExpectedNegativeHardLimit(
    int axisIndex) const
{
    return IsExpectedHomeHardLimit(
        axisIndex,
        false);
}


bool HomingManager::IsExpectedHomeHardLimit(
    int axisIndex,
    bool positiveDirection) const
{
    if (!m_active ||
        !IsAxisHoming(axisIndex))
    {
        return false;
    }


    const AxisContext& axis =
        m_motion.GetAxisContext(
            axisIndex);


    // �u�� LIMIT_INDEX / LIMIT_ONLY
    // �~��� Physical Limit �����` HOME Event�C
    if (!UsesHardLimitSwitch(
        axis.home.method))
    {
        return false;
    }


    // HomeDirection �����P Limit ��V�ۦP�C
    if (positiveDirection)
    {
        if (axis.home.direction != 1)
        {
            return false;
        }
    }
    else
    {
        if (axis.home.direction != -1)
        {
            return false;
        }
    }


    // �u�����w HOME State �i�H�Ȯɧ�Ӥ�V
    // Hard Limit ��Ū�� HOME Event�C
    if (!IsHardLimitAllowedHomeState(
        axis.homeRuntime.state))
    {
        return false;
    }


    return true;
}


// ============================================================
// Basic Validation
// ============================================================

bool HomingManager::IsValidAxisIndex(
    int axisIndex) const
{
    return
        axisIndex >= 0 &&
        axisIndex < HOME_AXIS_COUNT;
}


bool HomingManager::IsAxisRequested(
    uint8_t axisMask,
    int axisIndex) const
{
    if (!IsValidAxisIndex(
        axisIndex))
    {
        return false;
    }


    const uint8_t bit =
        static_cast<uint8_t>(
            1u << axisIndex);


    return
        (axisMask & bit) != 0;
}


uint8_t HomingManager::BuildEnabledAxisMask() const
{
    uint8_t mask =
        0;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        const AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.isExist)
        {
            continue;
        }


        if (!axis.home.enabled)
        {
            continue;
        }


        mask |=
            static_cast<uint8_t>(
                1u << i);
    }


    return mask;
}


// ============================================================
// Request Validation / Initialization
// ============================================================

bool HomingManager::ValidateAndInitializeRequest(
    const HomeRequest& request,
    uint8_t selectedAxisMask)
{
    // --------------------------------------------------------
    // Sequence Mode ���b
    // --------------------------------------------------------

    if (request.sequenceMode !=
        HomeSequenceMode::SIMULTANEOUS &&
        request.sequenceMode !=
        HomeSequenceMode::BY_ORDER)
    {
        m_lastError =
            HomeErrorReason::INVALID_CONFIG;

        return false;
    }


    // --------------------------------------------------------
    // �Ĥ@���u�� Validation�C
    //
    // ���ҥ����q�L��~�u���ק� HomeRuntime�A
    // �קK�ˬd��@�b���ѳy�������b�w�Q�窱�A�C
    // --------------------------------------------------------

    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            selectedAxisMask,
            i))
        {
            continue;
        }


        AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.isExist)
        {
            m_lastError =
                HomeErrorReason::AXIS_NOT_EXIST;

            m_lastErrorAxis =
                i;

            return false;
        }


        if (!axis.home.enabled)
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }


        if (!axis.isServoOn)
        {
            m_lastError =
                HomeErrorReason::SERVO_NOT_READY;

            m_lastErrorAxis =
                i;

            return false;
        }


        if (axis.isFault ||
            axis.isLagAlarm ||
            axis.state ==
            MotionState::MotionState_ERROR ||
            axis.state ==
            MotionState::MotionState_ESTOP)
        {
            m_lastError =
                HomeErrorReason::SERVO_FAULT;

            m_lastErrorAxis =
                i;

            return false;
        }


        // HOME �Ĥ@���u���\�q���� IDLE ���޶b�C
        //
        // �����\�m�G
        //
        // JOG
        // MPG
        // INCH
        // G00
        // Interpolation
        // STOPPING
        if (axis.state !=
            MotionState::MotionState_IDLE)
        {
            m_lastError =
                HomeErrorReason::MOTION_BUSY;

            m_lastErrorAxis =
                i;

            return false;
        }


        if (axis.home.direction != -1 &&
            axis.home.direction != 1)
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }


        // �Ĥ@���|����@ Mechanical Stop Homing�C
        if (axis.home.method ==
            HomeMethod::MECHANICAL_STOP)
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }


        // �ݭn INDEX ���Ҧ������\ ReferenceSource = NONE�C
        if (UsesIndexReference(
            axis.home.method) &&
            axis.home.referenceSource ==
            HomeReferenceSource::NONE)
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }


        // ABSOLUTE_REFERENCE �|�����J Delta Absolute Position Provider�C
        // ���i�Ρu�ثe��m�v�� 60BA ���˦� Absolute Home�C
        if (axis.home.method ==
            HomeMethod::ABSOLUTE_REFERENCE)
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }


        if (UsesIndexReference(axis.home.method) &&
            (axis.home.referenceSource ==
                HomeReferenceSource::MOTOR_ENCODER_INDEX ||
                axis.home.referenceSource ==
                HomeReferenceSource::LINEAR_SCALE_INDEX_DRIVE) &&
            !ValidateDriveProbeConfig(axis))
        {
            m_lastError =
                HomeErrorReason::INVALID_CONFIG;

            m_lastErrorAxis =
                i;

            return false;
        }
    }


    // --------------------------------------------------------
    // �ĤG���G�������Ҧ��\��A
    // �~�إߥ��� HOME Runtime�C
    // --------------------------------------------------------

    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.isExist)
        {
            continue;
        }


        ResetAxisRuntime(axis);


        if (!IsAxisRequested(
            selectedAxisMask,
            i))
        {
            continue;
        }


        PrepareSelectedAxis(axis);
    }


    return true;
}


void HomingManager::ResetAxisRuntime(
    AxisContext& axis)
{
    axis.homeRuntime =
        HomeRuntime{};
}


void HomingManager::PrepareSelectedAxis(
    AxisContext& axis)
{
    axis.homeRuntime.selected =
        true;

    axis.homeRuntime.active =
        false;

    axis.homeRuntime.completed =
        false;

    axis.homeRuntime.error =
        HomeErrorReason::NONE;

    axis.homeRuntime.state =
        HomeState::PREPARE;


    // HOME �@�����������A
    // �ª� Machine Home �Y���ġC
    //
    // ���� CompleteAxis() ���\��~���s�]�� true�C
    //
    // �o�]�|���J�� Software Travel Limit
    // �b HOME �L�{�۰� bypass�C
    axis.isHomed =
        false;
}


// ============================================================
// P0 / P1 Scheduler
// ============================================================

void HomingManager::ActivateInitialGroup()
{
    m_activeAxisMask =
        0;


    if (m_sequenceMode ==
        HomeSequenceMode::SIMULTANEOUS)
    {
        m_currentOrder =
            -1;

        ActivateAllSelectedAxes();

        return;
    }


    const int firstOrder =
        FindLowestPendingOrder();


    if (firstOrder < 0)
    {
        return;
    }


    m_currentOrder =
        firstOrder;

    ActivateOrderGroup(
        firstOrder);
}


void HomingManager::ActivateAllSelectedAxes()
{
    m_activeAxisMask =
        0;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }


        AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.homeRuntime.selected ||
            axis.homeRuntime.completed ||
            axis.homeRuntime.error !=
            HomeErrorReason::NONE)
        {
            continue;
        }


        axis.homeRuntime.active =
            true;

        axis.homeRuntime.state =
            HomeState::PREPARE;

        axis.homeRuntime.stateElapsedSec =
            0.0;


        m_activeAxisMask |=
            static_cast<uint8_t>(
                1u << i);
    }
}


void HomingManager::ActivateOrderGroup(
    int order)
{
    m_activeAxisMask =
        0;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }


        AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.homeRuntime.selected ||
            axis.homeRuntime.completed ||
            axis.homeRuntime.error !=
            HomeErrorReason::NONE)
        {
            continue;
        }


        if (axis.home.order !=
            order)
        {
            continue;
        }


        axis.homeRuntime.active =
            true;

        axis.homeRuntime.state =
            HomeState::PREPARE;

        axis.homeRuntime.stateElapsedSec =
            0.0;


        m_activeAxisMask |=
            static_cast<uint8_t>(
                1u << i);
    }
}


int HomingManager::FindLowestPendingOrder() const
{
    int lowestOrder =
        -1;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }


        const AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.homeRuntime.selected ||
            axis.homeRuntime.completed ||
            axis.homeRuntime.active ||
            axis.homeRuntime.error !=
            HomeErrorReason::NONE)
        {
            continue;
        }


        if (lowestOrder < 0 ||
            axis.home.order <
            lowestOrder)
        {
            lowestOrder =
                axis.home.order;
        }
    }


    return lowestOrder;
}


bool HomingManager::HasPendingAxis() const
{
    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }


        const AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (axis.homeRuntime.selected &&
            !axis.homeRuntime.completed &&
            axis.homeRuntime.error ==
            HomeErrorReason::NONE &&
            !axis.homeRuntime.active)
        {
            return true;
        }
    }


    return false;
}


bool HomingManager::IsActiveGroupComplete() const
{
    if (m_activeAxisMask == 0)
    {
        return false;
    }


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }


        const AxisContext& axis =
            m_motion.GetAxisContext(i);


        if (!axis.homeRuntime.completed &&
            axis.homeRuntime.error ==
            HomeErrorReason::NONE)
        {
            return false;
        }
    }


    return true;
}


void HomingManager::AdvanceScheduler()
{
    if (m_hasError)
    {
        m_active =
            false;

        return;
    }


    // �w������ Active Group ������C
    m_activeAxisMask =
        0;


    // P0�G
    // �Ҧ� Selected Axis ���b�P�@ Group�C
    if (m_sequenceMode ==
        HomeSequenceMode::SIMULTANEOUS)
    {
        CompleteRequest();
        return;
    }


    // P1�G
    // ��U�@�ө|�������� HomeOrder�C
    if (HasPendingAxis())
    {
        const int nextOrder =
            FindLowestPendingOrder();


        if (nextOrder >= 0)
        {
            m_currentOrder =
                nextOrder;

            ActivateOrderGroup(
                nextOrder);

            return;
        }
    }


    CompleteRequest();
}


// ============================================================
// HOME Cyclic Helpers / Barriers
// ============================================================

void HomingManager::ProcessCancel()
{
    bool allStopped =
        true;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (!axis.homeRuntime.selected ||
            axis.homeRuntime.completed)
        {
            continue;
        }


        if (axis.state !=
            MotionState::MotionState_IDLE)
        {
            allStopped =
                false;

            const double dec =
                GetHoldDecTime(axis);

            if (axis.state !=
                MotionState::MotionState_STOPPING)
            {
                QueueHomeStop(i, dec);
            }
        }
    }


    if (!allStopped)
    {
        return;
    }


    bool allDisarmQueued = true;

    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (axis.homeRuntime.completed)
        {
            continue;
        }

        if (!DisarmDriveProbe(
            i,
            axis,
            true))
        {
            allDisarmQueued = false;
            continue;
        }

        axis.homeRuntime.active =
            false;

        axis.homeRuntime.selected =
            false;

        axis.homeRuntime.error =
            HomeErrorReason::CANCELLED;

        axis.homeRuntime.state =
            HomeState::IDLE;

        axis.homeRuntime.motionCommandIssued =
            false;

        axis.homeRuntime.stateTargetValid =
            false;

        axis.isHomed =
            false;
    }


    if (!allDisarmQueued)
    {
        return;
    }

    m_activeAxisMask =
        0;

    m_selectedAxisMask =
        0;

    m_active =
        false;

    m_completed =
        false;

    m_cancelRequested =
        false;

    ClearResumeRequest();

    m_runControlState =
        HomeRunControlState::IDLE;

    m_currentOrder =
        -1;

    RestoreOrReleaseHomeMotionOwner();
}


// ============================================================
// HOME Feed Hold
//
// ���n��h�G
//
// 1. m_active �O�� true�AG81 Wait Callback ���|�V�L����C
// 2. HomeState / HomeOrder / Barrier / Capture Position �����O�d�C
// 3. HOME Timeout �b HOLD_DECEL_STOP / PAUSED �������֥[�C
// 4. ��t�~�����ʬݹw�� DOG / LIMIT �P INDEX Capture�C
// ============================================================

void HomingManager::ProcessHold(
    double cycleTimeSec)
{
    (void)cycleTimeSec;

    bool allStopped =
        true;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (!axis.homeRuntime.active ||
            axis.homeRuntime.completed)
        {
            continue;
        }


        // Feed Hold ��t�����Y��n�I�� DOG / �w�� LIMIT�A
        // �����O�s�ƥ�AResume �ᤣ�i�A�� Sensor �̱��C
        if (!MonitorSwitchDuringHold(
            i,
            axis))
        {
            return;
        }


        // Feed Hold ��t�����Y��n�g�L INDEX�A
        // �����O�s 60B9/60BA �� External IO Capture�C
        if (!MonitorReferenceDuringHold(
            i,
            axis))
        {
            return;
        }


        if (axis.state !=
            MotionState::MotionState_IDLE)
        {
            allStopped =
                false;

            if (axis.state !=
                MotionState::MotionState_STOPPING)
            {
                QueueHomeStop(i, GetHoldDecTime(axis));
            }
        }
    }


    if (!allStopped)
    {
        return;
    }


    // P2P �b StopMove �� finalTargetPos �w�ܦ��Ȱ������I�C
    // �O�d stateTargetPulse�AResume �ɭ��s���e��l�ؼСC
    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (IsP2PResumeState(
            axis.homeRuntime.state) &&
            axis.homeRuntime.stateTargetValid)
        {
            axis.homeRuntime.motionCommandIssued =
                false;
        }
    }


    m_runControlState =
        HomeRunControlState::PAUSED;


    // �ާ@���i��b��t�|�������e�N���� C12�C
    if (m_resumeRequested)
    {
        (void)TryResumeFromPaused();
    }
}


HomingManager::ResumeResult HomingManager::TryResumeFromPaused() noexcept
{
    if (!m_active ||
        m_hasError ||
        m_cancelRequested ||
        m_runControlState !=
        HomeRunControlState::PAUSED ||
        !m_resumeRequested ||
        !m_resumeAdmissionTicketValid ||
        !m_resumeHomeMotionLease.IsValid() ||
        !m_resumeHomeMotionLease.Matches(m_homeMotionLease) ||
        m_nc == nullptr)
    {
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    AlarmManager& alarms = AlarmManager::GetInstance();
    AlarmManager::MotionAdmissionReservation admission{};
    const AlarmManager::MotionAdmissionResult beginResult =
        alarms.TryBeginMotionAdmission(
            m_resumeAlarmUpdateCount,
            m_resumeAlarmIntentBaseState,
            admission,
            true);
    if (beginResult ==
        AlarmManager::MotionAdmissionResult::BUSY)
    {
        return ResumeResult::DEFERRED;
    }
    if (beginResult !=
        AlarmManager::MotionAdmissionResult::ACQUIRED)
    {
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    // Revalidate all HOME/NC/Motion identities only after admission.  A
    // queued request never retargets a newer HOME owner generation.
    if (!m_active ||
        m_hasError ||
        m_cancelRequested ||
        m_runControlState !=
        HomeRunControlState::PAUSED ||
        !m_resumeRequested ||
        !m_resumeAdmissionTicketValid ||
        !m_resumeHomeMotionLease.Matches(m_homeMotionLease) ||
        !m_motion.IsMotionOwnerLeaseCurrent(m_resumeHomeMotionLease) ||
        m_nc == nullptr ||
        m_nc->GetState() != NCState::HOLD)
    {
        const bool admissionEnded =
            alarms.EndMotionAdmission(admission);
        ClearResumeRequest();
        (void)admissionEnded;
        return ResumeResult::SUPERSEDED;
    }


    int errorAxisIndex = -1;
    HomeErrorReason resumeError = HomeErrorReason::NONE;
    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);

        if (!axis.homeRuntime.active ||
            axis.homeRuntime.completed)
        {
            continue;
        }


        if (!axis.isServoOn)
        {
            errorAxisIndex = i;
            resumeError = HomeErrorReason::SERVO_NOT_READY;
            break;
        }


        if (axis.isFault ||
            axis.isLagAlarm ||
            axis.state ==
            MotionState::MotionState_ERROR ||
            axis.state ==
            MotionState::MotionState_ESTOP)
        {
            errorAxisIndex = i;
            resumeError = HomeErrorReason::MOTION_FAULT;
            break;
        }


        if (axis.state !=
            MotionState::MotionState_IDLE)
        {
            const bool admissionEnded =
                alarms.EndMotionAdmission(admission);
            if (!admissionEnded)
            {
                ClearResumeRequest();
                return ResumeResult::SUPERSEDED;
            }
            return ResumeResult::DEFERRED;
        }
    }

    if (resumeError != HomeErrorReason::NONE)
    {
        const bool admissionEnded =
            alarms.EndMotionAdmission(admission);
        AxisContext& errorAxis =
            m_motion.GetAxisContext(errorAxisIndex);
        SetAxisError(
            errorAxisIndex,
            errorAxis,
            resumeError);
        return admissionEnded
            ? ResumeResult::REJECTED
            : ResumeResult::SUPERSEDED;
    }

    if (!alarms.IsMotionAdmissionCurrent(admission) ||
        !m_active ||
        m_hasError ||
        m_cancelRequested ||
        m_runControlState !=
        HomeRunControlState::PAUSED ||
        !m_resumeRequested ||
        !m_resumeAdmissionTicketValid ||
        !m_resumeHomeMotionLease.Matches(m_homeMotionLease) ||
        !m_motion.IsMotionOwnerLeaseCurrent(m_resumeHomeMotionLease) ||
        m_nc == nullptr ||
        m_nc->GetState() != NCState::HOLD)
    {
        const bool admissionEnded =
            alarms.EndMotionAdmission(admission);
        ClearResumeRequest();
        (void)admissionEnded;
        return ResumeResult::SUPERSEDED;
    }

    // Validation and mutation are intentionally separate.  No earlier axis
    // receives a partial PID reset when a later axis is still stopping.
    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_activeAxisMask,
            i))
        {
            continue;
        }

        AxisContext& axis =
            m_motion.GetAxisContext(i);
        if (!axis.homeRuntime.active ||
            axis.homeRuntime.completed)
        {
            continue;
        }

        // Bumpless Resume�G���� Search / Backoff / Index �_�I�A
        // �u�M�� PID ���v�A�קK�Ȱ������ݯd�n���y���_�B��i�C
        axis.pid.prevError =
            0.0;

        axis.pid.integralAcc =
            0.0;
    }

    // Reset/Alarm-independent owner and NC transitions are not covered by the
    // Alarm word.  Re-prove them at the final mutation seam as well.
    if (!alarms.IsMotionAdmissionCurrent(admission) ||
        !m_motion.IsMotionOwnerLeaseCurrent(m_resumeHomeMotionLease) ||
        m_nc == nullptr ||
        m_nc->GetState() != NCState::HOLD)
    {
        (void)alarms.EndMotionAdmission(admission);
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    // NC owns the state CAS.  Its lease -> HOLD/RUN CAS -> lease proof makes a
    // concurrent Reset/Alarm state win without a raw store from HOME.
    if (!m_nc->TryCommitHomingResume(m_resumeHomeMotionLease))
    {
        (void)alarms.EndMotionAdmission(admission);
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    m_runControlState =
        HomeRunControlState::RUNNING;
    if (m_nc->GetState() != NCState::RUN ||
        !m_motion.IsMotionOwnerLeaseCurrent(m_resumeHomeMotionLease))
    {
        m_runControlState =
            HomeRunControlState::PAUSED;
        m_nc->TryRollbackHomingResume();
        (void)alarms.EndMotionAdmission(admission);
        ClearResumeRequest();
        return ResumeResult::SUPERSEDED;
    }

    ClearResumeRequest();

    if (!alarms.EndMotionAdmission(admission))
    {
        // RUN was only provisional while the reservation was held.  No NC
        // dispatch can occur inside this HOME call.  Restore HOLD before
        // returning and force the overlapping Alarm to remain fail-closed.
        if (m_active &&
            !m_hasError &&
            !m_cancelRequested)
        {
            m_runControlState =
                HomeRunControlState::PAUSED;
        }
        m_nc->TryRollbackHomingResume();
        m_motion.RequestEmergencyStopAllAxes();
        return ResumeResult::SUPERSEDED;
    }

    return ResumeResult::APPLIED;
}


double HomingManager::GetHoldDecTime(
    const AxisContext& axis) const
{
    switch (axis.homeRuntime.state)
    {
    case HomeState::SEARCH_SWITCH:
    case HomeState::SWITCH_DECEL_STOP:

        return
            axis.home.switchStopDecTime;


    case HomeState::SEARCH_INDEX:
    case HomeState::INDEX_CAPTURED:
    case HomeState::INDEX_DECEL_STOP:

        return
            axis.home.indexStopDecTime;


    case HomeState::BACK_OFF:

        return
            axis.home.backoffDecTime;


    case HomeState::MOVE_TO_ZERO:

        return
            axis.home.moveToZeroDecTime;


    default:

        return
            axis.home.searchDecTime;
    }
}


bool HomingManager::IsP2PResumeState(
    HomeState state) const
{
    return
        state == HomeState::BACK_OFF ||
        state == HomeState::MOVE_TO_ZERO;
}


bool HomingManager::MonitorSwitchDuringHold(
    int axisIndex,
    AxisContext& axis)
{
    if (axis.homeRuntime.state !=
        HomeState::SEARCH_SWITCH)
    {
        return true;
    }


    if (axis.hardLimitPositive &&
        axis.hardLimitNegative)
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::BOTH_HARD_LIMITS);

        return false;
    }


    if (UsesDogSwitch(
        axis.home.method))
    {
        if (axis.hardLimitPositive ||
            axis.hardLimitNegative)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::OPPOSITE_HARD_LIMIT);

            return false;
        }
    }
    else if (UsesHardLimitSwitch(
        axis.home.method))
    {
        const bool oppositeLimit =
            (axis.home.direction > 0 &&
                axis.hardLimitNegative) ||
            (axis.home.direction < 0 &&
                axis.hardLimitPositive);

        if (oppositeLimit)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::OPPOSITE_HARD_LIMIT);

            return false;
        }
    }


    bool switchActive =
        false;

    if (!ReadHomeSwitch(
        axisIndex,
        axis,
        switchActive))
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::INVALID_CONFIG);

        return false;
    }


    if (!switchActive)
    {
        return true;
    }


    axis.homeRuntime.switchDetectedPulse =
        m_motion.GetRawLogicalPositionPulse(axis);

    axis.homeRuntime.dogDetected =
        UsesDogSwitch(axis.home.method);

    EnterState(
        axis,
        HomeState::SWITCH_DECEL_STOP);

    return true;
}


bool HomingManager::MonitorReferenceDuringHold(
    int axisIndex,
    AxisContext& axis)
{
    if (axis.homeRuntime.state !=
        HomeState::SEARCH_INDEX)
    {
        return true;
    }


    if (!axis.homeRuntime.referenceArmed)
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::REFERENCE_NOT_ARMED);

        return false;
    }


    if (axis.hardLimitPositive &&
        axis.hardLimitNegative)
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::BOTH_HARD_LIMITS);

        return false;
    }


    if (axis.hardLimitPositive ||
        axis.hardLimitNegative)
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::OPPOSITE_HARD_LIMIT);

        return false;
    }


    bool detected =
        false;

    double captured =
        0.0;


    if (axis.home.referenceSource ==
        HomeReferenceSource::EXTERNAL_IO_INDEX)
    {
        bool active =
            false;

        if (!ReadExternalReferenceInput(
            axisIndex,
            axis,
            active))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_INVALID);

            return false;
        }


        detected =
            active &&
            !axis.homeRuntime.previousReferenceInput;

        axis.homeRuntime.previousReferenceInput =
            active;


        if (detected)
        {
            captured =
                m_motion.GetRawLogicalPositionPulse(axis);
        }
    }
    else
    {
        if (!TryCaptureDriveProbe(
            axisIndex,
            axis,
            detected,
            captured))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_INVALID);

            return false;
        }
    }


    if (!detected)
    {
        return true;
    }


    axis.homeRuntime.capturedReferencePulse =
        captured;

    axis.homeRuntime.referenceDetected =
        true;

    EnterState(
        axis,
        HomeState::INDEX_DECEL_STOP);

    return true;
}

void HomingManager::ProcessBackoffBarrier()
{
    bool any = false;
    bool all = true;
    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        if (!IsAxisRequested(m_activeAxisMask, i)) continue;
        const HomeState state = m_motion.GetAxisContext(i).homeRuntime.state;
        if (state == HomeState::WAIT_GROUP_BACKOFF) any = true;
        else all = false;
    }
    if (!any || !all) return;

    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        if (!IsAxisRequested(m_activeAxisMask, i)) continue;
        AxisContext& axis = m_motion.GetAxisContext(i);
        axis.homeRuntime.waitingGroupBarrier = false;
        if (UsesIndexReference(axis.home.method))
            EnterState(axis, HomeState::ARM_REFERENCE);
        else
            EnterState(axis, HomeState::APPLY_HOME);
    }
}

void HomingManager::ProcessIndexStopBarrier()
{
    bool any = false;
    bool all = true;
    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        if (!IsAxisRequested(m_activeAxisMask, i)) continue;
        const AxisContext& axis = m_motion.GetAxisContext(i);
        if (!UsesIndexReference(axis.home.method)) continue;
        any = true;
        if (axis.homeRuntime.state != HomeState::WAIT_GROUP_INDEX_STOP) all = false;
    }
    if (!any || !all) return;

    for (int i = 0; i < HOME_AXIS_COUNT; ++i)
    {
        if (!IsAxisRequested(m_activeAxisMask, i)) continue;
        AxisContext& axis = m_motion.GetAxisContext(i);
        if (UsesIndexReference(axis.home.method)) EnterState(axis, HomeState::APPLY_HOME);
    }
}

bool HomingManager::ReadHomeSwitch(int axisIndex, AxisContext& axis, bool& active) const
{
    active = false;
    if (UsesDogSwitch(axis.home.method))
    {
        if (m_plc == nullptr) return false;
        const bool raw = m_plc->Get_C(NCPLC::C::AxisPoint(NCPLC::C::HOME_DOG_BASE, axisIndex));
        active = axis.home.dogActiveHigh ? raw : !raw;
        axis.homeRuntime.previousDogInput = raw;
        return true;
    }
    if (UsesHardLimitSwitch(axis.home.method))
    {
        active = axis.home.direction > 0 ? axis.hardLimitPositive : axis.hardLimitNegative;
        return true;
    }
    return false;
}

bool HomingManager::ReadExternalReferenceInput(int axisIndex, const AxisContext& axis, bool& active) const
{
    active = false;
    if (m_plc == nullptr) return false;
    const int cPoint = axis.home.externalReferenceCPoint >= 0
        ? axis.home.externalReferenceCPoint
        : NCPLC::C::AxisPoint(NCPLC::C::HOME_INDEX_BASE, axisIndex);
    const bool raw = m_plc->Get_C(cPoint);
    active = axis.home.referenceActiveHigh ? raw : !raw;
    return true;
}

// ============================================================
// Drive Touch Probe Provider
//
// 0x60B8�GController -> Drive
// 0x60B9�GDrive -> Controller Status
// 0x60BA�GDrive -> Controller Positive Edge Capture Position
//
// Bit values are parameterized in HomeConfig.  The state machine does not
// scatter Delta-specific magic numbers through the motion logic.
// ============================================================

bool HomingManager::UsesDriveTouchProbe(
    const AxisContext& axis) const
{
    return
        axis.home.captureMode ==
        HomeReferenceCaptureMode::DRIVE_HARDWARE_LATCH &&
        (axis.home.referenceSource ==
            HomeReferenceSource::MOTOR_ENCODER_INDEX ||
            axis.home.referenceSource ==
            HomeReferenceSource::LINEAR_SCALE_INDEX_DRIVE);
}


bool HomingManager::ValidateDriveProbeConfig(
    const AxisContext& axis) const
{
    if (!UsesDriveTouchProbe(axis))
    {
        return true;
    }

    if (axis.home.driveProbeArmMode !=
        HomeDriveProbeArmMode::CONTROLLER_60B8 &&
        axis.home.driveProbeArmMode !=
        HomeDriveProbeArmMode::DRIVE_AUTO_ARM)
    {
        return false;
    }

    if (axis.home.driveProbeCapturedMask == 0 &&
        axis.home.driveProbeCaptureToggleMask == 0 &&
        !axis.home.driveProbeAllowPositionChangeDetection)
    {
        return false;
    }

    if (!std::isfinite(
        axis.home.driveProbeClearTimeoutSec) ||
        !std::isfinite(
            axis.home.driveProbeArmTimeoutSec) ||
        axis.home.driveProbeClearTimeoutSec < 0.0 ||
        axis.home.driveProbeArmTimeoutSec < 0.0)
    {
        return false;
    }

    if (axis.home.driveProbeArmMode ==
        HomeDriveProbeArmMode::CONTROLLER_60B8)
    {
        if (axis.home.driveProbeArmValue ==
            axis.home.driveProbeDisarmValue)
        {
            return false;
        }

        if (axis.home.driveProbeRequireArmedStatus &&
            axis.home.driveProbeArmedMask == 0)
        {
            return false;
        }

        if (axis.home.driveProbeClearTimeoutSec <= 0.0 ||
            axis.home.driveProbeArmTimeoutSec <= 0.0)
        {
            return false;
        }
    }

    return true;
}


bool HomingManager::IsDriveProbeSourceStatusValid(
    const AxisContext& axis,
    uint16_t status) const
{
    if (axis.home.driveProbeSourceMask == 0)
    {
        return true;
    }

    return
        (status & axis.home.driveProbeSourceMask) ==
        (axis.home.driveProbeExpectedSourceValue &
            axis.home.driveProbeSourceMask);
}


void HomingManager::ResetDriveProbeRuntime(
    AxisContext& axis)
{
    axis.homeRuntime.driveProbePhase =
        HomeDriveProbePhase::IDLE;

    axis.homeRuntime.driveProbePhaseElapsedSec =
        0.0;

    axis.homeRuntime.driveProbeBaselineStatus =
        0;

    axis.homeRuntime.driveProbeBaselinePosition =
        0;

    axis.homeRuntime.driveProbeLastFunction =
        0;

    axis.homeRuntime.driveProbeLastStatus =
        0;

    axis.homeRuntime.driveProbeLastPosition =
        0;

    axis.homeRuntime.driveProbeControlWritten =
        false;

    axis.homeRuntime.driveProbeClearConfirmed =
        false;

    axis.homeRuntime.driveProbeArmedConfirmed =
        false;

    axis.homeRuntime.driveProbeCaptureConfirmed =
        false;

    axis.homeRuntime.driveProbeDisarmedAfterCapture =
        false;
}


bool HomingManager::DisarmDriveProbe(
    int axisIndex,
    AxisContext& axis,
    bool trackForOwnerRelease)
{
    if (!UsesDriveTouchProbe(axis))
    {
        return true;
    }

    if (axis.home.driveProbeArmMode !=
        HomeDriveProbeArmMode::CONTROLLER_60B8)
    {
        return true;
    }

    if (trackForOwnerRelease &&
        axisIndex >= 0 &&
        axisIndex < HOME_AXIS_COUNT &&
        m_pendingProbeDisarmSequence[axisIndex] !=
        MOTION_AXIS_COMMAND_SEQUENCE_INVALID)
    {
        return true;
    }

    MotionAxisCommandSequence sequence =
        MOTION_AXIS_COMMAND_SEQUENCE_INVALID;

    if (!QueueHomeProbeFunction(
        axisIndex,
        axis.home.driveProbeDisarmValue,
        trackForOwnerRelease ? &sequence : nullptr))
    {
        return false;
    }

    if (trackForOwnerRelease &&
        axisIndex >= 0 &&
        axisIndex < HOME_AXIS_COUNT)
    {
        m_pendingProbeDisarmSequence[axisIndex] = sequence;
    }

    axis.homeRuntime.driveProbeLastFunction =
        axis.home.driveProbeDisarmValue;

    axis.homeRuntime.driveProbeDisarmedAfterCapture =
        true;

    return true;
}


bool HomingManager::ProcessDriveProbeArm(
    int axisIndex,
    AxisContext& axis,
    double cycleTimeSec)
{
    if (!UsesDriveTouchProbe(axis) ||
        !ValidateDriveProbeConfig(axis))
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::INVALID_CONFIG);

        return false;
    }

    if (cycleTimeSec > 0.0 &&
        std::isfinite(cycleTimeSec))
    {
        axis.homeRuntime.driveProbePhaseElapsedSec +=
            cycleTimeSec;
    }

    uint16_t functionValue =
        0;

    uint16_t status =
        0;

    int32_t position =
        0;

    if (!m_motion.GetDriveTouchProbeFunction(
        axisIndex,
        functionValue) ||
        !m_motion.GetDriveTouchProbeData(
            axisIndex,
            status,
            position))
    {
        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::REFERENCE_INVALID);

        return false;
    }

    axis.homeRuntime.driveProbeLastFunction =
        functionValue;

    axis.homeRuntime.driveProbeLastStatus =
        status;

    axis.homeRuntime.driveProbeLastPosition =
        position;

    // Source Status is validated only after the probe is armed.
    // Some drives do not publish the source bit while 0x60B8 is disabled.

    // --------------------------------------------------------
    // Drive Parameter Auto Arm
    //
    // Do not write 0x60B8.  Establish a baseline and only accept a
    // new 0x60B9 event / optional 0x60BA change during SEARCH_INDEX.
    // --------------------------------------------------------

    if (axis.home.driveProbeArmMode ==
        HomeDriveProbeArmMode::DRIVE_AUTO_ARM)
    {
        if (!IsDriveProbeSourceStatusValid(
            axis,
            status))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_INVALID);

            return false;
        }

        axis.homeRuntime.driveProbeBaselineStatus =
            status;

        axis.homeRuntime.driveProbeBaselinePosition =
            position;

        axis.homeRuntime.previousTouchProbeStatus =
            status;

        axis.homeRuntime.capturedReferenceRaw =
            position;

        axis.homeRuntime.driveProbeArmedConfirmed =
            true;

        axis.homeRuntime.driveProbePhase =
            HomeDriveProbePhase::READY;

        axis.homeRuntime.referenceArmed =
            true;

        axis.homeRuntime.indexSearchStartPulse =
            m_motion.GetRawLogicalPositionPulse(axis);

        return true;
    }

    // --------------------------------------------------------
    // Controller Arm through 0x60B8
    // --------------------------------------------------------

    switch (axis.homeRuntime.driveProbePhase)
    {
    case HomeDriveProbePhase::IDLE:

        axis.homeRuntime.driveProbePhase =
            HomeDriveProbePhase::WRITE_DISARM;

        axis.homeRuntime.driveProbePhaseElapsedSec =
            0.0;

        return false;


    case HomeDriveProbePhase::WRITE_DISARM:

        if (!QueueHomeProbeFunction(
            axisIndex,
            axis.home.driveProbeDisarmValue))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_INVALID);

            return false;
        }

        axis.homeRuntime.driveProbeControlWritten =
            true;

        axis.homeRuntime.driveProbeLastFunction =
            axis.home.driveProbeDisarmValue;

        axis.homeRuntime.driveProbePhase =
            HomeDriveProbePhase::WAIT_CLEAR;

        axis.homeRuntime.driveProbePhaseElapsedSec =
            0.0;

        return false;


    case HomeDriveProbePhase::WAIT_CLEAR:
    {
        const bool captureCleared =
            (status & axis.home.driveProbeCapturedMask) == 0;

        const bool armedCleared =
            !axis.home.driveProbeRequireArmedStatus ||
            axis.home.driveProbeArmedMask == 0 ||
            (status & axis.home.driveProbeArmedMask) == 0;

        if (captureCleared &&
            armedCleared)
        {
            axis.homeRuntime.driveProbeClearConfirmed =
                true;

            axis.homeRuntime.driveProbeBaselineStatus =
                status;

            axis.homeRuntime.driveProbeBaselinePosition =
                position;

            axis.homeRuntime.driveProbePhase =
                HomeDriveProbePhase::WRITE_ARM;

            axis.homeRuntime.driveProbePhaseElapsedSec =
                0.0;

            return false;
        }

        if (axis.homeRuntime.driveProbePhaseElapsedSec >=
            axis.home.driveProbeClearTimeoutSec)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_NOT_ARMED);
        }

        return false;
    }


    case HomeDriveProbePhase::WRITE_ARM:

        if (!QueueHomeProbeFunction(
            axisIndex,
            axis.home.driveProbeArmValue))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_INVALID);

            return false;
        }

        axis.homeRuntime.driveProbeLastFunction =
            axis.home.driveProbeArmValue;

        axis.homeRuntime.driveProbePhase =
            HomeDriveProbePhase::WAIT_ARMED;

        axis.homeRuntime.driveProbePhaseElapsedSec =
            0.0;

        return false;


    case HomeDriveProbePhase::WAIT_ARMED:
    {
        const bool armed =
            !axis.home.driveProbeRequireArmedStatus ||
            axis.home.driveProbeArmedMask == 0 ||
            (status & axis.home.driveProbeArmedMask) != 0;

        const bool staleCapture =
            axis.home.driveProbeRequireNewCapture &&
            axis.home.driveProbeCapturedMask != 0 &&
            (status & axis.home.driveProbeCapturedMask) != 0;

        const bool sourceValid =
            IsDriveProbeSourceStatusValid(
                axis,
                status);

        if (armed &&
            !staleCapture &&
            sourceValid)
        {
            axis.homeRuntime.driveProbeArmedConfirmed =
                true;

            axis.homeRuntime.driveProbeBaselineStatus =
                status;

            axis.homeRuntime.driveProbeBaselinePosition =
                position;

            axis.homeRuntime.previousTouchProbeStatus =
                status;

            axis.homeRuntime.capturedReferenceRaw =
                position;

            axis.homeRuntime.driveProbePhase =
                HomeDriveProbePhase::READY;

            axis.homeRuntime.driveProbePhaseElapsedSec =
                0.0;

            axis.homeRuntime.referenceArmed =
                true;

            axis.homeRuntime.indexSearchStartPulse =
                m_motion.GetRawLogicalPositionPulse(axis);

            return true;
        }

        if (axis.homeRuntime.driveProbePhaseElapsedSec >=
            axis.home.driveProbeArmTimeoutSec)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::REFERENCE_NOT_ARMED);
        }

        return false;
    }


    case HomeDriveProbePhase::READY:

        return true;


    case HomeDriveProbePhase::CAPTURED:
    case HomeDriveProbePhase::DISARM_AFTER_CAPTURE:

        return axis.homeRuntime.referenceArmed;


    case HomeDriveProbePhase::PROBE_ERROR:
    default:

        SetAxisError(
            axisIndex,
            axis,
            HomeErrorReason::REFERENCE_INVALID);

        return false;
    }
}


bool HomingManager::TryCaptureDriveProbe(
    int axisIndex,
    AxisContext& axis,
    bool& detected,
    double& capturedPulse)
{
    detected =
        false;

    capturedPulse =
        0.0;

    if (!UsesDriveTouchProbe(axis) ||
        !axis.homeRuntime.referenceArmed)
    {
        return false;
    }

    uint16_t functionValue =
        0;

    uint16_t status =
        0;

    int32_t position =
        0;

    if (!m_motion.GetDriveTouchProbeFunction(
        axisIndex,
        functionValue) ||
        !m_motion.GetDriveTouchProbeData(
            axisIndex,
            status,
            position))
    {
        return false;
    }

    axis.homeRuntime.driveProbeLastFunction =
        functionValue;

    axis.homeRuntime.driveProbeLastStatus =
        status;

    axis.homeRuntime.driveProbeLastPosition =
        position;

    if (!IsDriveProbeSourceStatusValid(
        axis,
        status))
    {
        return false;
    }

    const uint16_t previousStatus =
        axis.homeRuntime.previousTouchProbeStatus;

    const bool capturedLevel =
        axis.home.driveProbeCapturedMask != 0 &&
        (status & axis.home.driveProbeCapturedMask) != 0;

    const bool previousCapturedLevel =
        axis.home.driveProbeCapturedMask != 0 &&
        (previousStatus & axis.home.driveProbeCapturedMask) != 0;

    const bool captureRisingEdge =
        capturedLevel &&
        !previousCapturedLevel;

    const bool captureToggleChanged =
        axis.home.driveProbeCaptureToggleMask != 0 &&
        ((status ^ previousStatus) &
            axis.home.driveProbeCaptureToggleMask) != 0;

    const bool positionChanged =
        axis.home.driveProbeAllowPositionChangeDetection &&
        position != axis.homeRuntime.capturedReferenceRaw;

    if (axis.home.driveProbeRequireNewCapture)
    {
        detected =
            captureRisingEdge ||
            captureToggleChanged ||
            positionChanged;
    }
    else
    {
        detected =
            capturedLevel ||
            captureToggleChanged ||
            positionChanged;
    }

    axis.homeRuntime.previousTouchProbeStatus =
        status;

    if (!detected)
    {
        return true;
    }

    axis.homeRuntime.capturedReferenceRaw =
        position;

    axis.homeRuntime.driveProbeCaptureConfirmed =
        true;

    axis.homeRuntime.driveProbePhase =
        HomeDriveProbePhase::CAPTURED;

    capturedPulse =
        m_motion.ConvertDriveCaptureToRawLogicalPulse(
            axisIndex,
            position,
            axis.home.referenceSource);

    if (!std::isfinite(capturedPulse))
    {
        return false;
    }

    if (axis.home.driveProbeDisarmAfterCapture)
    {
        DisarmDriveProbe(
            axisIndex,
            axis);

        axis.homeRuntime.driveProbePhase =
            HomeDriveProbePhase::DISARM_AFTER_CAPTURE;
    }

    return true;
}


double HomingManager::GetPulsePerUnit(const AxisContext& axis) const
{
    if (axis.resolution_PPR <= 0.0 || std::abs(axis.finalLead) < 1.0e-12) return 0.0;
    return axis.resolution_PPR / std::abs(axis.finalLead);
}

double HomingManager::GetTravelDistanceUnit(const AxisContext& axis, double startRawPulse) const
{
    const double ppu = GetPulsePerUnit(axis);
    if (ppu <= 0.0) return 0.0;
    return std::abs(m_motion.GetRawLogicalPositionPulse(axis) - startRawPulse) / ppu;
}

void HomingManager::EnterState(AxisContext& axis, HomeState state)
{
    axis.homeRuntime.state = state;
    axis.homeRuntime.stateElapsedSec = 0.0;
    axis.homeRuntime.motionCommandIssued = false;
    axis.homeRuntime.stateTargetValid = false;
    axis.homeRuntime.stateTargetPulse = 0.0;

    if (state == HomeState::ARM_REFERENCE)
    {
        ResetDriveProbeRuntime(axis);
    }
}

// ============================================================
// Per-Axis HOME State Machine
//
// PREPARE -> SEARCH_SWITCH -> SWITCH_DECEL_STOP
// -> BACK_OFF -> VALIDATE_RELEASE -> Group Barrier
// -> ARM_REFERENCE -> SEARCH_INDEX -> INDEX_DECEL_STOP
// -> Group Barrier -> APPLY_HOME -> Optional MOVE_TO_ZERO
// ============================================================

void HomingManager::ProcessAxis(
    int axisIndex,
    AxisContext& axis,
    double cycleTimeSec)
{
    if (!axis.homeRuntime.active)
    {
        return;
    }


    axis.homeRuntime.stateElapsedSec +=
        cycleTimeSec;


    // ========================================================
    // PREPARE
    //
    // �o�@���q�u���G
    //
    // 1. �A���T�{ HOME �ѼƦw��
    // 2. �إߥ��� HOME Runtime �_�l�ַ�
    // 3. �� HomeMethod �M�w�U�@�� State
    //
    // �o�̡u���|�v�U�F���� Motion�C
    // ========================================================

    if (axis.homeRuntime.state ==
        HomeState::PREPARE)
    {
        // ----------------------------------------------------
        // A. Runtime �򥻪��A�A���T�{
        //
        // Start() �� Process() �����Y�Ϫ��A�o���ܤơA
        // �]���ઽ���i�J HOME Motion�C
        // ----------------------------------------------------

        if (!axis.isExist)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::AXIS_NOT_EXIST);

            return;
        }


        if (!axis.home.enabled)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        if (!axis.isServoOn)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::SERVO_NOT_READY);

            return;
        }


        if (axis.isFault ||
            axis.isLagAlarm ||
            axis.state ==
            MotionState::MotionState_ERROR ||
            axis.state ==
            MotionState::MotionState_ESTOP)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::SERVO_FAULT);

            return;
        }


        if (axis.state !=
            MotionState::MotionState_IDLE)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::MOTION_BUSY);

            return;
        }


        if (axis.home.direction != -1 &&
            axis.home.direction != 1)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        // HOME �Z���P�t�״��ⳣ�̿� Encoder Resolution
        // �P Final Lead�A�o��Ӿ���Ѽƥ������ġC
        if (!std::isfinite(axis.resolution_PPR) ||
            !std::isfinite(axis.finalLead) ||
            axis.resolution_PPR <= 0.0 ||
            std::abs(axis.finalLead) < 1.0e-12)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        // ----------------------------------------------------
        // B. �@�ΰѼƨ��b
        // ----------------------------------------------------

        auto IsPositiveFinite =
            [](double value) -> bool
        {
            return
                std::isfinite(value) &&
                value > 0.0;
        };


        auto IsNonNegativeFinite =
            [](double value) -> bool
        {
            return
                std::isfinite(value) &&
                value >= 0.0;
        };


        const bool usesSwitch =
            UsesDogSwitch(
                axis.home.method) ||
            UsesHardLimitSwitch(
                axis.home.method);


        const bool usesIndex =
            UsesIndexReference(
                axis.home.method);


        // ----------------------------------------------------
        // C. DOG / LIMIT Search �Ѽ�
        //
        // �ݭn�j�M Switch ���Ҧ��G
        //
        // DOG_INDEX
        // LIMIT_INDEX
        // DOG_ONLY
        // LIMIT_ONLY
        //
        // ������ơG
        //
        // Search Speed
        // Search Max Distance
        // Controlled Stop Dec Time
        // Backoff Speed
        // Backoff Max Distance
        // ----------------------------------------------------

        if (usesSwitch)
        {
            if (!IsPositiveFinite(
                axis.home.searchSpeed_PPS) ||
                !IsPositiveFinite(
                    axis.home.searchMaxDistance_unit) ||
                !IsPositiveFinite(
                    axis.home.switchStopDecTime) ||
                !IsPositiveFinite(
                    axis.home.backoffSpeed_PPS) ||
                !IsPositiveFinite(
                    axis.home.backoffMaxDistance_unit))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            if (!IsNonNegativeFinite(
                axis.home.searchTimeoutSec) ||
                !IsNonNegativeFinite(
                    axis.home.switchStopMaxDistance_unit) ||
                !IsNonNegativeFinite(
                    axis.home.backoffTimeoutSec))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            // ------------------------------------------------
            // Backoff Mode �M�ζZ���ˬd
            // ------------------------------------------------

            if (axis.home.backoffMode ==
                HomeBackoffMode::FIXED_DISTANCE)
            {
                if (!IsPositiveFinite(
                    axis.home.backoffDistance_unit))
                {
                    SetAxisError(
                        axisIndex,
                        axis,
                        HomeErrorReason::INVALID_CONFIG);

                    return;
                }
            }
            else if (axis.home.backoffMode ==
                HomeBackoffMode::UNTIL_DOG_OFF_PLUS_DISTANCE)
            {
                if (!IsNonNegativeFinite(
                    axis.home.backoffExtraDistance_unit))
                {
                    SetAxisError(
                        axisIndex,
                        axis,
                        HomeErrorReason::INVALID_CONFIG);

                    return;
                }
            }
            else
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            // DOG Mode �����n�� PLC�A
            // �]�� HOME DOG �O PLC C Point�C
            if (UsesDogSwitch(
                axis.home.method) &&
                m_plc == nullptr)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }
        }


        // ----------------------------------------------------
        // D. INDEX Search �Ѽ�
        //
        // �ݭn INDEX ���Ҧ��G
        //
        // DOG_INDEX
        // LIMIT_INDEX
        // INDEX_ONLY
        //
        // HomeIndexMaxDistance �j��n�D > 0�C
        //
        // �����\�L���j�M INDEX�C
        // ----------------------------------------------------

        if (usesIndex)
        {
            if (!IsPositiveFinite(
                axis.home.indexSearchSpeed_PPS) ||
                !IsPositiveFinite(
                    axis.home.indexStopDecTime) ||
                !IsPositiveFinite(
                    axis.home.indexMaxDistance_unit) ||
                !IsNonNegativeFinite(
                    axis.home.indexTimeoutSec))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            if (axis.home.referenceSource ==
                HomeReferenceSource::NONE)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            // ------------------------------------------------
            // Reference Source / Capture Mode �զX����
            //
            // �Ĥ@�������i���զX�G
            //
            // 1. Motor / Drive Scale INDEX
            //      -> DRIVE_HARDWARE_LATCH
            //
            // 2. External IO INDEX
            //      -> SOFTWARE_SAMPLE
            //
            // EXTERNAL_HARDWARE_LATCH �ݭn�~���O�l��
            // Capture Register API�A�ثe�|�����ѡA���ల�ˤ䴩�C
            // ------------------------------------------------

            if (axis.home.referenceSource ==
                HomeReferenceSource::MOTOR_ENCODER_INDEX ||
                axis.home.referenceSource ==
                HomeReferenceSource::LINEAR_SCALE_INDEX_DRIVE)
            {
                if (axis.home.captureMode !=
                    HomeReferenceCaptureMode::DRIVE_HARDWARE_LATCH)
                {
                    SetAxisError(
                        axisIndex,
                        axis,
                        HomeErrorReason::INVALID_CONFIG);

                    return;
                }
            }
            else if (axis.home.referenceSource ==
                HomeReferenceSource::EXTERNAL_IO_INDEX)
            {
                if (axis.home.captureMode !=
                    HomeReferenceCaptureMode::SOFTWARE_SAMPLE ||
                    m_plc == nullptr)
                {
                    SetAxisError(
                        axisIndex,
                        axis,
                        HomeErrorReason::INVALID_CONFIG);

                    return;
                }
            }
            else
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            if (UsesDriveTouchProbe(axis) &&
                !ValidateDriveProbeConfig(axis))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }
        }


        // ----------------------------------------------------
        // E. Absolute Reference
        //
        // �ثe�S�� Delta Absolute Position / Multi-turn Provider�A
        // �]�����T�ڵ��A���Υثe��m�_�R Absolute Reference�C
        // ----------------------------------------------------

        if (axis.home.method ==
            HomeMethod::ABSOLUTE_REFERENCE)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        // ----------------------------------------------------
        // F. Mechanical Stop
        //
        // �Ĥ@���|����@�C
        // ----------------------------------------------------

        if (axis.home.method ==
            HomeMethod::MECHANICAL_STOP)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        // ----------------------------------------------------
        // G. Runtime Snapshot ��l��
        // ----------------------------------------------------

        axis.homeRuntime.error =
            HomeErrorReason::NONE;

        axis.homeRuntime.completed =
            false;

        axis.homeRuntime.dogDetected =
            false;

        axis.homeRuntime.dogReleased =
            false;

        axis.homeRuntime.hardLimitReleased =
            false;

        axis.homeRuntime.referenceArmed =
            false;

        axis.homeRuntime.referenceDetected =
            false;

        axis.homeRuntime.waitingGroupBarrier =
            false;

        axis.homeRuntime.previousDogInput =
            false;

        axis.homeRuntime.previousReferenceInput =
            false;

        axis.homeRuntime.previousTouchProbeStatus =
            0;

        ResetDriveProbeRuntime(axis);


        // HOME Runtime ���Z���_�I�����O�s�� Raw Logical Pulse�C
        //
        // ���i�V�� axis.currentActPos�]Machine Pulse�^�A
        // �_�h ApplyMachineHome() �إ� Machine Offset ��A
        // �U�@�� HOME ���Z���O�@�|�� Offset �~�⦨��ڲ��ʶZ���C
        const double prepareRawPulse =
            m_motion.GetRawLogicalPositionPulse(
                axis);

        axis.homeRuntime.searchStartPulse =
            prepareRawPulse;

        axis.homeRuntime.stateStartPulse =
            prepareRawPulse;

        axis.homeRuntime.backoffStartPulse =
            prepareRawPulse;

        axis.homeRuntime.indexSearchStartPulse =
            prepareRawPulse;

        axis.homeRuntime.switchDetectedPulse =
            prepareRawPulse;

        axis.homeRuntime.capturedReferenceRaw =
            0;

        axis.homeRuntime.capturedReferencePulse =
            0.0;

        axis.homeRuntime.stateElapsedSec =
            0.0;


        // ----------------------------------------------------
        // H. HomeMethod -> �U�@�� State
        //
        // �`�N�G
        // �o�̥u�� State�A
        // �U�@�� Scan �~�|�}�l�� State ���u���u�@�C
        // ----------------------------------------------------

        switch (axis.home.method)
        {
        case HomeMethod::DOG_INDEX:
        case HomeMethod::LIMIT_INDEX:
        case HomeMethod::DOG_ONLY:
        case HomeMethod::LIMIT_ONLY:

            axis.homeRuntime.state =
                HomeState::SEARCH_SWITCH;

            break;


        case HomeMethod::INDEX_ONLY:

            // �Y�Ϥ��ݭn DOG / LIMIT�A�]���i�J Backoff Barrier�A
            // �T�O�h�b P0/P1 �b�P�@���I�}�l Reference ���q�C
            axis.homeRuntime.waitingGroupBarrier = true;
            axis.homeRuntime.state = HomeState::WAIT_GROUP_BACKOFF;

            break;


        case HomeMethod::CURRENT_POSITION:

            // �N�ثe��ڦ�m���� Reference�C
            //
            // ���O�s Pulse�A
            // ���� APPLY_HOME �A�����إ� Machine Coordinate�C
            axis.homeRuntime.capturedReferencePulse =
                m_motion.GetRawLogicalPositionPulse(axis);

            axis.homeRuntime.referenceDetected = true;
            axis.homeRuntime.waitingGroupBarrier = true;
            axis.homeRuntime.state = HomeState::WAIT_GROUP_BACKOFF;

            break;


        case HomeMethod::MECHANICAL_STOP:
        default:

            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        return;
    }


    // ========================================================
    // SEARCH_SWITCH
    //
    // �Ĥ@�ӯu���|���ʪ� HOME State�C
    //
    // DOG_INDEX / DOG_ONLY�G
    //
    //     �� HomeDirection �ϥ� VelocityMove()
    //     �j�M PLC HOME DOG�C
    //
    // LIMIT_INDEX / LIMIT_ONLY�G
    //
    //     �� HomeDirection �ϥ� VelocityMove()
    //     �j�M�w����V�� Physical Hard Limit�C
    //
    // ����G
    //
    //     StopMove(HomeSwitchStopDecTime)
    //     ��
    //     SWITCH_DECEL_STOP
    //
    // ���`��� Sensor ���O Alarm�C
    // ========================================================

    if (axis.homeRuntime.state ==
        HomeState::SEARCH_SWITCH)
    {
        // ----------------------------------------------------
        // A. Runtime Safety
        // ----------------------------------------------------

        if (!axis.isServoOn)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::SERVO_NOT_READY);

            return;
        }


        if (axis.isFault ||
            axis.isLagAlarm ||
            axis.state ==
            MotionState::MotionState_ERROR ||
            axis.state ==
            MotionState::MotionState_ESTOP)
        {
            // �Y�~�h Safety �w�g���إ� Alarm�A
            // �o�̥u���� HOME�A���A�B�~��ĤG�� Alarm�C
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::MOTION_FAULT);

            return;
        }


        // SEARCH_SWITCH ���`�u�i��O�G
        //
        // IDLE�G
        //     �|���u���Ұʷj�M�C
        //
        // VELOCITY�G
        //     ���b����j�M�C
        //
        // ��L MotionState ���N�� Ownership �Q�}�a�C
        if (axis.state !=
            MotionState::MotionState_IDLE &&
            axis.state !=
            MotionState::MotionState_VELOCITY)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::MOTION_FAULT);

            return;
        }


        // ----------------------------------------------------
        // B. Hard Limit Safety
        //
        // +OT �P -OT �P�� ON �û��O���`�C
        //
        // �j�M HOME DOG �ɡG
        //     ���@ Hard Limit �����O�w�� HOME Event�C
        //
        // �j�M LIMIT �ɡG
        //     �u�� HomeDirection ���������@���i�H�O���` Event�C
        // ----------------------------------------------------

        const bool positiveHardLimit =
            axis.hardLimitPositive;

        const bool negativeHardLimit =
            axis.hardLimitNegative;


        if (positiveHardLimit &&
            negativeHardLimit)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::BOTH_HARD_LIMITS);

            return;
        }


        const bool usesDog =
            UsesDogSwitch(
                axis.home.method);

        const bool usesHardLimit =
            UsesHardLimitSwitch(
                axis.home.method);


        if (usesDog)
        {
            if (positiveHardLimit ||
                negativeHardLimit)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::OPPOSITE_HARD_LIMIT);

                return;
            }
        }
        else if (usesHardLimit)
        {
            const bool oppositeLimit =
                (axis.home.direction > 0 &&
                    negativeHardLimit) ||
                (axis.home.direction < 0 &&
                    positiveHardLimit);


            if (oppositeLimit)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::OPPOSITE_HARD_LIMIT);

                return;
            }
        }
        else
        {
            // ��i SEARCH_SWITCH ����k�@�w�����ϥ�
            // DOG �� LIMIT�C
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }


        // ----------------------------------------------------
        // C. Read Target Switch
        // ----------------------------------------------------

        bool switchDetected =
            false;


        if (usesDog)
        {
            if (m_plc == nullptr)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }


            const bool rawDogInput =
                m_plc->Get_C(
                    NCPLC::C::AxisPoint(
                        NCPLC::C::HOME_DOG_BASE,
                        axisIndex));


            const bool dogActive =
                axis.home.dogActiveHigh
                ? rawDogInput
                : !rawDogInput;


            axis.homeRuntime.previousDogInput =
                rawDogInput;


            switchDetected =
                dogActive;


            if (dogActive)
            {
                axis.homeRuntime.dogDetected =
                    true;
            }
        }
        else
        {
            switchDetected =
                axis.home.direction > 0
                ? positiveHardLimit
                : negativeHardLimit;
        }


        // ----------------------------------------------------
        // D. Switch Found
        //
        // Sensor �w�g ON ���u���B�z Found�A
        // �A�P�_ MaxDistance / Timeout�C
        //
        // �o�]�䴩�G
        //
        // HOME �}�l�e�b�w�g���b�w�� DOG / LIMIT �W�C
        //
        // ���ɤ��|�~�� Sensor �̭����A
        // �ӬO�����i Controlled Stop / Backoff �y�{�C
        // ----------------------------------------------------

        if (switchDetected)
        {
            axis.homeRuntime.switchDetectedPulse =
                m_motion.GetRawLogicalPositionPulse(axis);

            axis.homeRuntime.stateStartPulse =
                axis.homeRuntime.switchDetectedPulse;

            axis.homeRuntime.capturedReferencePulse =
                axis.homeRuntime.switchDetectedPulse;

            axis.homeRuntime.referenceDetected =
                !UsesIndexReference(axis.home.method);

            axis.homeRuntime.stateElapsedSec =
                0.0;


            if (axis.state ==
                MotionState::MotionState_VELOCITY)
            {
                QueueHomeStop(axisIndex, axis.home.switchStopDecTime);
            }


            axis.homeRuntime.state =
                HomeState::SWITCH_DECEL_STOP;


            return;
        }


        // ----------------------------------------------------
        // E. Search Distance Protection
        //
        // currentActPos / searchStartPulse�G
        //     Pulse
        //
        // HomeSearchMaxDistance�G
        //     Machine Unit
        //
        // Linear = mm
        // Rotary = degree
        // ----------------------------------------------------

        // ====================================================
        // SEARCH Distance �����ϥΦP�@�Ӯy�� Domain
        //
        // searchStartPulse�G
        //     Raw Logical Pulse
        //
        // axis.currentActPos�G
        //     Machine Pulse
        //     �w���� machineCoordinateOffsetPulse
        //
        // HOME ���\�� machineCoordinateOffsetPulse �q�`�ܤj�C
        // �Y�� currentActPos - searchStartPulse�A
        // �U�@�� G81 �|���� Machine Offset �~�P���w���ʶZ���A
        // �X�G�ߨ�Ĳ�o 3009 HOME_SEARCH_NOT_FOUND�C
        //
        // �]���ثe��m�]������^ Raw Logical Pulse�A
        // �A�p�⥻���u�����j�M�Z���C
        // ====================================================

        const double searchDistanceUnit =
            GetTravelDistanceUnit(
                axis,
                axis.homeRuntime.searchStartPulse);


        if (searchDistanceUnit >=
            axis.home.searchMaxDistance_unit)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::SEARCH_MAX_DISTANCE);

            return;
        }


        // ----------------------------------------------------
        // F. Search Timeout Protection
        //
        // 0 = Disable
        // ----------------------------------------------------

        if (axis.home.searchTimeoutSec > 0.0 &&
            axis.homeRuntime.stateElapsedSec >=
            axis.home.searchTimeoutSec)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::SEARCH_TIMEOUT);

            return;
        }


        // ----------------------------------------------------
        // G. Start / Continue Search Motion
        //
        // HOME Search �ϥ� Machine Logical Direction�C
        //
        // isReverse / Axis_Reverse ���w���V����A
        // ���� MotionCore / Servo Output Layer �t�d�C
        // ----------------------------------------------------

        const double searchVelocity =
            axis.home.searchSpeed_PPS *
            static_cast<double>(
                axis.home.direction);


        // �u���� State �Ĥ@���Ұʮɤ~��إ� Search �_�I�C
        // Hold -> Resume �� axis.state �]�|�^�� IDLE�A
        // �����୫�] SearchMaxDistance / Timeout �_�I�C
        if (!axis.homeRuntime.motionCommandIssued)
        {
            axis.pid.prevError =
                0.0;

            axis.pid.integralAcc =
                0.0;


            axis.homeRuntime.searchStartPulse =
                m_motion.GetRawLogicalPositionPulse(axis);

            axis.homeRuntime.stateStartPulse =
                axis.homeRuntime.searchStartPulse;

            axis.homeRuntime.stateElapsedSec =
                0.0;

            axis.homeRuntime.motionCommandIssued =
                true;
        }


        QueueHomeVelocity(
            axisIndex, searchVelocity, axis.home.searchAccTime);


        return;
    }


    // ========================================================
    // SWITCH_DECEL_STOP
    // ========================================================
    if (axis.homeRuntime.state == HomeState::SWITCH_DECEL_STOP)
    {
        if (axis.state == MotionState::MotionState_VELOCITY)
        {
            QueueHomeStop(axisIndex, axis.home.switchStopDecTime);
            return;
        }

        if (axis.home.switchStopMaxDistance_unit > 0.0 &&
            GetTravelDistanceUnit(axis, axis.homeRuntime.switchDetectedPulse) > axis.home.switchStopMaxDistance_unit)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::SWITCH_STOP_MAX_DISTANCE);
            return;
        }

        if (axis.state == MotionState::MotionState_STOPPING) return;
        if (axis.state != MotionState::MotionState_IDLE)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
            return;
        }

        axis.homeRuntime.backoffStartPulse = m_motion.GetRawLogicalPositionPulse(axis);
        axis.homeRuntime.dogReleased = false;
        EnterState(axis, HomeState::BACK_OFF);
        return;
    }

    // ========================================================
    // BACK_OFF
    // ========================================================
    if (axis.homeRuntime.state == HomeState::BACK_OFF)
    {
        if (axis.hardLimitPositive && axis.hardLimitNegative)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::BOTH_HARD_LIMITS);
            return;
        }

        const bool oppositeLimit =
            (axis.home.direction > 0 && axis.hardLimitNegative) ||
            (axis.home.direction < 0 && axis.hardLimitPositive);
        if (oppositeLimit)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::OPPOSITE_HARD_LIMIT);
            return;
        }

        if (GetTravelDistanceUnit(axis, axis.homeRuntime.backoffStartPulse) >= axis.home.backoffMaxDistance_unit)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::BACKOFF_MAX_DISTANCE);
            return;
        }
        if (axis.home.backoffTimeoutSec > 0.0 && axis.homeRuntime.stateElapsedSec >= axis.home.backoffTimeoutSec)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::BACKOFF_TIMEOUT);
            return;
        }

        const double dir = -static_cast<double>(axis.home.direction);
        const double ppu = GetPulsePerUnit(axis);

        if (axis.home.backoffMode == HomeBackoffMode::FIXED_DISTANCE)
        {
            if (!axis.homeRuntime.stateTargetValid)
            {
                axis.homeRuntime.stateTargetPulse =
                    axis.currentActPos +
                    dir *
                    axis.home.backoffDistance_unit *
                    ppu;

                axis.homeRuntime.stateTargetValid =
                    true;
            }


            if (!axis.homeRuntime.motionCommandIssued)
            {
                if (axis.state !=
                    MotionState::MotionState_IDLE)
                {
                    return;
                }

                if (!QueueHomeMove(
                    axisIndex, axis.homeRuntime.stateTargetPulse,
                    axis.home.backoffSpeed_PPS, axis.home.backoffAccTime,
                    axis.home.backoffDecTime, axis.useShortestPath))
                {
                    return;
                }

                axis.homeRuntime.motionCommandIssued =
                    true;

                return;
            }


            if (axis.state ==
                MotionState::MotionState_IDLE)
            {
                EnterState(
                    axis,
                    HomeState::VALIDATE_RELEASE);

                return;
            }


            if (axis.state !=
                MotionState::MotionState_MOVING &&
                axis.state !=
                MotionState::MotionState_STOPPING)
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::MOTION_FAULT);
            }

            return;
        }

        bool switchActive = false;
        if (!ReadHomeSwitch(axisIndex, axis, switchActive))
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::INVALID_CONFIG);
            return;
        }

        if (!axis.homeRuntime.dogReleased)
        {
            if (switchActive)
            {
                if (axis.state != MotionState::MotionState_IDLE && axis.state != MotionState::MotionState_VELOCITY)
                {
                    SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
                    return;
                }
                QueueHomeVelocity(axisIndex, dir * axis.home.backoffSpeed_PPS, axis.home.backoffAccTime);
                return;
            }

            axis.homeRuntime.dogReleased = true;
            axis.homeRuntime.hardLimitReleased = !axis.hardLimitPositive && !axis.hardLimitNegative;
            if (axis.state == MotionState::MotionState_VELOCITY) QueueHomeStop(axisIndex, axis.home.backoffDecTime);
            return;
        }

        if (axis.state != MotionState::MotionState_IDLE)
        {
            if (axis.state != MotionState::MotionState_STOPPING) QueueHomeStop(axisIndex, axis.home.backoffDecTime);
            return;
        }

        if (axis.home.backoffExtraDistance_unit <= 0.0)
        {
            EnterState(axis, HomeState::VALIDATE_RELEASE);
            return;
        }

        if (!axis.homeRuntime.stateTargetValid)
        {
            axis.homeRuntime.stateTargetPulse =
                axis.currentActPos +
                dir *
                axis.home.backoffExtraDistance_unit *
                ppu;

            axis.homeRuntime.stateTargetValid =
                true;
        }


        if (!axis.homeRuntime.motionCommandIssued)
        {
            if (!QueueHomeMove(
                axisIndex, axis.homeRuntime.stateTargetPulse,
                axis.home.backoffSpeed_PPS, axis.home.backoffAccTime,
                axis.home.backoffDecTime, axis.useShortestPath))
            {
                return;
            }

            axis.homeRuntime.motionCommandIssued =
                true;

            return;
        }

        if (axis.state == MotionState::MotionState_IDLE)
        {
            EnterState(axis, HomeState::VALIDATE_RELEASE);
            return;
        }
        return;
    }

    // ========================================================
    // VALIDATE_RELEASE
    // ========================================================
    if (axis.homeRuntime.state == HomeState::VALIDATE_RELEASE)
    {
        if (axis.state != MotionState::MotionState_IDLE) return;
        bool switchActive = false;
        if (!ReadHomeSwitch(axisIndex, axis, switchActive))
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::INVALID_CONFIG);
            return;
        }
        if (UsesDogSwitch(axis.home.method) && switchActive && axis.home.alarmIfDogNotReleasedBeforeIndex)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::DOG_NOT_RELEASED);
            return;
        }
        const bool anyLimit = axis.hardLimitPositive || axis.hardLimitNegative;
        if (anyLimit && axis.home.alarmIfHardLimitNotReleasedBeforeIndex)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::HARD_LIMIT_NOT_RELEASED);
            return;
        }
        axis.homeRuntime.dogReleased = !switchActive;
        axis.homeRuntime.hardLimitReleased = !anyLimit;
        axis.homeRuntime.waitingGroupBarrier = true;
        EnterState(axis, HomeState::WAIT_GROUP_BACKOFF);
        return;
    }

    if (axis.homeRuntime.state == HomeState::WAIT_GROUP_BACKOFF ||
        axis.homeRuntime.state == HomeState::WAIT_GROUP_INDEX_STOP)
        return;

    // ========================================================
    // ARM_REFERENCE
    // ========================================================
    if (axis.homeRuntime.state == HomeState::ARM_REFERENCE)
    {
        if (axis.state != MotionState::MotionState_IDLE) return;

        if (axis.home.method == HomeMethod::ABSOLUTE_REFERENCE)
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }

        if (axis.home.referenceSource == HomeReferenceSource::EXTERNAL_IO_INDEX)
        {
            if (axis.home.captureMode != HomeReferenceCaptureMode::SOFTWARE_SAMPLE)
            {
                SetAxisError(axisIndex, axis, HomeErrorReason::INVALID_CONFIG);
                return;
            }
            bool active = false;
            if (!ReadExternalReferenceInput(axisIndex, axis, active))
            {
                SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_INVALID);
                return;
            }
            if (active)
            {
                axis.homeRuntime.previousReferenceInput = true;
                if (axis.home.indexTimeoutSec > 0.0 && axis.homeRuntime.stateElapsedSec >= axis.home.indexTimeoutSec)
                    SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_NOT_ARMED);
                return;
            }
            axis.homeRuntime.previousReferenceInput = false;
            axis.homeRuntime.referenceArmed = true;
            axis.homeRuntime.indexSearchStartPulse = m_motion.GetRawLogicalPositionPulse(axis);
            EnterState(axis, HomeState::SEARCH_INDEX);
            return;
        }

        if (!UsesDriveTouchProbe(axis))
        {
            SetAxisError(
                axisIndex,
                axis,
                HomeErrorReason::INVALID_CONFIG);

            return;
        }

        if (ProcessDriveProbeArm(
            axisIndex,
            axis,
            cycleTimeSec))
        {
            EnterState(
                axis,
                HomeState::SEARCH_INDEX);
        }

        return;
    }

    // ========================================================
    // SEARCH_INDEX
    // ========================================================
    if (axis.homeRuntime.state == HomeState::SEARCH_INDEX)
    {
        if (!axis.homeRuntime.referenceArmed)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_NOT_ARMED);
            return;
        }
        if (axis.hardLimitPositive && axis.hardLimitNegative)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::BOTH_HARD_LIMITS);
            return;
        }
        if (axis.hardLimitPositive || axis.hardLimitNegative)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::OPPOSITE_HARD_LIMIT);
            return;
        }

        bool detected = false;
        double captured = 0.0;
        if (axis.home.referenceSource == HomeReferenceSource::EXTERNAL_IO_INDEX)
        {
            bool active = false;
            if (!ReadExternalReferenceInput(axisIndex, axis, active))
            {
                SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_INVALID);
                return;
            }
            detected = active && !axis.homeRuntime.previousReferenceInput;
            axis.homeRuntime.previousReferenceInput = active;
            if (detected) captured = m_motion.GetRawLogicalPositionPulse(axis);
        }
        else
        {
            if (!TryCaptureDriveProbe(
                axisIndex,
                axis,
                detected,
                captured))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::REFERENCE_INVALID);

                return;
            }
        }

        if (detected)
        {
            axis.homeRuntime.capturedReferencePulse = captured;
            axis.homeRuntime.referenceDetected = true;
            if (axis.state == MotionState::MotionState_VELOCITY) QueueHomeStop(axisIndex, axis.home.indexStopDecTime);
            EnterState(axis, HomeState::INDEX_DECEL_STOP);
            return;
        }

        if (GetTravelDistanceUnit(axis, axis.homeRuntime.indexSearchStartPulse) >= axis.home.indexMaxDistance_unit)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::INDEX_MAX_DISTANCE);
            return;
        }
        if (axis.home.indexTimeoutSec > 0.0 && axis.homeRuntime.stateElapsedSec >= axis.home.indexTimeoutSec)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::INDEX_TIMEOUT);
            return;
        }
        if (axis.state != MotionState::MotionState_IDLE && axis.state != MotionState::MotionState_VELOCITY)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
            return;
        }
        const int indexDirection =
            (UsesDogSwitch(axis.home.method) ||
                UsesHardLimitSwitch(axis.home.method))
            ? -axis.home.direction
            : axis.home.direction;


        // Hold -> Resume ���i���s�إ� INDEX Search �_�I�� Timeout�C
        if (!axis.homeRuntime.motionCommandIssued)
        {
            axis.pid.prevError =
                0.0;

            axis.pid.integralAcc =
                0.0;

            axis.homeRuntime.motionCommandIssued =
                true;
        }


        QueueHomeVelocity(
            axisIndex,
            axis.home.indexSearchSpeed_PPS *
            static_cast<double>(indexDirection),
            axis.home.indexSearchAccTime);
        return;
    }

    // ========================================================
    // INDEX_DECEL_STOP
    // ========================================================
    if (axis.homeRuntime.state == HomeState::INDEX_CAPTURED)
    {
        EnterState(axis, HomeState::INDEX_DECEL_STOP);
        return;
    }
    if (axis.homeRuntime.state == HomeState::INDEX_DECEL_STOP)
    {
        if (axis.state == MotionState::MotionState_VELOCITY)
        {
            QueueHomeStop(axisIndex, axis.home.indexStopDecTime);
            return;
        }
        if (axis.state == MotionState::MotionState_STOPPING) return;
        if (axis.state != MotionState::MotionState_IDLE)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
            return;
        }
        EnterState(axis, HomeState::WAIT_GROUP_INDEX_STOP);
        return;
    }

    // ========================================================
    // APPLY_HOME
    // ========================================================
    if (axis.homeRuntime.state == HomeState::APPLY_HOME)
    {
        if (axis.state != MotionState::MotionState_IDLE || !axis.homeRuntime.referenceDetected || !std::isfinite(axis.homeRuntime.capturedReferencePulse))
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_INVALID);
            return;
        }
        MotionAxisCommandSequence& pendingSequence =
            m_pendingApplyHomeSequence[axisIndex];

        if (pendingSequence == MOTION_AXIS_COMMAND_SEQUENCE_INVALID)
        {
            if (!m_motion.SubmitApplyMachineHome(
                axisIndex, axis.homeRuntime.capturedReferencePulse,
                axis.home.homeOffset_unit, m_homeMotionLease,
                pendingSequence))
            {
                SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
            }
            return;
        }

        MotionAxisCommandResult applyResult{};
        if (!m_motion.TryGetAxisCommandResult(pendingSequence, applyResult))
        {
            return;
        }

        pendingSequence = MOTION_AXIS_COMMAND_SEQUENCE_INVALID;
        if (applyResult.resultType != MotionAxisCommandResultType::APPLIED)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::REFERENCE_INVALID);
            return;
        }

        axis.isHomed = true;
        if (m_nc != nullptr)
            m_nc->CoordSys.commandedMCS[axisIndex] = axis.currentActPos * (axis.finalLead / axis.resolution_PPR);

        if (axis.home.moveToZero)
        {
            if (axis.home.moveToZeroSpeed_PPS <= 0.0)
            {
                SetAxisError(axisIndex, axis, HomeErrorReason::INVALID_CONFIG);
                return;
            }
            EnterState(axis, HomeState::MOVE_TO_ZERO);
        }
        else CompleteAxis(axisIndex, axis);
        return;
    }

    // ========================================================
    // MOVE_TO_ZERO
    // ========================================================
    if (axis.homeRuntime.state == HomeState::MOVE_TO_ZERO)
    {
        if (axis.hardLimitPositive || axis.hardLimitNegative)
        {
            SetAxisError(axisIndex, axis, HomeErrorReason::OPPOSITE_HARD_LIMIT);
            return;
        }
        if (!axis.homeRuntime.stateTargetValid)
        {
            // ApplyMachineHome �� Machine Zero ���� MotionCore Pulse = 0�C
            axis.homeRuntime.stateTargetPulse =
                0.0;

            axis.homeRuntime.stateTargetValid =
                true;
        }


        if (!axis.homeRuntime.motionCommandIssued)
        {
            if (axis.state !=
                MotionState::MotionState_IDLE)
            {
                return;
            }

            if (m_nc != nullptr &&
                !m_nc->CoordSys.IsTargetWithinSoftwareTravelLimit(
                    axis,
                    0.0))
            {
                SetAxisError(
                    axisIndex,
                    axis,
                    HomeErrorReason::INVALID_CONFIG);

                return;
            }

            if (!QueueHomeMove(
                axisIndex, axis.homeRuntime.stateTargetPulse,
                axis.home.moveToZeroSpeed_PPS, axis.home.moveToZeroAccTime,
                axis.home.moveToZeroDecTime, axis.useShortestPath))
            {
                return;
            }

            axis.homeRuntime.motionCommandIssued =
                true;

            return;
        }
        if (axis.state == MotionState::MotionState_IDLE)
        {
            CompleteAxis(axisIndex, axis);
            return;
        }
        if (axis.state != MotionState::MotionState_MOVING && axis.state != MotionState::MotionState_STOPPING)
            SetAxisError(axisIndex, axis, HomeErrorReason::MOTION_FAULT);
        return;
    }
}


// ============================================================
// Completion / Error
// ============================================================

void HomingManager::CompleteAxis(
    int axisIndex,
    AxisContext& axis)
{
    if (!DisarmDriveProbe(
        axisIndex,
        axis,
        true))
    {
        // Mailbox full: keep this axis at the completion point and retry.
        return;
    }


    axis.homeRuntime.active =
        false;

    axis.homeRuntime.completed =
        true;

    axis.homeRuntime.error =
        HomeErrorReason::NONE;

    axis.homeRuntime.state =
        HomeState::DONE;

    axis.homeRuntime.stateElapsedSec =
        0.0;


    // HOME �u�����\������A
    // �~���s�}�� Machine Homed ���A�C
    axis.isHomed =
        true;


    // ========================================================
    // HOME Persistence
    //
    // �u Queue �O���� Snapshot�C
    // �o�̤�������Ϻ� I/O�C
    //
    // �u���g�ɥ� 1000ms supervisory task ����C
    // ========================================================

    RtPrintf(
        "[HOME-PERSIST] CompleteAxis Axis:%d IsHomed:%d\n",
        axisIndex,
        axis.isHomed
        ? 1
        : 0);


    HomePersistenceManager::GetInstance()
        .QueueSuccessfulHome(
            axisIndex,
            axis);
}


void HomingManager::SetAxisError(
    int axisIndex,
    AxisContext& axis,
    HomeErrorReason error)
{
    // ========================================================
    // 1. �Ĥ@���~��s
    //
    // �h�b HOME �i��b�P�@ Scan �o�{�h�Ӱ��D�C
    //
    // Alarm History �u�O�d�Ĥ@�ӯu�����ѭ�]�A
    // �קK�P�@�ƥ��J�h�ӭl�� Alarm�C
    // ========================================================

    const bool firstHomeError =
        m_lastError ==
        HomeErrorReason::NONE;

    const int immediateAlarmCode = GetHomeAlarmCode(error);
    if (immediateAlarmCode != 0)
    {
        m_motion.RequestEmergencyStopAllAxes();
    }

    DisarmDriveProbe(
        axisIndex,
        axis);


    // ========================================================
    // 2. �аO�o�Ϳ��~���b
    // ========================================================

    axis.homeRuntime.active =
        false;

    axis.homeRuntime.completed =
        false;

    axis.homeRuntime.error =
        error;

    axis.homeRuntime.state =
        HomeState::HOME_ERROR;

    axis.homeRuntime.stateElapsedSec =
        0.0;


    // HOME ���ѫ�A���b Machine Home �L�ġC
    axis.isHomed =
        false;


    // ========================================================
    // 3. �פ��� HOME Request
    //
    // �u�n�䤤�@�b HOME ���ѡA
    // ���� G81 / Panel HOME ���i�~������L�b�C
    //
    // �w�g���\���� HOME ���e�@�� Order �b�A
    // isHomed ���A�O�d�A�����N�M���C
    // ========================================================

    m_hasError =
        true;

    m_active =
        false;

    m_completed =
        false;

    m_cancelRequested =
        false;

    ClearResumeRequest();

    m_runControlState =
        HomeRunControlState::IDLE;

    m_currentOrder =
        -1;


    for (int i = 0;
        i < HOME_AXIS_COUNT;
        ++i)
    {
        if (!IsAxisRequested(
            m_selectedAxisMask,
            i))
        {
            continue;
        }


        AxisContext& selectedAxis =
            m_motion.GetAxisContext(i);


        // �w�g���\ DONE ���b�O�d�������A�C
        if (selectedAxis.homeRuntime.completed)
        {
            continue;
        }


        // �u���o�Ϳ��~���b�w�b�W��g�J Error�C
        if (i == axisIndex)
        {
            continue;
        }


        // ��L���b�ѻP�P�@ HOME Request ���b�u���� Ownership�C
        //
        // �������̫إ߲ĤG�� Alarm�A
        // �]�����˥��̦U�۵o�ͬۦP�G�١C
        DisarmDriveProbe(
            i,
            selectedAxis);

        selectedAxis.homeRuntime.active =
            false;

        selectedAxis.homeRuntime.waitingGroupBarrier =
            false;
    }


    m_activeAxisMask =
        0;


    // ========================================================
    // 4. �O�s�Ĥ@���~�{��
    // ========================================================

    if (firstHomeError)
    {
        m_lastError =
            error;

        m_lastErrorAxis =
            axisIndex;
    }


    // ========================================================
    // 5. Error -> Alarm
    //
    // �ϥΪ̩w�q�G
    //
    //     �u�n�i AlarmManager
    //     �N���� Emergency Stop�C
    //
    // CANCELLED �O���`�����A���b�o�̲��� Alarm�C
    // ========================================================

    const int alarmCode =
        GetHomeAlarmCode(
            error);


    if (firstHomeError &&
        alarmCode != 0 &&
        !AlarmManager::GetInstance().HasAlarm())
    {
        const int alarmAxisIndex =
            axis.isExist
            ? axis.axisIndex
            : axisIndex;


        AlarmManager::GetInstance().Trigger(
            alarmCode,
            0,
            alarmAxisIndex);
    }

    // �u�n�O Alarm �������~�A�@�ߥ��b�氱�C
    if (alarmCode != 0)
    {
        m_motion.RequestEmergencyStopAllAxes();
        if (m_nc != nullptr) m_nc->ChangeState(NCState::ALARM);
    }

    RestoreOrReleaseHomeMotionOwner();
}


void HomingManager::CompleteRequest()
{
    if (m_nc != nullptr)
    {
        double actualMCS[HOME_AXIS_COUNT] = { 0.0 };
        for (int i = 0; i < HOME_AXIS_COUNT; ++i)
        {
            const AxisContext& axis = m_motion.GetAxisContext(i);
            if (axis.isExist && axis.resolution_PPR > 0.0)
                actualMCS[i] = axis.currentActPos * (axis.finalLead / axis.resolution_PPR);
        }
        m_nc->CoordSys.UpdateActualMCS(actualMCS);
        m_nc->CoordSys.SyncMachinePosition(actualMCS);
        m_motion.SyncVirtualEndPosition();
        m_nc->UpdateSystemVariables();
    }

    m_activeAxisMask =
        0;

    m_active =
        false;

    m_completed =
        true;

    m_cancelRequested =
        false;

    ClearResumeRequest();

    m_runControlState =
        HomeRunControlState::IDLE;

    m_currentOrder =
        -1;

    RestoreOrReleaseHomeMotionOwner();
}


// ============================================================
// HOME Method Helper
// ============================================================

bool HomingManager::UsesDogSwitch(
    HomeMethod method) const
{
    return
        method ==
        HomeMethod::DOG_INDEX ||
        method ==
        HomeMethod::DOG_ONLY;
}


bool HomingManager::UsesHardLimitSwitch(
    HomeMethod method) const
{
    return
        method ==
        HomeMethod::LIMIT_INDEX ||
        method ==
        HomeMethod::LIMIT_ONLY;
}


bool HomingManager::UsesIndexReference(
    HomeMethod method) const
{
    return
        method ==
        HomeMethod::DOG_INDEX ||
        method ==
        HomeMethod::LIMIT_INDEX ||
        method ==
        HomeMethod::INDEX_ONLY;
}


bool HomingManager::IsHardLimitAllowedHomeState(
    HomeState state) const
{
    switch (state)
    {
    case HomeState::SEARCH_SWITCH:

        // ���b�D�ʴM��w����V Limit�C
        return true;


    case HomeState::SWITCH_DECEL_STOP:

        // Limit �w�gĲ�o�A
        // ���b Controlled Deceleration�C
        return true;


    case HomeState::BACK_OFF:

        // ���b�Ϥ�V�h�X Limit�C
        return true;


    case HomeState::VALIDATE_RELEASE:

        // Backoff �����᥿�b�T�{ Limit �O�_�Ѱ��C
        //
        // �Y�����Ѱ��B�Ѽƭn�D Alarm�A
        // ����� HomingManager ���ͧ���T��
        // HOME_LIMIT_NOT_RELEASED ���� Alarm�C
        return true;


    default:
        return false;
    }
}
