#include "EtherCatMaster_DC_Topology.h"
#include "EtherCatMaster.h"
#include "GlobalConfig.h"
#include "ConfigReader.h"
#include <windows.h>
#include <rtapi.h>
#include <rtssapi.h>
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <string>
#include <vector>

// ============================================================================
// EtherCatMaster_DC_Topology.cpp
// DC Reference ��ܻP AUTO Topology Dry-Run V1
//
// SystemConfig.txt�G
//
//   DC_Reference_Mode=AUTO
//   DC_Reference_Slave_Index=-1
//
// AUTO�G
//   �� BuildIoMap() �إߪ� m_ServoList�A���ӹ��� slave index �Ѥp��j���աF
//   �Ĥ@�x�ন�\Ū�� 0x0910 �B System Time �D 0 �����A���� DC Reference�C
//
// FIXED�G
//   �ϥ� DC_Reference_Slave_Index ���w���s�_�� slave index�C���w�����s�b�B
//   �L�kŪ�� 0x0910 �� DC System Time �� 0 �ɡA���|��������L�q���C
//
// AUTO Topology Dry-Run�G
//   �b DC Reference ��w��A�� m_ServoList ������ slave index �إ̦߳h 8 �b
//   ����Ū���ǧַӡA�ˬd 0x0910�B0x0928�BDL Status �P�u�� Port �Ϊ��C
//   �����q���g�J 0x0928�A�J�� S4/S5/S6 propagation delay �޿�O�����ܡC
// ============================================================================

namespace
{
    volatile LONG g_dcReferenceSlaveIndex = -1;

    struct DcAutoTopologyNode
    {
        int order;
        int slaveIndex;
        uint16_t configAddr;
        uint16_t dlStatus;
        uint16_t physicalPortMask;
        uint64_t dcSystemTime;
        uint32_t propagationDelayNs;
        int dlWkc;
        int dcWkc;
        int delayWkc;
    };

    std::string ToUpperCopy(
        std::string value)
    {
        std::transform(
            value.begin(),
            value.end(),
            value.begin(),
            [](unsigned char ch)
            {
                return (char)std::toupper(ch);
            });

        return value;
    }

    bool ValidateDcReferenceCandidate(
        EtherCatMaster* pMaster,
        int slaveIndex,
        uint64_t& dcSystemTime,
        int& dcWkc)
    {
        dcSystemTime = 0;
        dcWkc = 0;

        if (pMaster == nullptr ||
            pMaster->m_pEni == nullptr)
        {
            return false;
        }

        const auto& slaves =
            pMaster->m_pEni->GetSlaves();

        if (slaveIndex < 0 ||
            slaveIndex >= (int)slaves.size())
        {
            return false;
        }

        uint16_t configAddr =
            m_slaveInfo[slaveIndex].configAddr;

        if (configAddr == 0)
        {
            return false;
        }

        // �̦h���դT���A�קK��n�I��@���Ұʴ��ʥ]����C
        for (int attempt = 0;
            attempt < 3;
            attempt++)
        {
            uint64_t candidateDcTime = 0;

            int candidateWkc =
                pMaster->ecx_FPRD(
                    configAddr,
                    0x0910,
                    &candidateDcTime,
                    8,
                    20);

            if (candidateWkc > 0 &&
                candidateDcTime > 0)
            {
                dcSystemTime = candidateDcTime;
                dcWkc = candidateWkc;
                return true;
            }

            dcWkc = candidateWkc;
        }

        return false;
    }

    void PrintSelectedDcReference(
        int slaveIndex,
        const char* source,
        uint64_t dcSystemTime,
        int dcWkc)
    {
        RtPrintf(
            "[DC-REFERENCE] SELECTED | "
            "Mode:%s | "
            "SlaveIndex:%d | "
            "ConfigAddr:0x%04X | "
            "Vendor:0x%08lX | "
            "Product:0x%08lX | "
            "WKC:%d | "
            "DC:%llu\n",

            source,
            slaveIndex,
            (unsigned int)m_slaveInfo[slaveIndex].configAddr,
            (unsigned long)m_slaveInfo[slaveIndex].Vendor_ID,
            (unsigned long)m_slaveInfo[slaveIndex].Product_Code,
            dcWkc,
            (unsigned long long)dcSystemTime);
    }

    bool IsDcAutoNodeReadable(
        const DcAutoTopologyNode& node)
    {
        return
            node.dlWkc > 0 &&
            node.dcWkc > 0 &&
            node.delayWkc > 0 &&
            node.dcSystemTime > 0;
    }

    bool IsExpectedLinearServoPortShape(
        const std::vector<DcAutoTopologyNode>& nodes)
    {
        if (nodes.empty())
        {
            return false;
        }

        for (size_t i = 0;
            i < nodes.size();
            i++)
        {
            const uint16_t portMask =
                nodes[i].physicalPortMask;

            const bool p0Linked =
                (portMask & 0x01U) != 0;

            const bool p1Linked =
                (portMask & 0x02U) != 0;

            const bool branchedOnP2OrP3 =
                (portMask & 0x0CU) != 0;

            if (!p0Linked ||
                branchedOnP2OrP3)
            {
                return false;
            }

            const bool isLast =
                (i + 1U) == nodes.size();

            if (!isLast &&
                !p1Linked)
            {
                return false;
            }

            // �̫�@�x Servo �� P1 �i�H�O Open�A�]�i�H�s�����D Servo �q���C
            // Dry-Run �u�T�{ Servo �������쵲�A������ݳ]�ƻ~�P�����ѡC
        }

        return true;
    }
}

int GetDcReferenceSlaveIndex()
{
    // Writer �u�b���� PDO timer �Ұʫe���� InterlockedExchange�F�i�J Runtime ��
    // ���ޤ��A���ܡC�]�� 4 kHz ���|�u���@�� volatile 32-bit read�A���ϥ� locked
    // InterlockedCompareExchange�A�קK�W�[�����n���Y�ɸ��|�����C
    return (int)g_dcReferenceSlaveIndex;
}

bool DiagnoseDcAutoTopologyDryRun(
    EtherCatMaster* pMaster)
{
    if (pMaster == nullptr ||
        pMaster->m_pEni == nullptr)
    {
        RtPrintf(
            "[DC-TOPOLOGY-AUTO] FAILED | "
            "Reason:Master or ENI unavailable | "
            "Write0928:NO\n");

        return false;
    }

    const auto& slaves =
        pMaster->m_pEni->GetSlaves();

    const int totalSlaves =
        (int)slaves.size();

    const int servoCount =
        (int)pMaster->m_ServoList.size();

    RtPrintf(
        "\n"
        "============================================================\n"
        "[DC-TOPOLOGY-AUTO] BEGIN | "
        "Mode:DRY_RUN | "
        "SlaveCount:%d | "
        "ServoCount:%d | "
        "ServoLimit:%d | "
        "Write0928:NO\n"
        "============================================================\n",

        totalSlaves,
        servoCount,
        DC_AUTO_MAX_SERVO_COUNT);

    if (totalSlaves <= 0 ||
        servoCount <= 0)
    {
        RtPrintf(
            "[DC-TOPOLOGY-AUTO] FAILED | "
            "Reason:No slave or no servo | "
            "Write0928:NO\n");

        return false;
    }

    if (servoCount >
        DC_AUTO_MAX_SERVO_COUNT)
    {
        RtPrintf(
            "[DC-TOPOLOGY-AUTO] FAILED | "
            "Reason:Servo count exceeds limit | "
            "ServoCount:%d | Limit:%d | "
            "Write0928:NO\n",

            servoCount,
            DC_AUTO_MAX_SERVO_COUNT);

        return false;
    }

    std::vector<int> servoSlaveIndices;

    servoSlaveIndices.reserve(
        (size_t)servoCount);

    for (size_t i = 0;
        i < pMaster->m_ServoList.size();
        i++)
    {
        servoSlaveIndices.push_back(
            pMaster->m_ServoList[i].slaveIndex);
    }

    std::sort(
        servoSlaveIndices.begin(),
        servoSlaveIndices.end());

    bool indexRangeValid =
        true;

    bool duplicateIndex =
        false;

    bool consecutiveServoIndices =
        true;

    for (size_t i = 0;
        i < servoSlaveIndices.size();
        i++)
    {
        const int slaveIndex =
            servoSlaveIndices[i];

        if (slaveIndex < 0 ||
            slaveIndex >= totalSlaves)
        {
            indexRangeValid =
                false;
        }

        if (i > 0)
        {
            if (servoSlaveIndices[i - 1] ==
                slaveIndex)
            {
                duplicateIndex =
                    true;
            }

            if (servoSlaveIndices[i - 1] + 1 !=
                slaveIndex)
            {
                consecutiveServoIndices =
                    false;
            }
        }
    }

    if (!indexRangeValid ||
        duplicateIndex)
    {
        RtPrintf(
            "[DC-TOPOLOGY-AUTO] FAILED | "
            "Reason:Invalid or duplicate servo slave index | "
            "IndexRangeValid:%s | Duplicate:%s | "
            "Write0928:NO\n",

            indexRangeValid ? "YES" : "NO",
            duplicateIndex ? "YES" : "NO");

        return false;
    }

    const int referenceSlaveIndex =
        GetDcReferenceSlaveIndex();

    std::vector<DcAutoTopologyNode> nodes;

    nodes.reserve(
        servoSlaveIndices.size());

    bool allNodesReadable =
        true;

    bool referenceInServoOrder =
        false;

    RtPrintf(
        "[DC-TOPOLOGY-AUTO] ORDER | ");

    for (size_t i = 0;
        i < servoSlaveIndices.size();
        i++)
    {
        RtPrintf(
            "%sS%d",
            i == 0 ? "" : " -> ",
            servoSlaveIndices[i]);
    }

    RtPrintf("\n");

    for (size_t i = 0;
        i < servoSlaveIndices.size();
        i++)
    {
        DcAutoTopologyNode node = {};

        node.order =
            (int)i;

        node.slaveIndex =
            servoSlaveIndices[i];

        node.configAddr =
            m_slaveInfo[node.slaveIndex].configAddr;

        node.dlWkc =
            pMaster->ecx_FPRD(
                node.configAddr,
                0x0110,
                &node.dlStatus,
                2,
                20);

        node.physicalPortMask =
            (uint16_t)(
                (node.dlStatus >> 4) &
                0x000FU);

        node.dcWkc =
            pMaster->ecx_FPRD(
                node.configAddr,
                0x0910,
                &node.dcSystemTime,
                8,
                20);

        node.delayWkc =
            pMaster->ecx_FPRD(
                node.configAddr,
                0x0928,
                &node.propagationDelayNs,
                4,
                20);

        const bool isReference =
            node.slaveIndex ==
            referenceSlaveIndex;

        if (isReference)
        {
            referenceInServoOrder =
                true;
        }

        const bool nodeReadable =
            IsDcAutoNodeReadable(
                node);

        if (!nodeReadable)
        {
            allNodesReadable =
                false;
        }

        RtPrintf(
            "[DC-TOPOLOGY-AUTO] NODE | "
            "Order:%d | "
            "SlaveIndex:%d | "
            "Role:%s | "
            "ConfigAddr:0x%04X | "
            "Vendor:0x%08lX | "
            "Product:0x%08lX | "
            "DL:0x%04X | "
            "PortMask:0x%X | "
            "DC:%llu WKC:%d | "
            "Delay:%u ns WKC:%d | "
            "Readable:%s\n",

            node.order,
            node.slaveIndex,
            isReference ? "REFERENCE" : "FOLLOWER",
            (unsigned int)node.configAddr,
            (unsigned long)m_slaveInfo[node.slaveIndex].Vendor_ID,
            (unsigned long)m_slaveInfo[node.slaveIndex].Product_Code,
            (unsigned int)node.dlStatus,
            (unsigned int)node.physicalPortMask,
            (unsigned long long)node.dcSystemTime,
            node.dcWkc,
            (unsigned int)node.propagationDelayNs,
            node.delayWkc,
            nodeReadable ? "YES" : "NO");

        nodes.push_back(
            node);
    }

    const bool referenceIsFirstServo =
        !servoSlaveIndices.empty() &&
        referenceSlaveIndex ==
        servoSlaveIndices.front();

    const bool linearPortShape =
        IsExpectedLinearServoPortShape(
            nodes);

    const int leadingNonServoCount =
        servoSlaveIndices.front();

    const int trailingNonServoCount =
        totalSlaves -
        1 -
        servoSlaveIndices.back();

    const bool dryRunPass =
        allNodesReadable &&
        referenceInServoOrder &&
        referenceIsFirstServo &&
        consecutiveServoIndices &&
        linearPortShape;

    RtPrintf(
        "[DC-TOPOLOGY-AUTO] SUMMARY | "
        "Reference:S%d | "
        "ReferenceInOrder:%s | "
        "ReferenceIsFirstServo:%s | "
        "AllServoReadable:%s | "
        "Consecutive:%s | "
        "LinearPortShape:%s | "
        "LeadingNonServo:%d | "
        "TrailingNonServo:%d | "
        "Write0928:NO | "
        "Result:%s\n",

        referenceSlaveIndex,
        referenceInServoOrder ? "YES" : "NO",
        referenceIsFirstServo ? "YES" : "NO",
        allNodesReadable ? "YES" : "NO",
        consecutiveServoIndices ? "YES" : "NO",
        linearPortShape ? "YES" : "NO",
        leadingNonServoCount,
        trailingNonServoCount,
        dryRunPass ? "PASS" : "CHECK");

    RtPrintf(
        "============================================================\n"
        "[DC-TOPOLOGY-AUTO] END | "
        "Mode:DRY_RUN | Write0928:NO\n"
        "============================================================\n\n");

    return dryRunPass;
}

bool ResolveDcReferenceSlave(
    EtherCatMaster* pMaster)
{
    InterlockedExchange(
        &g_dcReferenceSlaveIndex,
        -1);

    if (pMaster == nullptr ||
        pMaster->m_pEni == nullptr)
    {
        RtPrintf(
            "[DC-REFERENCE] FAILED | "
            "Master or ENI unavailable.\n");

        return false;
    }

    const auto& slaves =
        pMaster->m_pEni->GetSlaves();

    if (slaves.empty())
    {
        RtPrintf(
            "[DC-REFERENCE] FAILED | "
            "No EtherCAT slaves.\n");

        return false;
    }

    std::string configPath =
        GlobalConfig::GetInstance().BaseDataDir +
        "SystemConfig.txt";

    std::string mode =
        ToUpperCopy(
            ConfigUtil::ReadConfigString(
                configPath,
                "DC_Reference_Mode",
                "AUTO"));

    int fixedSlaveIndex =
        (int)ConfigUtil::ReadParam(
            configPath,
            "DC_Reference_Slave_Index",
            -1.0);

    if (mode == "FIXED")
    {
        uint64_t dcSystemTime = 0;
        int dcWkc = 0;

        if (!ValidateDcReferenceCandidate(
            pMaster,
            fixedSlaveIndex,
            dcSystemTime,
            dcWkc))
        {
            RtPrintf(
                "[DC-REFERENCE] FAILED | "
                "Mode:FIXED | "
                "SlaveIndex:%d | "
                "Reason:Invalid index or 0x0910 validation failed | "
                "WKC:%d\n",

                fixedSlaveIndex,
                dcWkc);

            return false;
        }

        InterlockedExchange(
            &g_dcReferenceSlaveIndex,
            (LONG)fixedSlaveIndex);

        PrintSelectedDcReference(
            fixedSlaveIndex,
            "FIXED",
            dcSystemTime,
            dcWkc);

        return true;
    }

    if (mode != "AUTO")
    {
        RtPrintf(
            "[DC-REFERENCE] WARNING | "
            "Unknown mode:%s | Using AUTO.\n",

            mode.c_str());
    }

    if (pMaster->m_ServoList.empty())
    {
        RtPrintf(
            "[DC-REFERENCE] FAILED | "
            "Mode:AUTO | Servo list is empty.\n");

        return false;
    }

    for (size_t servoIndex = 0;
        servoIndex < pMaster->m_ServoList.size();
        servoIndex++)
    {
        int slaveIndex =
            pMaster->m_ServoList[servoIndex].slaveIndex;

        uint64_t dcSystemTime = 0;
        int dcWkc = 0;

        if (!ValidateDcReferenceCandidate(
            pMaster,
            slaveIndex,
            dcSystemTime,
            dcWkc))
        {
            RtPrintf(
                "[DC-REFERENCE] AUTO REJECT | "
                "Servo:%u | "
                "SlaveIndex:%d | "
                "WKC:%d\n",

                (unsigned int)servoIndex,
                slaveIndex,
                dcWkc);

            continue;
        }

        InterlockedExchange(
            &g_dcReferenceSlaveIndex,
            (LONG)slaveIndex);

        PrintSelectedDcReference(
            slaveIndex,
            "AUTO",
            dcSystemTime,
            dcWkc);

        return true;
    }

    RtPrintf(
        "[DC-REFERENCE] FAILED | "
        "Mode:AUTO | No servo passed 0x0910 validation.\n");

    return false;
}
