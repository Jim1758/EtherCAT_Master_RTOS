#pragma once

#include "HomeTypes.h"
#include "MotionExecutionContract.h"
#include "MotionAxisCommandMailbox.h"
#include <cstdint>

class MotionCore;
class PLCManager;
class NCManager;
struct AxisContext;


// ============================================================
// HomingManager
//
// G81 �M���I�y�{�޲z���C
//
// ¾�d�G
//
// 1. ���� G81 HomeRequest
// 2. ��X�ѻP HOME ���b
// 3. �޲z P0 �P�ɴM���I
// 4. �޲z P1 �� HomeOrder ���մM���I
// 5. �޲z�C�b HomeRuntime / HomeState
// 6. ���� Hard Limit HOME �ҥ~�P�_
// 7. ����Τ@�޲z DOG / Backoff / INDEX / Offset
//
// ���t�d�G
//
// - Servo PID ���h�p��
// - EtherCAT PDO ���o
// - PLC Ladder ����
// - �@�� G00 / JOG / MPG / INCH
//
// �u���B�ʤ��浹 MotionCore�G
//
// SEARCH DOG / LIMIT
//     -> VelocityMove()
//
// DOG / INDEX ���
//     -> StopMove()
//
// Backoff / Move To Zero
//     -> MoveToPosition()
//
// Alarm ���`
//     -> Emergency Stop
// ============================================================

class HomingManager
{
public:
    static constexpr int HOME_AXIS_COUNT = 8;

    enum class ResumeResult : std::uint8_t
    {
        REJECTED = 0,
        DEFERRED,
        APPLIED,
        SUPERSEDED
    };


    // ========================================================
    // Constructor
    //
    // MotionCore �@�w�s�b�A�ҥH�ϥ� Reference�C
    //
    // NCManager / PLCManager �i��b�t�Ϋغc��~�����A
    // �]���ϥ� Link API ����s���C
    // ========================================================

    explicit HomingManager(
        MotionCore& motion);


    // ========================================================
    // System Link
    // ========================================================

    void LinkNCManager(
        NCManager* nc);

    void LinkPLCManager(
        PLCManager* plc);


    // ========================================================
    // Start HOME
    //
    // request.axisMask�G
    //
    // Bit 0 = Axis 0
    // Bit 1 = Axis 1
    // ...
    // Bit 7 = Axis 7
    //
    // axisMask == 0�G
    //
    // �۰ʿ���G
    //
    // axis.isExist == true
    // &&
    // axis.home.enabled == true
    //
    // request.sequenceMode�G
    //
    // P0 = SIMULTANEOUS
    //      �Ҧ����w�b�P�ɶ}�l�C
    //
    // P1 = BY_ORDER
    //      �� axis.home.order ���հ���C
    //
    // true�G
    //      Request �w�����C
    //
    // false�G
    //      Request ���X�k�Ψt�Υثe����}�l HOME�C
    // ========================================================

    bool Start(
        const HomeRequest& request);


    // ========================================================
    // Cyclic Process
    //
    // cycleTimeSec�G
    //      �I�s���禡����ڶg���A�����C
    //
    // �Ĥ@���w�p�ѡG
    //
    // NCPLCManager::ProcessHomeInputs()
    //
    // �C�� PLC / NC Scan �I�s�C
    //
    // ����Y�ݭn��֪� Drive Capture �P�_�A
    // �i�N Reference Capture ���� PDO �h�A
    // HomingManager ���u�B�z���A�ಾ�C
    // ========================================================

    void Process(
        double cycleTimeSec);


    // ========================================================
    // Cancel / Reset
    //
    // Cancel�G
    //      ���b HOME �ɴ��X���`�����C
    //      �����@�|�勵�b���ʪ��b�ϥ� Controlled Stop�C
    //
    // Reset�G
    //      �N HomingManager �P�Ҧ� HomeRuntime �~�^��l���A�C
    //      ���N���b�w���� HOME�C
    // ========================================================

    // Feed Hold�G������t�ëO�d���� HOME Request / HomeState�C
    bool RequestHold();

    // Cycle Start�G�q PAUSED ��_�F�Y���b��t�A���ƤJ Resume Request�C
    ResumeResult Resume() noexcept;

    // Reset / Abort�G���������M���|�������� HOME Runtime�A���i��_�C
    void Cancel();

    void Reset();


    // ========================================================
    // Global State Query
    // ========================================================

    bool IsActive() const;

    bool IsCompleted() const;

    bool HasError() const;

    bool IsCancelRequested() const;

    bool IsHoldDecelerating() const;

    bool IsPaused() const;

    bool IsResumeRequested() const;

    HomeRunControlState GetRunControlState() const;


    // ========================================================
    // Request / Scheduler Query
    // ========================================================

    uint8_t GetSelectedAxisMask() const;

    uint8_t GetActiveAxisMask() const;

    HomeSequenceMode GetSequenceMode() const;

    int GetCurrentOrder() const;


    // ========================================================
    // Last Error Query
    //
    // Request ��l�ƥ��ѩ� Runtime �o�Ϳ��~�ɡA
    // �O���Ĥ@�ӥ��ѭ�]�P�b�s���C
    //
    // -1 = �L�S�w�b�C
    // ========================================================

    HomeErrorReason GetLastError() const;

    int GetLastErrorAxis() const;


    // ========================================================
    // Per-Axis Query
    // ========================================================

    bool IsAxisSelected(
        int axisIndex) const;

    bool IsAxisActive(
        int axisIndex) const;

    bool IsAxisCompleted(
        int axisIndex) const;

    bool IsAxisHoming(
        int axisIndex) const;

    HomeState GetAxisState(
        int axisIndex) const;

    HomeErrorReason GetAxisError(
        int axisIndex) const;


    // ========================================================
    // Expected HOME Hard Limit
    //
    // �� NCPLCManager::ProcessSafetyInputs() �ϥΡC
    //
    // ���`���A�G
    //
    // Physical +OT / -OT
    //     -> HARD_LIMIT Alarm
    //
    // LIMIT_INDEX / LIMIT_ONLY HOME�G
    //
    // �u���ŦX�H�U��������ɡA
    // �w����V�� Hard Limit �~�O HOME Event�G
    //
    // 1. �Ӷb���b HOME
    // 2. HomeMethod �ϥ� LIMIT
    // 3. HomeDirection �P Limit ��V�ۦP
    // 4. HomeState ��󤹳\��Ĳ / �h�X Limit �����q
    //
    // �ۤϤ�V Limit�G
    //     �û����O���` HOME Event�C
    //
    // +OT �P -OT �P�� ON�G
    //     �û��������`�C
    // ========================================================

    bool IsExpectedPositiveHardLimit(
        int axisIndex) const;

    bool IsExpectedNegativeHardLimit(
        int axisIndex) const;

    bool IsExpectedHomeHardLimit(
        int axisIndex,
        bool positiveDirection) const;


private:
    // ========================================================
    // Stage NC-0.1F - HOME ownership and RT command mailbox
    // ========================================================
    bool AcquireHomeMotionOwner() noexcept;
    void RestoreOrReleaseHomeMotionOwner() noexcept;
    MotionOwnerLease GetProbeCommandLease() const noexcept;

    bool QueueHomeStop(int axisIndex, double decelerationTime) noexcept;
    bool QueueHomeVelocity(
        int axisIndex, double velocity, double accelerationTime) noexcept;
    bool QueueHomeMove(
        int axisIndex, double targetPosition, double targetVelocity,
        double accelerationTime, double decelerationTime,
        bool useShortestPath) noexcept;
    bool QueueHomeProbeFunction(
        int axisIndex, uint16_t value,
        MotionAxisCommandSequence* outSequence = nullptr) noexcept;

    // ========================================================
    // Basic Validation
    // ========================================================

    bool IsValidAxisIndex(
        int axisIndex) const;

    bool IsAxisRequested(
        uint8_t axisMask,
        int axisIndex) const;

    uint8_t BuildEnabledAxisMask() const;


    // ========================================================
    // Request Initialization
    // ========================================================

    bool ValidateAndInitializeRequest(
        const HomeRequest& request,
        uint8_t selectedAxisMask);

    void ResetAxisRuntime(
        AxisContext& axis);

    void PrepareSelectedAxis(
        AxisContext& axis);


    // ========================================================
    // P0 / P1 Scheduler
    // ========================================================

    void ActivateInitialGroup();

    void ActivateAllSelectedAxes();

    void ActivateOrderGroup(
        int order);

    int FindLowestPendingOrder() const;

    bool HasPendingAxis() const;

    bool IsActiveGroupComplete() const;

    void AdvanceScheduler();


    // ========================================================
    // Per-Axis State Machine
    //
    // �o�@�B�u���ŧi�C
    // �u�� DOG / Backoff / INDEX Motion
    // �|�b����v State ��@�C
    // ========================================================

    void ProcessAxis(
        int axisIndex,
        AxisContext& axis,
        double cycleTimeSec);

    void ProcessCancel();
    void ProcessHold(double cycleTimeSec);
    ResumeResult TryResumeFromPaused() noexcept;
    void ClearResumeRequest() noexcept;

    bool MonitorSwitchDuringHold(int axisIndex, AxisContext& axis);
    bool MonitorReferenceDuringHold(int axisIndex, AxisContext& axis);
    double GetHoldDecTime(const AxisContext& axis) const;
    bool IsP2PResumeState(HomeState state) const;

    void ProcessBackoffBarrier();
    void ProcessIndexStopBarrier();

    bool ReadHomeSwitch(int axisIndex, AxisContext& axis, bool& active) const;
    bool ReadExternalReferenceInput(int axisIndex, const AxisContext& axis, bool& active) const;

    // Delta / CiA402 Drive Touch Probe Provider
    bool UsesDriveTouchProbe(const AxisContext& axis) const;
    bool ValidateDriveProbeConfig(const AxisContext& axis) const;
    bool ProcessDriveProbeArm(int axisIndex, AxisContext& axis, double cycleTimeSec);
    bool TryCaptureDriveProbe(int axisIndex, AxisContext& axis, bool& detected, double& capturedPulse);
    bool IsDriveProbeSourceStatusValid(const AxisContext& axis, uint16_t status) const;
    bool DisarmDriveProbe(
        int axisIndex, AxisContext& axis,
        bool trackForOwnerRelease = false);
    void ResetDriveProbeRuntime(AxisContext& axis);

    double GetPulsePerUnit(const AxisContext& axis) const;
    double GetTravelDistanceUnit(const AxisContext& axis, double startRawPulse) const;
    void EnterState(AxisContext& axis, HomeState state);


    // ========================================================
    // Completion / Error
    // ========================================================

    void CompleteAxis(
        int axisIndex,
        AxisContext& axis);

    void SetAxisError(
        int axisIndex,
        AxisContext& axis,
        HomeErrorReason error);

    void CompleteRequest();


    // ========================================================
    // HOME Method Helper
    // ========================================================

    bool UsesDogSwitch(
        HomeMethod method) const;

    bool UsesHardLimitSwitch(
        HomeMethod method) const;

    bool UsesIndexReference(
        HomeMethod method) const;

    bool IsHardLimitAllowedHomeState(
        HomeState state) const;


private:
    // ========================================================
    // Linked Systems
    // ========================================================

    MotionCore& m_motion;

    NCManager* m_nc =
        nullptr;

    PLCManager* m_plc =
        nullptr;


    // Stage NC-0.1F ownership snapshot.  G81 may transfer AUTO / MDI /
    // MANUAL_AUTO to HOME and restore a new generation when HOME finishes.
    MotionOwnerLease m_homeMotionLease{};
    MotionOwner m_returnMotionOwner = MotionOwner::NONE;
    MotionAxisCommandSequence
        m_pendingApplyHomeSequence[HOME_AXIS_COUNT]{};
    MotionAxisCommandSequence
        m_pendingProbeDisarmSequence[HOME_AXIS_COUNT]{};

    // ========================================================
    // Request State
    // ========================================================

    HomeSequenceMode m_sequenceMode =
        HomeSequenceMode::SIMULTANEOUS;

    uint8_t m_selectedAxisMask =
        0;

    uint8_t m_activeAxisMask =
        0;

    int m_currentOrder =
        -1;


    // ========================================================
    // Global Runtime State
    // ========================================================

    bool m_active =
        false;

    bool m_completed =
        false;

    bool m_hasError =
        false;

    bool m_cancelRequested =
        false;

    HomeRunControlState m_runControlState =
        HomeRunControlState::IDLE;

    // Cycle Start �i��b Hold ��t�����e�����U�C
    // ���X���� HomingManager �b�Ҧ��b�u�������۰ʫ�_�C
    bool m_resumeRequested =
        false;

    // Immutable Alarm/Motion identity captured by the operator Cycle Start.
    // A queued HOME resume may wait through controlled deceleration, but it
    // must never recapture a newer post-Alarm baseline and resume implicitly.
    std::uint32_t m_resumeAlarmUpdateCount =
        0U;

    std::uint64_t m_resumeAlarmIntentBaseState =
        0ULL;

    MotionOwnerLease m_resumeHomeMotionLease{};

    bool m_resumeAdmissionTicketValid =
        false;


    // ========================================================
    // First Error Snapshot
    // ========================================================

    HomeErrorReason m_lastError =
        HomeErrorReason::NONE;

    int m_lastErrorAxis =
        -1;
};
