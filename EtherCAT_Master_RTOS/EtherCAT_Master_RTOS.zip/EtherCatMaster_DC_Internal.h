#pragma once
#include <windows.h>

// =============================================================
// DC-RX.3F - deterministic test-only fault injection
//
// Startup reads D:\EtherCAT_Master_Data\DC_FaultInjection.txt once,
// validates an explicit arm token, and publishes this immutable config before
// the real PDO timer is created. Runtime executes at most one scenario per
// RTOS process. The normal production path remains OFF by default.
// =============================================================

enum class DcRx3fFaultScenario : LONG
{
    Off = 0,
    DcWkcDrop = 1,
    LrwWkcDrop = 2,
    ExactTimingMissing = 3,
    LateRtt = 4,
    DcTimestampRepeat = 5,
    DcTimestampBackward = 6,
    PhaseMapJump = 7,
    SchedulerRecovery = 8,
    LrwTimeout = 9
};

enum class DcRx3fFaultState : LONG
{
    Off = 0,
    WaitGate = 1,
    Delay = 2,
    Inject = 3,
    Recovery = 4,
    Pass = 5,
    Fail = 6
};

extern volatile LONG g_dcRx3fConfigReady;
extern volatile LONG g_dcRx3fConfiguredScenario;
extern volatile LONG g_dcRx3fConfiguredCycles;
extern volatile LONG g_dcRx3fConfiguredStartDelayCycles;
extern volatile LONGLONG g_dcRx3fConfiguredValueNs;
extern volatile LONG g_dcRx3fConfiguredRequireServoOff;
extern volatile LONG g_dcRx3fConfiguredAllowSafetyStop;

/*
 * �ɮסGEtherCatMaster_DC_Internal.h
 * �����GEtherCAT DC Release Candidate RC1.8
 *
 * ���ɮ׬O EtherCAT/DC �U�Ҳդ����������E�_�ַӤ����C
 * ���u�ŧi extern �ܼơA���إ߱����A�]�����汱��t��k�C
 *
 * �R�W�W�h�G
 * - *Sequence�Gseqlock �Ǹ��Fodd ���� writer ���b��s�Aeven ���ܧ����C
 * - *AvgNs/*MinNs/*MaxNs�G�@�Ӳέp���������`���ƭȡC
 * - *Total*�G�{�ǱҰʫ�ֿn�ȡA���|�]�C�� publish �k�s�C
 * - �S�� Total �� Count�G�q�`�O�̪�@�� 4000-cycle �������ȡC
 *
 * ������W�h�G
 * - Priority 64 �O�D�n writer�A�u�t�d�p�ƻP�ַӵo���C
 * - Priority 50 �O reader�A�����ϥ� Sequence + MemoryBarrier() Ū���C
 * - Reader ���o�z�L�o���ܼƤϦV�ק� PDO�BDC�BMotion �� NC ����C
 *
 * ���@�W�h�G
 * - �s�W snapshot ���ɡAdefinition�Bextern�Bwriter publish �P reader copy
 *   �����@�_��s�C
 * - 64-bit ��쥲����b seqlock �O�@�d��Ū�g�C
 */

 // =============================================================
 // �Ұ� Drift �]�w�P�۰ʮե��ַ�
 //
 // ConfigReady/ConfiguredMode/ConfiguredFixedPpb �� Startup �b���� PDO timer
 // �Ұʫe�g�J�C��l���� Priority 64 Runtime �o���APriority 50 �uŪ���C
 // Mode�G0=AUTO�B1=FIXED�CState�G0=WARMUP�B1=LOCKED�B2=FIXED�C
 // =============================================================

extern volatile LONG
g_dcDriftConfigReady;

extern volatile LONG
g_dcDriftConfiguredMode;

extern volatile LONGLONG
g_dcDriftConfiguredFixedPpb;

extern volatile LONG
g_dcDriftCalibrationDiagSequence;

extern volatile LONG
g_dcDriftCalibrationMode;

extern volatile LONG
g_dcDriftCalibrationState;

extern volatile LONG
g_dcDriftCalibrationCandidateGood;

extern volatile LONG
g_dcDriftCalibrationGoodWindows;

extern volatile LONG
g_dcDriftCalibrationRequiredWindows;

extern volatile LONG
g_dcDriftCalibrationRobustSequence;

extern volatile LONGLONG
g_dcDriftCalibrationRawPpb;

extern volatile LONGLONG
g_dcDriftCalibrationMedianPpb;

extern volatile LONGLONG
g_dcDriftCalibrationMadPpb;

extern volatile LONGLONG
g_dcDriftCalibrationRawMedianDeviationPpb;

extern volatile LONGLONG
g_dcDriftCalibrationBaselinePpb;

extern volatile LONG
g_dcDriftCalibrationLockCount;

// =============================================================
// PDO RT Diagnostic Snapshot
//
// �����ܼƩw�q�b EtherCatMaster.cpp
// �o�� Main Thread �uŪ���C
// =============================================================
// =============================================================
// DC PLL Diagnostic Snapshot
//
// Definition:
//     UpdateDCPdoPhaseController() �Ҧb .cpp
//
// Reader:
//     System_EDM_SINKER_MODE.cpp
// =============================================================

extern volatile LONG
g_dcPllDiagSequence;

extern volatile LONGLONG
g_dcPllDiagEstimatorSequence;

extern volatile LONGLONG
g_dcPllDiagEstimatorOffsetNs;

extern volatile LONGLONG
g_dcPllDiagDriftPpb;

extern volatile LONGLONG
g_dcPllDiagPdoPhaseNs;

extern volatile LONGLONG
g_dcPllDiagTargetPhaseNs;

extern volatile LONGLONG
g_dcPllDiagPhaseStepNs;

extern volatile LONGLONG
g_dcPllDiagWrappedErrorNs;

extern volatile LONGLONG
g_dcPllDiagUnwrappedErrorNs;

extern volatile LONGLONG
g_dcPllDiagSync0MarginNs;

extern volatile LONG
g_dcPllDiagTargetCaptured;

extern volatile LONG
g_dcPllDiagStableWindows;
extern volatile LONGLONG
g_dcPllDiagPCommandNs;

extern volatile LONGLONG
g_dcPllDiagPeriodCorrectionPs;
extern volatile LONG
g_pdoRtDiagSequence;


// PDO Timer
extern volatile LONGLONG
g_pdoRtTimerAvgNs;

extern volatile LONGLONG
g_pdoRtTimerMinNs;

extern volatile LONGLONG
g_pdoRtTimerMaxNs;

extern volatile LONG
g_pdoRtTimerShortCount;

extern volatile LONG
g_pdoRtTimerNormalCount;

extern volatile LONG
g_pdoRtTimerLongCount;


// EtherCAT Combined
extern volatile LONGLONG
g_pdoRtCombinedAvgNs;

extern volatile LONGLONG
g_pdoRtCombinedMinNs;

extern volatile LONGLONG
g_pdoRtCombinedMaxNs;


// PDO Execution
extern volatile LONGLONG
g_pdoRtExecAvgNs;

extern volatile LONGLONG
g_pdoRtExecMinNs;

extern volatile LONGLONG
g_pdoRtExecMaxNs;

extern volatile LONG
g_pdoRtExecOver250Count;

extern volatile LONG
g_pdoRtExecOver300Count;

extern volatile LONG
g_pdoRtExecOver400Count;


// WKC
extern volatile LONG
g_pdoRtLrwWkc;

extern volatile LONG
g_pdoRtDcWkc;

// DC-RX.3A - decoupled Process Data / DC transport quality snapshot
extern volatile LONG
g_pdoRtDcReferencePresent;

extern volatile LONG
g_pdoRtProcessDataValid;

extern volatile LONG
g_pdoRtDcTransportValid;

extern volatile LONG
g_pdoRtProcessInvalidStreak;

extern volatile LONG
g_pdoRtDcTransportInvalidStreak;

extern volatile LONG
g_pdoRtDcTransportInvalidMaxStreak;

extern volatile LONGLONG
g_pdoRtDcWkcInvalidTotal;

extern volatile LONGLONG
g_pdoRtDcOnlyInvalidTotal;

extern volatile LONGLONG
g_pdoRtDcTransportRecoveryTotal;

// DC-RX.3B bounded DC-only holdover / graded requalification snapshot
extern volatile LONG
g_pdoRtDcOnlyInvalidStreak;

extern volatile LONG
g_pdoRtDcOnlyInvalidMaxStreak;

extern volatile LONG
g_pdoRtDcHoldoverTier;

extern volatile LONG
g_pdoRtDcHoldoverCurrentCycles;

extern volatile LONG
g_pdoRtDcHoldoverMaxCycles;

extern volatile LONG
g_pdoRtDcGlitchDebt;

extern volatile LONG
g_pdoRtDcGlitchDebtMax;

extern volatile LONG
g_pdoRtDcGlitchDebtLimit;

extern volatile LONGLONG
g_pdoRtDcGraceAcceptedCyclesTotal;

extern volatile LONGLONG
g_pdoRtDcHoldoverEpisodeTotal;

extern volatile LONGLONG
g_pdoRtDcHoldoverEntryTotal;

extern volatile LONGLONG
g_pdoRtDcDegradedEntryTotal;

extern volatile LONGLONG
g_pdoRtDcRelockEntryTotal;

// DC-RX.3C sample freshness / stale-frame / phase-jump guard snapshot
extern volatile LONG
g_pdoRtDcSampleGuardState;

extern volatile LONG
g_pdoRtDcSampleQualified;

extern volatile LONG
g_pdoRtDcSampleGuardReasonMask;

extern volatile LONG
g_pdoRtDcSampleRejectStreak;

extern volatile LONG
g_pdoRtDcSampleRejectMaxStreak;

extern volatile LONGLONG
g_pdoRtDcSampleApproxAgeNs;

extern volatile LONGLONG
g_pdoRtDcSampleApproxAgeMaxNs;

extern volatile LONGLONG
g_pdoRtDcSampleQpcDeltaNs;

extern volatile LONGLONG
g_pdoRtDcSampleDcDeltaNs;

extern volatile LONGLONG
g_pdoRtDcSampleDeltaErrorNs;

extern volatile LONGLONG
g_pdoRtDcSampleDeltaToleranceNs;

extern volatile LONGLONG
g_pdoRtDcSampleAcceptedTotal;

extern volatile LONGLONG
g_pdoRtDcSampleRejectedTotal;

extern volatile LONGLONG
g_pdoRtDcSampleAnchorTotal;

extern volatile LONGLONG
g_pdoRtDcSampleReanchorTotal;

extern volatile LONGLONG
g_pdoRtDcSampleAgeRejectTotal;

extern volatile LONGLONG
g_pdoRtDcSampleOrderRejectTotal;

extern volatile LONGLONG
g_pdoRtDcSampleDeltaRejectTotal;

extern volatile LONG
g_pdoRtDcPhaseJumpGuardActive;

extern volatile LONG
g_pdoRtDcPhaseJumpGuardGoodWindows;

extern volatile LONG
g_pdoRtDcPhaseJumpGuardRequiredWindows;

extern volatile LONGLONG
g_pdoRtDcPhaseJumpLastNs;

extern volatile LONGLONG
g_pdoRtDcPhaseJumpMaxAbsNs;

extern volatile LONGLONG
g_pdoRtDcPhaseJumpArmTotal;

extern volatile LONGLONG
g_pdoRtDcPhaseJumpPassTotal;

extern volatile LONGLONG
g_pdoRtDcPhaseJumpRejectTotal;

extern volatile LONG
g_pdoRtDcPhaseMapSequence;

extern volatile LONG
g_pdoRtDcPhaseMapNew;

extern volatile LONG
g_pdoRtDcPhaseMapAgeGood;

extern volatile LONGLONG
g_pdoRtDcPhaseMapAgeNs;

extern volatile LONGLONG
g_pdoRtDcPhaseMapStaleTotal;

// DC-RX.3D exact TX/RX software timing anchor snapshot
extern volatile LONG
g_pdoRtDcTimingSource;

extern volatile LONG
g_pdoRtDcExactTimingLocked;

extern volatile LONG
g_pdoRtDcExactTimingValid;

extern volatile LONGLONG
g_pdoRtDcTimingSelectedRttNs;

extern volatile LONGLONG
g_pdoRtDcTimingExactRttNs;

extern volatile LONGLONG
g_pdoRtDcTimingExactRttMaxNs;

extern volatile LONGLONG
g_pdoRtDcTimingCallRttNs;

extern volatile LONGLONG
g_pdoRtDcTimingExcludedOverheadNs;

extern volatile LONGLONG
g_pdoRtDcTimingMidpointShiftNs;

extern volatile LONGLONG
g_pdoRtDcTimingMidpointShiftMaxAbsNs;

extern volatile LONGLONG
g_pdoRtDcTimingExactUseTotal;

extern volatile LONGLONG
g_pdoRtDcTimingFallbackUseTotal;

extern volatile LONGLONG
g_pdoRtDcTimingMissingAfterLockTotal;

extern volatile LONGLONG
g_pdoRtDcTimingSourceSwitchTotal;

extern volatile LONGLONG
g_pdoRtDcTimingRejectTotal;

// DC-RX.3E adaptive exact-RTT envelope / late-sample guard snapshot
extern volatile LONG
g_pdoRtDcRttGuardState;

extern volatile LONG
g_pdoRtDcRttGuardAccepted;

extern volatile LONG
g_pdoRtDcRttGuardWarmupSamples;

extern volatile LONG
g_pdoRtDcRttGuardWarmupRequired;

extern volatile LONGLONG
g_pdoRtDcRttGuardCurrentNs;

extern volatile LONGLONG
g_pdoRtDcRttGuardBaselineNs;

extern volatile LONGLONG
g_pdoRtDcRttGuardDeviationNs;

extern volatile LONGLONG
g_pdoRtDcRttGuardLimitNs;

extern volatile LONGLONG
g_pdoRtDcRttGuardExcessNs;

extern volatile LONG
g_pdoRtDcRttGuardOutlierStreak;

extern volatile LONG
g_pdoRtDcRttGuardOutlierMaxStreak;

extern volatile LONG
g_pdoRtDcRttGuardRebaseCandidateSamples;

extern volatile LONGLONG
g_pdoRtDcRttGuardAcceptedTotal;

extern volatile LONGLONG
g_pdoRtDcRttGuardRejectedTotal;

extern volatile LONGLONG
g_pdoRtDcRttGuardRebaseTotal;

extern volatile LONGLONG
g_pdoRtDcSampleRttRejectTotal;

// DC-RX.3F deterministic fault-injection runtime snapshot.
// These fields are diagnostic-only and remain inside the existing internal
// g_pdoRtDiagSequence seqlock; SHM/API layout is unchanged.
extern volatile LONG g_pdoRtDcFaultState;
extern volatile LONG g_pdoRtDcFaultScenario;
extern volatile LONG g_pdoRtDcFaultConfiguredCycles;
extern volatile LONG g_pdoRtDcFaultAppliedCycles;
extern volatile LONG g_pdoRtDcFaultStartDelayRemaining;
extern volatile LONG g_pdoRtDcFaultRecoveryCycles;
extern volatile LONG g_pdoRtDcFaultTargetWaitCycles;
extern volatile LONG g_pdoRtDcFaultActiveThisCycle;
extern volatile LONG g_pdoRtDcFaultGateBlockMask;
extern volatile LONG g_pdoRtDcFaultEvidenceMask;
extern volatile LONG g_pdoRtDcFaultFailureMask;
extern volatile LONG g_pdoRtDcFaultRequireServoOff;
extern volatile LONG g_pdoRtDcFaultAllowSafetyStop;
extern volatile LONGLONG g_pdoRtDcFaultValueNs;
extern volatile LONGLONG g_pdoRtDcFaultBaselineAppliedPpb;
extern volatile LONGLONG g_pdoRtDcFaultCurrentAppliedPpb;
extern volatile LONGLONG g_pdoRtDcFaultMaxAppliedDeltaPpb;
extern volatile LONG g_pdoRtDcFaultMaxPdoInvalidStreak;
extern volatile LONGLONG g_pdoRtDcFaultStartTick;
extern volatile LONGLONG g_pdoRtDcFaultLastAppliedTick;
extern volatile LONGLONG g_pdoRtDcFaultEndTick;

// =============================================================
// PDO Fine Scheduler Timing Diagnostic Snapshot
// =============================================================

extern volatile LONG
g_pdoFineDiagSequence;

extern volatile LONGLONG
g_pdoFineQpcFrequency;

extern volatile LONGLONG
g_pdoFineIntervalAvgNs;

extern volatile LONGLONG
g_pdoFineIntervalMinNs;

extern volatile LONGLONG
g_pdoFineIntervalMaxNs;

extern volatile LONGLONG
g_pdoFineWakeToEcatAvgNs;

extern volatile LONGLONG
g_pdoFineWakeToEcatMinNs;

extern volatile LONGLONG
g_pdoFineWakeToEcatMaxNs;

extern volatile LONGLONG
g_pdoFineQpcReadAvgNs;

extern volatile LONGLONG
g_pdoFineQpcReadMaxNs;

extern volatile LONG
g_pdoFineQpcValid;

// =============================================================
// EtherCAT Send Point Diagnostic Snapshot
// =============================================================

extern volatile LONG
g_ecatSendDiagSequence;

extern volatile LONGLONG
g_ecatSendBuildAvgNs;

extern volatile LONGLONG
g_ecatSendBuildMinNs;

extern volatile LONGLONG
g_ecatSendBuildMaxNs;

extern volatile LONGLONG
g_ecatSendCallAvgNs;

extern volatile LONGLONG
g_ecatSendCallMinNs;

extern volatile LONGLONG
g_ecatSendCallMaxNs;

extern volatile LONG
g_ecatSendQpcValid;


// =============================================================
// EtherCAT RX Soft/Hard Deadline Diagnostic Snapshot
//
// Publish �����G4000 �� ecx_LRW_FRMW()�C
// Soft Deadline�G205000 ns�F�W�L Soft �������� Hard �����īʥ]�i�����C
// Hard Deadline�G210000 ns�F�W�L Hard ���ʥ]���A�浹 PDO process image�C
//
// Calls/FirstRx/EmptyRx/InvalidFrame�G�̪�@�ӵ����C
// SoftLateAccepted/HardTimeout�G�̪�@�ӵ����C
// TotalSoftLateAccepted/TotalHardTimeout�G�{�ǱҰʫ�ä[�ֿn�C
// CurrentConsecutiveTimeout�G�ثe�s�� Hard Timeout ���ơC
// RecoveryAfterTimeout�GTimeout �᭫�s���즳�īʥ]�����ơC
// TimeoutPreReceive�G�I�s ReceivePacket() �e�w�W�L Hard Deadline�C
// TimeoutSleep0/1/2�G�J�� ABI �W�١FDC-RX.2 �_���� Timeout �e������ wait slice �ơC
// SleepCount�G�J�� ABI �W�١FDC-RX.2 �_�����` coarse wait slice �ơC
// EventWait*�GNAL RX event ���ݡB����Btimeout�Bfallback �P�Ӯɲέp�C
// ReceiveCallMaxNs�G�榸 ReceivePacket() ���̤j����ɶ��C
// TimeoutReceiveCallMaxNs�G�����y�� Hard Timeout �� ReceivePacket() �̤j�ɶ��C
// =============================================================

extern volatile LONG g_ecatRxDiagSequence;
extern volatile LONG g_ecatRxDiagCalls;
extern volatile LONG g_ecatRxDiagFirstRxSuccess;
extern volatile LONG g_ecatRxDiagEmptyRx;
extern volatile LONG g_ecatRxDiagInvalidFrame;
extern volatile LONG g_ecatRxDiagSoftLateAccepted;
extern volatile LONGLONG g_ecatRxDiagTotalSoftLateAccepted;
extern volatile LONGLONG g_ecatRxDiagSoftLateElapsedMaxNs;
extern volatile LONG g_ecatRxDiagHardTimeout;
extern volatile LONG g_ecatRxDiagPostReceiveLate;
extern volatile LONG g_ecatRxDiagCurrentConsecutiveTimeout;
extern volatile LONG g_ecatRxDiagMaxConsecutiveTimeout;
extern volatile LONGLONG g_ecatRxDiagTotalHardTimeout;
extern volatile LONG g_ecatRxDiagRecoveryAfterTimeout;
extern volatile LONG g_ecatRxDiagQpcFail;
extern volatile LONG g_ecatRxDiagSleepCount;
extern volatile LONG g_ecatRxDiagElapsedValid;
extern volatile LONGLONG g_ecatRxDiagElapsedAvgNs;
extern volatile LONGLONG g_ecatRxDiagElapsedMaxNs;
extern volatile LONG g_ecatRxDiagTimeoutPreReceive;
extern volatile LONG g_ecatRxDiagTimeoutSleep0;
extern volatile LONG g_ecatRxDiagTimeoutSleep1;
extern volatile LONG g_ecatRxDiagTimeoutSleep2;
extern volatile LONG g_ecatRxDiagTimeoutAttemptAvg;
extern volatile LONG g_ecatRxDiagTimeoutAttemptMax;
extern volatile LONGLONG g_ecatRxDiagReceiveCallMaxNs;
extern volatile LONGLONG g_ecatRxDiagTimeoutReceiveCallMaxNs;
extern volatile LONG g_ecatRxDiagWaitMode;
extern volatile LONG g_ecatRxDiagEventWaitCalls;
extern volatile LONG g_ecatRxDiagEventSignaled;
extern volatile LONG g_ecatRxDiagEventTimeout;
extern volatile LONG g_ecatRxDiagEventFailed;
extern volatile LONG g_ecatRxDiagEventStopped;
extern volatile LONG g_ecatRxDiagEventFallbackSleep;
extern volatile LONG g_ecatRxDiagEventWaitValid;
extern volatile LONGLONG g_ecatRxDiagEventWaitAvgNs;
extern volatile LONGLONG g_ecatRxDiagEventWaitMaxNs;
extern volatile LONG g_ecatRxDiagEventLastError;
extern volatile LONG g_ecatRxDiagSoftDeadlineNs;
extern volatile LONG g_ecatRxDiagHardDeadlineNs;


// =============================================================
// QPC <-> EtherCAT S4 DC Estimator Snapshot
// =============================================================

extern volatile LONG
g_qpcDcDiagSequence;

extern volatile LONGLONG
g_qpcDcQpcElapsedNs;

extern volatile LONGLONG
g_qpcDcDcElapsedNs;

extern volatile LONGLONG
g_qpcDcDeltaNs;

extern volatile LONGLONG
g_qpcDcDriftPpb;

extern volatile LONGLONG
g_qpcDcRttAvgNs;

extern volatile LONGLONG
g_qpcDcRttMinNs;

extern volatile LONGLONG
g_qpcDcRttMaxNs;

extern volatile LONG
g_qpcDcValidSamples;

extern volatile LONG
g_qpcDcRejectedSamples;

extern volatile LONG
g_qpcDcValid;


// =============================================================
// QPC <-> S4 Robust Drift Dry-Run V1 Snapshot
// =============================================================

extern volatile LONG
g_qpcDcRobustDiagSequence;

extern volatile LONGLONG
g_qpcDcRobustRawDriftPpb;

extern volatile LONGLONG
g_qpcDcRobustMedianDriftPpb;

extern volatile LONGLONG
g_qpcDcRobustMadPpb;

extern volatile LONGLONG
g_qpcDcRobustPeriodFfPs;

extern volatile LONG
g_qpcDcRobustBufferCount;

extern volatile LONG
g_qpcDcRobustCurrentAccepted;

extern volatile LONG
g_qpcDcRobustLocked;

extern volatile LONG
g_qpcDcRobustAcceptedTotal;

extern volatile LONG
g_qpcDcRobustRejectedTotal;


// =============================================================
// QPC <-> S4 Trusted Drift V1A Dry-Run Snapshot
// =============================================================

extern volatile LONG
g_qpcDcTrustedDiagSequence;

extern volatile LONGLONG
g_qpcDcTrustedRawDriftPpb;

extern volatile LONGLONG
g_qpcDcTrustedRobustMedianPpb;

extern volatile LONGLONG
g_qpcDcTrustedRobustMadPpb;

extern volatile LONGLONG
g_qpcDcTrustedDriftPpb;

extern volatile LONGLONG
g_qpcDcTrustedCandidateDeviationPpb;

extern volatile LONGLONG
g_qpcDcTrustedRawMedianDeviationPpb;

extern volatile LONGLONG
g_qpcDcTrustedSlewAppliedPpb;

extern volatile LONGLONG
g_qpcDcTrustedPeriodFfPs;

extern volatile LONG
g_qpcDcTrustedCandidateGood;

extern volatile LONG
g_qpcDcTrustedValid;

extern volatile LONG
g_qpcDcTrustedState;

extern volatile LONG
g_qpcDcTrustedWarmupGoodCount;

extern volatile LONG
g_qpcDcTrustedBadCount;

extern volatile LONG
g_qpcDcTrustedRecoveryGoodCount;

extern volatile LONG
g_qpcDcTrustedUpdateTotal;

extern volatile LONG
g_qpcDcTrustedHoldTotal;

extern volatile LONG
g_qpcDcTrustedUnlockTotal;

extern volatile LONG
g_qpcDcTrustedRelockTotal;


// =============================================================
// QPC <-> S4 Trusted Drift V1A
// Reject / Transition Reason Diagnostic Snapshot
// =============================================================

extern volatile LONG
g_qpcDcTrustedReasonDiagSequence;

extern volatile LONG
g_qpcDcTrustedRejectRobustAcceptTotal;

extern volatile LONG
g_qpcDcTrustedRejectRobustLockTotal;

extern volatile LONG
g_qpcDcTrustedRejectBufferNotFullTotal;

extern volatile LONG
g_qpcDcTrustedRejectMadTotal;

extern volatile LONG
g_qpcDcTrustedRejectCandidateDeviationTotal;

extern volatile LONG
g_qpcDcTrustedRejectRawMedianDeviationTotal;

extern volatile LONG
g_qpcDcTrustedCurrentRejectMask;

extern volatile LONG
g_qpcDcTrustedLastRejectMask;

extern volatile LONG
g_qpcDcTrustedMaxBadStreak;

extern volatile LONG
g_qpcDcTrustedWarmupToTrackTotal;

extern volatile LONG
g_qpcDcTrustedTrackToHoldTotal;

extern volatile LONG
g_qpcDcTrustedHoldToTrackTotal;

extern volatile LONG
g_qpcDcTrustedHoldToUntrustedTotal;

extern volatile LONG
g_qpcDcTrustedUntrustedToTrackTotal;

extern volatile LONG
g_qpcDcTrustedLastTransitionFrom;

extern volatile LONG
g_qpcDcTrustedLastTransitionTo;

extern volatile LONGLONG
g_qpcDcTrustedLastTransitionRawPpb;

extern volatile LONGLONG
g_qpcDcTrustedLastTransitionMedianPpb;

extern volatile LONGLONG
g_qpcDcTrustedLastTransitionMadPpb;

extern volatile LONGLONG
g_qpcDcTrustedLastTransitionTrustedPpb;


// =============================================================
// Trusted Drift -> QPC Live Feed-Forward Dry Run V1 Snapshot
// =============================================================

extern volatile LONG
g_qpcLiveFfDiagSequence;

extern volatile LONG
g_qpcLiveFfInitialized;

extern volatile LONG
g_qpcLiveFfMode;

extern volatile LONG
g_qpcLiveFfTrustedSnapshotValid;

extern volatile LONG
g_qpcLiveFfTrustedValid;

extern volatile LONG
g_qpcLiveFfTrustedState;

extern volatile LONGLONG
g_qpcLiveFfTrustedDriftPpb;

extern volatile LONGLONG
g_qpcLiveFfAppliedDriftPpb;

extern volatile LONGLONG
g_qpcLiveFfAppliedPeriodFfPs;

extern volatile LONGLONG
g_qpcLiveFfFixedErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowVsFixedTargetNs;

extern volatile LONGLONG
g_qpcLiveFfShadowWindowStartErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowWindowEndErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowWindowDeltaErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowWindowMinErrorNs;

extern volatile LONGLONG
g_qpcLiveFfShadowWindowMaxErrorNs;

extern volatile LONGLONG
g_qpcLiveFfTargetDeltaWindowStartNs;

extern volatile LONGLONG
g_qpcLiveFfTargetDeltaWindowEndNs;

extern volatile LONGLONG
g_qpcLiveFfTargetDeltaWindowDeltaNs;

extern volatile LONG
g_qpcLiveFfTrustedCyclesWindow;

extern volatile LONG
g_qpcLiveFfFallbackCyclesWindow;

extern volatile LONG
g_qpcLiveFfModeSwitchesWindow;

extern volatile LONGLONG
g_qpcLiveFfTotalTrustedCycles;

extern volatile LONGLONG
g_qpcLiveFfTotalFallbackCycles;

extern volatile LONG
g_qpcLiveFfTotalModeSwitches;

extern volatile LONG
g_qpcLiveFfInitCount;

extern volatile LONG
g_qpcLiveFfSamples;


// =============================================================
// Trusted Live-FF DC Phase Predictor Dry Run V1 Snapshot
// =============================================================

extern volatile LONG
g_qpcLiveFfDcPhaseDiagSequence;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseLastSampleQpc;

extern volatile LONG
g_qpcLiveFfDcPhaseInitialized;

extern volatile LONG
g_qpcLiveFfDcPhaseBoundInitCount;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseBaselinePhaseNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseBaselineSync0MarginNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedPhaseNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowPhaseNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedSync0MarginNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowSync0MarginNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWrappedErrorNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWrappedErrorNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedUnwrappedErrorNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowUnwrappedErrorNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowVsFixedNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWindowStartNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWindowEndNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWindowDeltaNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWindowMinNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedWindowMaxNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWindowStartNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWindowEndNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWindowDeltaNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWindowMinNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowWindowMaxNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseFixedAbsAvgNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseShadowAbsAvgNs;

extern volatile LONG
g_qpcLiveFfDcPhaseShadowBetterCount;

extern volatile LONG
g_qpcLiveFfDcPhaseShadowWorseCount;

extern volatile LONG
g_qpcLiveFfDcPhaseEqualCount;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseMapRttAvgNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseMapRttMinNs;

extern volatile LONGLONG
g_qpcLiveFfDcPhaseMapRttMaxNs;

extern volatile LONG
g_qpcLiveFfDcPhaseSamples;


// =============================================================
// S4 DC Phase Residual Drift Observer V1 Dry-Run Snapshot
// =============================================================

extern volatile LONG
g_qpcDcPhaseResidualDiagSequence;

extern volatile LONG
g_qpcDcPhaseResidualInitialized;

extern volatile LONG
g_qpcDcPhaseResidualBoundInitCount;

extern volatile LONGLONG
g_qpcDcPhaseResidualRawPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualMedianPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualMadPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualRecommendedSchedulerPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualTrustedDriftPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualTrustedMinusRecommendedPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualFixedWindowDeltaNs;

extern volatile LONGLONG
g_qpcDcPhaseResidualWindowElapsedNs;

extern volatile LONGLONG
g_qpcDcPhaseResidualWindowRttMaxNs;

extern volatile LONG
g_qpcDcPhaseResidualCurrentAccepted;

extern volatile LONG
g_qpcDcPhaseResidualBufferCount;

extern volatile LONG
g_qpcDcPhaseResidualLocked;

extern volatile LONG
g_qpcDcPhaseResidualAcceptedTotal;

extern volatile LONG
g_qpcDcPhaseResidualRejectedTotal;

extern volatile LONG
g_qpcDcPhaseResidualRejectElapsedTotal;

extern volatile LONG
g_qpcDcPhaseResidualRejectRttTotal;

extern volatile LONG
g_qpcDcPhaseResidualRejectMagnitudeTotal;

extern volatile LONGLONG
g_qpcDcPhaseResidualRingMinPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualRingMaxPpb;


// =============================================================
// S4 DC Phase Residual Drift Observer V1A Snapshot
// =============================================================

extern volatile LONG
g_qpcDcPhaseResidualV1ADiagSequence;

extern volatile LONG
g_qpcDcPhaseResidualV1AInitialized;

extern volatile LONG
g_qpcDcPhaseResidualV1ABoundInitCount;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1AMeanPhaseNs;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1APhaseSpanNs;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1APointTimeNs;

extern volatile LONG
g_qpcDcPhaseResidualV1APointAccepted;

extern volatile LONG
g_qpcDcPhaseResidualV1AMeanSamples;

extern volatile LONG
g_qpcDcPhaseResidualV1APointBufferCount;

extern volatile LONG
g_qpcDcPhaseResidualV1APairSlopeCount;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ATheilSenPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ASlopeMadPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ATimeSpanNs;

extern volatile LONG
g_qpcDcPhaseResidualV1ALocked;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ARecommendedSchedulerPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ATrustedDriftPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ATrustedMinusRecommendedPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1AWindowElapsedNs;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1AWindowRttMaxNs;

extern volatile LONG
g_qpcDcPhaseResidualV1AAcceptedPointTotal;

extern volatile LONG
g_qpcDcPhaseResidualV1ARejectedPointTotal;

extern volatile LONG
g_qpcDcPhaseResidualV1ARejectSamplesTotal;

extern volatile LONG
g_qpcDcPhaseResidualV1ARejectElapsedTotal;

extern volatile LONG
g_qpcDcPhaseResidualV1ARejectRttTotal;

extern volatile LONG
g_qpcDcPhaseResidualV1ARejectSpanTotal;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ASlopeMinPpb;

extern volatile LONGLONG
g_qpcDcPhaseResidualV1ASlopeMaxPpb;

extern volatile LONG g_qpcV1aCostSeq;
extern volatile LONGLONG g_qpcV1aCostLastNs;
extern volatile LONGLONG g_qpcV1aCostAvgNs;
extern volatile LONGLONG g_qpcV1aCostMaxNs;
extern volatile LONG g_qpcV1aCostEvents;
extern volatile LONG g_qpcV1aCostOver20us;
extern volatile LONG g_qpcV1aCostOver40us;
extern volatile LONG g_qpcV1aCostOver80us;
extern volatile LONG g_qpcV1aCostQpcFail;


// =============================================================
// Frequency FF Dry Run V2 Snapshot
// =============================================================

extern volatile LONG
g_qpcPhaseFfV2DiagSequence;

extern volatile LONG
g_qpcPhaseFfV2Initialized;

extern volatile LONG
g_qpcPhaseFfV2State;

extern volatile LONG
g_qpcPhaseFfV2CandidateGood;

extern volatile LONG
g_qpcPhaseFfV2WarmupGoodCount;

extern volatile LONG
g_qpcPhaseFfV2BadCount;

extern volatile LONG
g_qpcPhaseFfV2RecoveryGoodCount;

extern volatile LONG
g_qpcPhaseFfV2ObserverSequence;

extern volatile LONGLONG
g_qpcPhaseFfV2RecommendedPpb;

extern volatile LONGLONG
g_qpcPhaseFfV2DesiredPpb;

extern volatile LONGLONG
g_qpcPhaseFfV2AppliedPpb;

extern volatile LONGLONG
g_qpcPhaseFfV2SlewAppliedPpb;

extern volatile LONGLONG
g_qpcPhaseFfV2SlopeMadPpb;

extern volatile LONG
g_qpcPhaseFfV2Points;

extern volatile LONG
g_qpcPhaseFfV2Pairs;

extern volatile LONG
g_qpcPhaseFfV2ObserverLocked;

extern volatile LONG
g_qpcPhaseFfV2PointAccepted;

extern volatile LONGLONG
g_qpcPhaseFfV2TargetVsFixedNs;

extern volatile LONGLONG
g_qpcPhaseFfV2WakeErrorNs;

extern volatile LONGLONG
g_qpcPhaseFfV2TargetDeltaWindowStartNs;

extern volatile LONGLONG
g_qpcPhaseFfV2TargetDeltaWindowEndNs;

extern volatile LONGLONG
g_qpcPhaseFfV2TargetDeltaWindowDeltaNs;

extern volatile LONG
g_qpcPhaseFfV2TrackCyclesWindow;

extern volatile LONG
g_qpcPhaseFfV2HoldCyclesWindow;

extern volatile LONG
g_qpcPhaseFfV2FallbackCyclesWindow;

extern volatile LONG
g_qpcPhaseFfV2StateSwitchesWindow;

extern volatile LONG
g_qpcPhaseFfV2TotalStateSwitches;

extern volatile LONG
g_qpcPhaseFfV2WarmupToTrackTotal;

extern volatile LONG
g_qpcPhaseFfV2TrackToHoldTotal;

extern volatile LONG
g_qpcPhaseFfV2HoldToTrackTotal;

extern volatile LONG
g_qpcPhaseFfV2HoldToFallbackTotal;

extern volatile LONG
g_qpcPhaseFfV2FallbackToTrackTotal;

extern volatile LONG
g_qpcPhaseFfV2Samples;


// =============================================================
// Frequency FF Dry Run V2 - S4 DC Phase Comparison Snapshot
// =============================================================

extern volatile LONG
g_qpcPhaseFfV2DcDiagSequence;

extern volatile LONG
g_qpcPhaseFfV2DcInitialized;

extern volatile LONGLONG
g_qpcPhaseFfV2DcPhaseNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcSync0MarginNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcUnwrappedErrorNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcVsFixedNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcVsTrustedNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcWindowStartNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcWindowEndNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcWindowDeltaNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcWindowMinNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcWindowMaxNs;

extern volatile LONGLONG
g_qpcPhaseFfV2DcAbsAvgNs;

extern volatile LONG
g_qpcPhaseFfV2DcBetterThanFixed;

extern volatile LONG
g_qpcPhaseFfV2DcBetterThanTrusted;

extern volatile LONG
g_qpcPhaseFfV2DcSamples;


// =============================================================
// QPC Coarse Re-Anchor Dry Run V1 Snapshot
// =============================================================

extern volatile LONG g_qpcCoarseReanchorDiagSequence;
extern volatile LONG g_qpcCoarseReanchorInitialized;
extern volatile LONGLONG g_qpcCoarseReanchorRawErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorVirtualErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorVirtualMarginNs;
extern volatile LONGLONG g_qpcCoarseReanchorVirtualOffsetNs;
extern volatile LONGLONG g_qpcCoarseReanchorWindowStartErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorWindowEndErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorWindowDeltaErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorWindowMinErrorNs;
extern volatile LONGLONG g_qpcCoarseReanchorWindowMaxErrorNs;
extern volatile LONG g_qpcCoarseReanchorCorrectionEventsWindow;
extern volatile LONG g_qpcCoarseReanchorCorrectionTicksWindow;
extern volatile LONG g_qpcCoarseReanchorMaxTicksPerEventWindow;
extern volatile LONG g_qpcCoarseReanchorMultiTickEventsWindow;
extern volatile LONGLONG g_qpcCoarseReanchorTotalCorrectionEvents;
extern volatile LONGLONG g_qpcCoarseReanchorTotalCorrectionTicks;
extern volatile LONG g_qpcCoarseReanchorLastEventSpacingCycles;
extern volatile LONG g_qpcCoarseReanchorMinEventSpacingCycles;
extern volatile LONG g_qpcCoarseReanchorMaxEventSpacingCycles;
extern volatile LONGLONG g_qpcCoarseReanchorRobustMedianDriftPpb;
extern volatile LONGLONG g_qpcCoarseReanchorRobustMadPpb;
extern volatile LONG g_qpcCoarseReanchorRobustLocked;
extern volatile LONG g_qpcCoarseReanchorWindowSamples;
extern volatile LONG g_qpcCoarseReanchorOverflow;


// =============================================================
// QPC Scheduler Dry Run V1 Snapshot
// =============================================================

extern volatile LONG
g_qpcSchedulerDiagSequence;

extern volatile LONGLONG
g_qpcSchedulerTargetQpc;

extern volatile LONGLONG
g_qpcSchedulerActualQpc;

extern volatile LONGLONG
g_qpcSchedulerErrorCounts;

extern volatile LONGLONG
g_qpcSchedulerErrorNs;

extern volatile LONGLONG
g_qpcSchedulerWindowStartErrorNs;

extern volatile LONGLONG
g_qpcSchedulerWindowEndErrorNs;

extern volatile LONGLONG
g_qpcSchedulerWindowDeltaErrorNs;

extern volatile LONGLONG
g_qpcSchedulerWindowMinErrorNs;

extern volatile LONGLONG
g_qpcSchedulerWindowMaxErrorNs;

extern volatile LONGLONG
g_qpcSchedulerPeriodWholeCounts;

extern volatile LONGLONG
g_qpcSchedulerPeriodFractionScaled;

extern volatile LONGLONG
g_qpcSchedulerAssumedDriftPpb;

extern volatile LONG
g_qpcSchedulerWindowSamples;

extern volatile LONG
g_qpcSchedulerValid;

extern volatile LONG g_qpcRealFfV0Seq;
extern volatile LONG g_qpcRealFfV0State;
extern volatile LONG g_qpcRealFfV0PhaseGood;
extern volatile LONG g_qpcRealFfV0ArmGood;
extern volatile LONG g_qpcRealFfV0HoldMask;
extern volatile LONG g_qpcRealFfV0HistoryMask;
extern volatile LONG g_qpcRealFfV0CleanCycles;
extern volatile LONG g_qpcRealFfV0CleanCyclesRequired;
extern volatile LONG g_qpcRealFfV0TripMask;
extern volatile LONG g_qpcRealFfV0TripCount;
extern volatile LONGLONG g_qpcRealFfV0RecommendedPpb;
extern volatile LONGLONG g_qpcRealFfV0DesiredPpb;
extern volatile LONGLONG g_qpcRealFfV0AppliedPpb;
extern volatile LONGLONG g_qpcRealFfV0LastStepPpb;
extern volatile LONGLONG g_qpcRealFfV0TargetVsFixedNs;
extern volatile LONGLONG g_qpcRealFfV0DcErrEstNs;
extern volatile LONG g_qpcRealFfV0PhaseSeq;
extern volatile LONG g_qpcRealFfV0PhaseRejectMask;
extern volatile LONG g_qpcRealFfV0LastPhaseRejectMask;
extern volatile LONG g_qpcRealFfV0HoldGood;
extern volatile LONG g_qpcRealFfV0HoldBad;
extern volatile LONG g_qpcRealFfV0HoldEntries;
extern volatile LONG g_qpcRealFfV0ClampActive;
extern volatile LONG g_qpcRealFfV0RecoveryProfile;
extern volatile LONG g_qpcRealFfV0HoldRecoveryWindowsRequired;

extern volatile LONG g_qpcRealFfClampSelfTestSeq;
extern volatile LONG g_qpcRealFfClampSelfTestPass;
extern volatile LONG g_qpcRealFfClampSelfTestCases;
extern volatile LONG g_qpcRealFfClampSelfTestFail;
extern volatile LONGLONG g_qpcRealFfClampSelfTestRec0;
extern volatile LONGLONG g_qpcRealFfClampSelfTestDesired0;
extern volatile LONG g_qpcRealFfClampSelfTestClamp0;
extern volatile LONGLONG g_qpcRealFfClampSelfTestRec1;
extern volatile LONGLONG g_qpcRealFfClampSelfTestDesired1;
extern volatile LONG g_qpcRealFfClampSelfTestClamp1;
extern volatile LONGLONG g_qpcRealFfClampSelfTestRec2;
extern volatile LONGLONG g_qpcRealFfClampSelfTestDesired2;
extern volatile LONG g_qpcRealFfClampSelfTestClamp2;
extern volatile LONGLONG g_qpcRealFfClampSelfTestRec3;
extern volatile LONGLONG g_qpcRealFfClampSelfTestDesired3;
extern volatile LONG g_qpcRealFfClampSelfTestClamp3;
extern volatile LONGLONG g_qpcRealFfClampSelfTestRec4;
extern volatile LONGLONG g_qpcRealFfClampSelfTestDesired4;
extern volatile LONG g_qpcRealFfClampSelfTestClamp4;

extern volatile LONG g_qpcPhasePActV0Seq;
extern volatile LONG g_qpcPhasePActV0State;
extern volatile LONG g_qpcPhasePActV0GateGood;
extern volatile LONG g_qpcPhasePActV0ArmGood;
extern volatile LONGLONG g_qpcPhasePActV0BaseErrNs;
extern volatile LONGLONG g_qpcPhasePActV0ActualErrNs;
extern volatile LONGLONG g_qpcPhasePActV0WrappedErrNs;
extern volatile LONGLONG g_qpcPhasePActV0RawCorrectionNs;
extern volatile LONGLONG g_qpcPhasePActV0CommandNs;
extern volatile LONGLONG g_qpcPhasePActV0StepNs;
extern volatile LONGLONG g_qpcPhasePActV0OffsetNs;
extern volatile LONGLONG g_qpcPhasePActV0PredictedErrNs;
extern volatile LONG g_qpcPhasePActV0CommandSat;
extern volatile LONG g_qpcPhasePActV0OffsetSat;
extern volatile LONG g_qpcPhasePActV0Improve;
extern volatile LONG g_qpcPhasePActV0HoldGood;
extern volatile LONG g_qpcPhasePActV0HoldEntries;
extern volatile LONG g_qpcPhasePActV0TripCount;
extern volatile LONG g_qpcPhasePActV0RealFfState;

// =============================================================
// QPC Scheduler Re-Anchor + Guard V1B
// =============================================================

extern volatile LONG
g_qpcSchedulerState;

extern volatile LONGLONG
g_qpcSchedulerGuardNs;

extern volatile LONGLONG
g_qpcSchedulerRemainingToTargetNs;

extern volatile LONGLONG
g_qpcSchedulerLateByNs;

extern volatile LONGLONG
g_qpcSchedulerAnchorQpc;

extern volatile LONG
g_qpcSchedulerAnchorDcDiagSequence;

extern volatile LONG
g_qpcSchedulerStableWaitCycles;

extern volatile LONG
g_qpcSchedulerEarlyCount;

extern volatile LONG
g_qpcSchedulerNearCount;

extern volatile LONG
g_qpcSchedulerLateCount;

// =============================================================
// PDO One-Shot Bootstrap Fallback Diagnostic V1 Snapshot
// =============================================================

extern volatile LONG g_pdoBootstrapDiagSequence;

extern volatile LONG g_pdoBootstrapWindowBootstrap;
extern volatile LONG g_pdoBootstrapCurrentConsecutive;
extern volatile LONG g_pdoBootstrapMaxConsecutive;
extern volatile LONGLONG g_pdoBootstrapTotal;
extern volatile LONG g_pdoBootstrapRecoveryAfterBootstrap;

extern volatile LONG g_pdoBootstrapReasonNotReady;
extern volatile LONG g_pdoBootstrapReasonFinalUnderGuard;
extern volatile LONG g_pdoBootstrapReasonQpcBeforeArmFail;
extern volatile LONG g_pdoBootstrapReasonLeadTooShort;
extern volatile LONG g_pdoBootstrapReasonOther;

extern volatile LONG g_pdoBootstrapSchedulerInitialized;

extern volatile LONG g_pdoBootstrapPredictedLeadValid;
extern volatile LONGLONG g_pdoBootstrapPredictedLeadAvgNs;
extern volatile LONGLONG g_pdoBootstrapPredictedLeadMinNs;
extern volatile LONGLONG g_pdoBootstrapPredictedLeadMaxNs;

extern volatile LONGLONG g_pdoBootstrapSchedulerErrorNs;
extern volatile LONGLONG g_pdoBootstrapSchedulerLateByNs;

extern volatile LONG g_pdoRuntimeRecoveryWindowEvents;
extern volatile LONG g_pdoRuntimeRecoveryWindowSkippedCycles;
extern volatile LONG g_pdoRuntimeRecoveryMaxSkipCycles;
extern volatile LONGLONG g_pdoRuntimeRecoveryTotalEvents;
extern volatile LONGLONG g_pdoRuntimeRecoveryTotalSkippedCycles;
extern volatile LONGLONG g_pdoRuntimeRecoveryLastLeadBeforeNs;
extern volatile LONGLONG g_pdoRuntimeRecoveryLastLeadAfterNs;

extern volatile LONG g_pdoRecoveryForensicSeq;
extern volatile LONG g_pdoRecoveryForensicCaptured;
extern volatile LONGLONG g_pdoRecoveryForensicWakeIntervalNs;
extern volatile LONGLONG g_pdoRecoveryForensicLeadAtWakeNs;
extern volatile LONGLONG g_pdoRecoveryForensicWakeToArmNs;
extern volatile LONGLONG g_pdoRecoveryForensicLeadAtArmNs;
extern volatile LONGLONG g_pdoRecoveryForensicLeadAfterNs;
extern volatile LONG g_pdoRecoveryForensicSkipCycles;

extern volatile LONG g_pdoRecoverySelfTestSeq;
extern volatile LONG g_pdoRecoverySelfTestPass;
extern volatile LONG g_pdoRecoverySelfTestCases;
extern volatile LONG g_pdoRecoverySelfTestFail;
extern volatile LONGLONG g_pdoRecoverySelfTestBefore0;
extern volatile LONGLONG g_pdoRecoverySelfTestAfter0;
extern volatile LONG g_pdoRecoverySelfTestSkip0;
extern volatile LONGLONG g_pdoRecoverySelfTestBefore1;
extern volatile LONGLONG g_pdoRecoverySelfTestAfter1;
extern volatile LONG g_pdoRecoverySelfTestSkip1;
extern volatile LONGLONG g_pdoRecoverySelfTestBefore2;
extern volatile LONGLONG g_pdoRecoverySelfTestAfter2;
extern volatile LONG g_pdoRecoverySelfTestSkip2;
extern volatile LONGLONG g_pdoRecoverySelfTestBefore3;
extern volatile LONGLONG g_pdoRecoverySelfTestAfter3;
extern volatile LONG g_pdoRecoverySelfTestSkip3;
extern volatile LONG g_pdoRecoverySelfTestShadowPreserve;


// =============================================================
// PDO One-Shot Scheduler V1A Infrastructure Snapshot
//
// Producer:
//     GlobalTimerHandler_PDO() / EtherCatMaster.cpp
//
// Reader:
//     Main Priority 50 here.
//
// V1A is diagnostic only:
//     ControlEnabled  = 0
//     FineWaitEnabled = 0
// =============================================================

extern volatile LONG
g_pdoOneShotInfraSequence;

extern volatile LONG
g_pdoOneShotInfraState;

extern volatile LONG
g_pdoOneShotInfraValid;

extern volatile LONG
g_pdoOneShotInfraControlEnabled;

extern volatile LONG
g_pdoOneShotInfraFineWaitEnabled;

extern volatile LONG
g_pdoOneShotInfraWarmupRequired;

extern volatile LONG
g_pdoOneShotInfraWarmupComplete;

extern volatile LONGLONG
g_pdoOneShotInfraQpcFrequency;

extern volatile LONGLONG
g_pdoOneShotInfraFinalTargetQpc;

extern volatile LONGLONG
g_pdoOneShotInfraCoarseTargetQpc;

extern volatile LONGLONG
g_pdoOneShotInfraActualWakeQpc;

extern volatile LONGLONG
g_pdoOneShotInfraGuardNs;

extern volatile LONGLONG
g_pdoOneShotInfraToCoarseNs;

extern volatile LONGLONG
g_pdoOneShotInfraToFinalNs;

extern volatile LONGLONG
g_pdoOneShotInfraFinalLateByNs;

extern volatile LONG
g_pdoOneShotInfraDcDiagSequence;

extern volatile LONG
g_pdoOneShotInfraWindowSamples;

extern volatile LONG
g_pdoOneShotInfraReadyCount;

extern volatile LONG
g_pdoOneShotInfraCoarseWindowCount;

extern volatile LONG
g_pdoOneShotInfraFinalLateCount;


// =============================================================
// PDO One-Shot Scheduler V1B Live Bridge
// Definition: EtherCatMaster.cpp
// =============================================================

extern HANDLE
g_pdoOneShotTimerHandle;

extern volatile LONG
g_pdoOneShotStartupMode;

extern volatile LONG
g_pdoOneShotWarmupCallbackDone;


extern volatile LONG
g_pdoOneShotInfraRearmOkCount;

extern volatile LONG
g_pdoOneShotInfraRearmFailCount;

extern volatile LONG
g_pdoOneShotInfraBootstrapCount;

extern volatile LONG
g_pdoOneShotInfraActiveCount;

extern volatile LONGLONG
g_pdoOneShotInfraCoarseErrorAvgNs;

extern volatile LONGLONG
g_pdoOneShotInfraCoarseErrorMinNs;

extern volatile LONGLONG
g_pdoOneShotInfraCoarseErrorMaxNs;

extern volatile LONGLONG
g_pdoOneShotInfraFinalMarginAvgNs;

extern volatile LONGLONG
g_pdoOneShotInfraFinalMarginMinNs;

extern volatile LONGLONG
g_pdoOneShotInfraFinalMarginMaxNs;

extern volatile LONGLONG
g_pdoOneShotInfraRearmCostAvgNs;

extern volatile LONGLONG
g_pdoOneShotInfraRearmCostMinNs;

extern volatile LONGLONG
g_pdoOneShotInfraRearmCostMaxNs;
