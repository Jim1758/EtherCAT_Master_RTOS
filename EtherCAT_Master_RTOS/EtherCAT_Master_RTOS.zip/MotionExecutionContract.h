#pragma once

#include <cstdint>
#include <type_traits>

// ============================================================================
// Motion Execution Contract
//
// NC / Manual / Home / EDM �P Motion Runtime �����@�Ϊ��G
//
//     Execution Epoch
//     Segment Identity
//     Motion Owner
//     Motion Feedback Event
//
// �Ҧ������� Payload �������O�� trivially-copyable�A
// �~��w����J�T�w�e�q Lock-Free Ring�C
// ============================================================================

using MotionExecutionEpoch = std::uint32_t;
using MotionSegmentId = std::uint64_t;
using MotionSourceBlockId = std::int32_t;
using MotionFeedbackSequence = std::uint64_t;
using MotionOwnerGeneration = std::uint32_t;

constexpr MotionExecutionEpoch MOTION_EXECUTION_EPOCH_INVALID = 0U;
constexpr MotionSegmentId MOTION_SEGMENT_ID_INVALID = 0ULL;
constexpr MotionSourceBlockId MOTION_SOURCE_BLOCK_ID_INVALID = -1;
constexpr MotionFeedbackSequence MOTION_FEEDBACK_SEQUENCE_INVALID = 0ULL;
constexpr MotionOwnerGeneration MOTION_OWNER_GENERATION_INVALID = 0U;

// �R�O�ѭ��@�ӤW�h�l�t�β��͡C
enum class MotionCommandSource : std::uint8_t
{
    UNKNOWN = 0,
    NC_MEMORY = 1,
    NC_MDI = 2,
    NC_MANUAL_AUTO = 3,
    JOG = 4,
    MPG = 5,
    HOME = 6,
    EDM_PATH = 7,
    EDM_RETRACT = 8,
    RECOVERY = 9,
    SAFETY = 10
};

// ���@�Ӥl�t�Υثe�֦� Motion �����v�C
enum class MotionOwner : std::uint8_t
{
    NONE = 0,
    AUTO = 1,
    MDI = 2,
    MANUAL_AUTO = 3,
    JOG = 4,
    MPG = 5,
    HOME = 6,
    EDM_PATH = 7,
    EDM_RETRACT = 8,
    RECOVERY = 9,
    SAFETY = 10
};

// Stage NC-0.1E�GMotion �����v�����C
//
// owner�G�ثe���� Motion ���l�t�ΡC
// generation�G�C���u����γ����W�C�°���������� Lease �Y�ϱߨ�A
//             �u�n Generation ���P�A�N����������~��ϥηs�������v�C
struct MotionOwnerLease
{
    MotionOwner owner = MotionOwner::NONE;
    MotionOwnerGeneration generation = MOTION_OWNER_GENERATION_INVALID;

    bool IsValid() const noexcept
    {
        return
            owner != MotionOwner::NONE &&
            generation != MOTION_OWNER_GENERATION_INVALID;
    }

    bool Matches(const MotionOwnerLease& other) const noexcept
    {
        return
            owner == other.owner &&
            generation == other.generation;
    }
};

inline MotionOwner ResolveMotionOwnerForSource(
    MotionCommandSource source) noexcept
{
    switch (source)
    {
    case MotionCommandSource::NC_MEMORY:      return MotionOwner::AUTO;
    case MotionCommandSource::NC_MDI:         return MotionOwner::MDI;
    case MotionCommandSource::NC_MANUAL_AUTO: return MotionOwner::MANUAL_AUTO;
    case MotionCommandSource::JOG:            return MotionOwner::JOG;
    case MotionCommandSource::MPG:            return MotionOwner::MPG;
    case MotionCommandSource::HOME:           return MotionOwner::HOME;
    case MotionCommandSource::EDM_PATH:       return MotionOwner::EDM_PATH;
    case MotionCommandSource::EDM_RETRACT:    return MotionOwner::EDM_RETRACT;
    case MotionCommandSource::RECOVERY:       return MotionOwner::RECOVERY;
    case MotionCommandSource::SAFETY:         return MotionOwner::SAFETY;
    case MotionCommandSource::UNKNOWN:
    default:                                  return MotionOwner::NONE;
    }
}

inline MotionCommandSource ResolveMotionCommandSourceForOwner(
    MotionOwner owner) noexcept
{
    switch (owner)
    {
    case MotionOwner::AUTO:         return MotionCommandSource::NC_MEMORY;
    case MotionOwner::MDI:          return MotionCommandSource::NC_MDI;
    case MotionOwner::MANUAL_AUTO:  return MotionCommandSource::NC_MANUAL_AUTO;
    case MotionOwner::JOG:          return MotionCommandSource::JOG;
    case MotionOwner::MPG:          return MotionCommandSource::MPG;
    case MotionOwner::HOME:         return MotionCommandSource::HOME;
    case MotionOwner::EDM_PATH:     return MotionCommandSource::EDM_PATH;
    case MotionOwner::EDM_RETRACT:  return MotionCommandSource::EDM_RETRACT;
    case MotionOwner::RECOVERY:     return MotionCommandSource::RECOVERY;
    case MotionOwner::SAFETY:       return MotionCommandSource::SAFETY;
    case MotionOwner::NONE:
    default:                        return MotionCommandSource::UNKNOWN;
    }
}

// Motion Runtime �^�����W�h���ƥ�����C
//
// Stage NC-0.1D �������͡G
//
//     ACCEPTED
//     REJECTED
//     STARTED
//     COMPLETED
//     ABORTED
//     FAULTED
//
// PROGRESS / HELD / RESUMED / CANCELLED �O�d�����򶥬q�C
enum class MotionFeedbackType : std::uint8_t
{
    NONE = 0,
    ACCEPTED = 1,
    REJECTED = 2,
    STARTED = 3,
    PROGRESS = 4,
    HELD = 5,
    RESUMED = 6,
    COMPLETED = 7,
    CANCELLED = 8,
    FAULTED = 9,
    ABORTED = 10
};

// �R�O�Q Motion Runtime �ڵ��ɪ���]�C
enum class MotionRejectReason : std::uint8_t
{
    NONE = 0,
    STALE_EPOCH = 1,
    QUEUE_FULL = 2,
    OWNER_CONFLICT = 3,
    NOT_READY = 4,
    INVALID_AXIS = 5,
    INVALID_GEOMETRY = 6,
    SAFETY_INTERLOCK = 7,

    // �T�w�e�q Command / Replay / Feedback Transport �L�k�O�ҥ�I�C
    TRANSPORT_OVERFLOW = 8
};

// �C�@�� Motion �R�O��������Q�ߤ@�l�ܡC
//
// epoch�G
//     Reset / GOTO / ���s�W���ɻ��W�F�� epoch �R�O���o�A����C
//
// segmentId�G
//     ���t�γ�ջ��W�����|�q�ѧO�X�C
//
// sourceBlockId�G
//     ���� NC ��l Block�F��ʩR�O�i���� INVALID�C
struct MotionExecutionIdentity
{
    MotionExecutionEpoch epoch = MOTION_EXECUTION_EPOCH_INVALID;
    MotionSegmentId segmentId = MOTION_SEGMENT_ID_INVALID;
    MotionSourceBlockId sourceBlockId = MOTION_SOURCE_BLOCK_ID_INVALID;
    MotionCommandSource source = MotionCommandSource::UNKNOWN;

    bool IsAssigned() const noexcept
    {
        return
            epoch != MOTION_EXECUTION_EPOCH_INVALID &&
            segmentId != MOTION_SEGMENT_ID_INVALID;
    }

    bool Matches(
        const MotionExecutionIdentity& other) const noexcept
    {
        return
            epoch == other.epoch &&
            segmentId == other.segmentId;
    }
};

// �T�w�e�q Feedback Ring �ϥΪ��ƥ�榡�C
//
// sequence�G
//     �� 250 us Motion Runtime ��@ Producer �t�o�F0 �O�d�� INVALID�C
//     NC �i�Υ��ˬd�ƥ󶶧ǻP�O�_�o�Ϳ򥢡C
//
// owner / ownerGeneration�G
//     �Ӧ۩R�O��ګ����� MotionOwnerLease�C
//     �i�Ψӿ��ѦP�@�� Owner �����P����@�N�C
//
// progress�G
//     0.0 ~ 1.0�CCOMPLETED �T�w�� 1.0�FABORTED / FAULTED �O�s���U�i�סC
struct MotionFeedbackEvent
{
    MotionFeedbackSequence sequence = MOTION_FEEDBACK_SEQUENCE_INVALID;
    MotionExecutionIdentity identity{};
    MotionFeedbackType type = MotionFeedbackType::NONE;
    MotionRejectReason rejectReason = MotionRejectReason::NONE;
    MotionOwner owner = MotionOwner::NONE;
    MotionOwnerGeneration ownerGeneration = MOTION_OWNER_GENERATION_INVALID;
    std::uint32_t errorCode = 0U;
    double progress = 0.0;
};

static_assert(
    std::is_standard_layout<MotionExecutionIdentity>::value,
    "MotionExecutionIdentity must remain standard-layout.");

static_assert(
    std::is_trivially_copyable<MotionExecutionIdentity>::value,
    "MotionExecutionIdentity must remain trivially copyable.");

static_assert(
    std::is_standard_layout<MotionOwnerLease>::value,
    "MotionOwnerLease must remain standard-layout.");

static_assert(
    std::is_trivially_copyable<MotionOwnerLease>::value,
    "MotionOwnerLease must remain trivially copyable.");

static_assert(
    std::is_standard_layout<MotionFeedbackEvent>::value,
    "MotionFeedbackEvent must remain standard-layout.");

static_assert(
    std::is_trivially_copyable<MotionFeedbackEvent>::value,
    "MotionFeedbackEvent must remain trivially copyable.");
