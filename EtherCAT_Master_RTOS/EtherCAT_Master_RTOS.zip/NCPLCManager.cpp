#include "NCPLCManager.h"
#include "NCManager.h"
#include "MotionCore.h"
#include "PLCManager.h"
#include "NCPLCMap.h"
#include "AlarmManager.h"
#include <cstdint>
#include <cmath>

// =========================================================
// Constructor
// =========================================================
NCPLCManager::NCPLCManager(NCManager& nc, MotionCore& motion, PLCManager& plc)
    : m_nc(nc), m_motion(motion), m_plc(plc)
{
    m_lastMPGCount = static_cast<int32_t>(m_plc.GetMemory("DR", NCPLC::DR::MPG_ENCODER_COUNT)); // MPG DR200 baseline. Avoid a startup jump if DR200 is already non-zero.
}

// ============================================================================
// Stage NC-0.1F - Manual Motion Owner / Axis Command Mailbox Helpers
// ============================================================================
MotionCommandSource NCPLCManager::GetManualCommandSource() const noexcept
{
    return ResolveMotionCommandSourceForOwner(m_manualMotionLease.owner);
}

bool NCPLCManager::QueueManualStop(
    int axisIndex, double decelerationTime) noexcept
{
    return m_motion.SubmitAxisStopMove(
        axisIndex, decelerationTime, GetManualCommandSource(),
        m_manualMotionLease);
}

bool NCPLCManager::QueueManualVelocity(
    int axisIndex, double velocity, double accelerationTime) noexcept
{
    return m_motion.SubmitAxisVelocityMove(
        axisIndex, velocity, accelerationTime, GetManualCommandSource(),
        m_manualMotionLease);
}

bool NCPLCManager::QueueManualMPG(
    int axisIndex, double targetPosition, double maximumVelocity,
    double accelerationTime, double decelerationTime) noexcept
{
    return m_motion.SubmitAxisMPGMove(
        axisIndex, targetPosition, maximumVelocity, accelerationTime,
        decelerationTime, GetManualCommandSource(), m_manualMotionLease);
}

bool NCPLCManager::QueueManualMove(
    int axisIndex, double targetPosition, double targetVelocity,
    double accelerationTime, double decelerationTime,
    bool useShortestPath) noexcept
{
    return m_motion.SubmitAxisMoveToPosition(
        axisIndex, targetPosition, targetVelocity, accelerationTime,
        decelerationTime, useShortestPath, GetManualCommandSource(),
        m_manualMotionLease);
}

bool NCPLCManager::HasActiveManualAxis() const noexcept
{
    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        if (m_jogActive[i]) return true;
    }
    return false;
}

void NCPLCManager::ReleaseManualMotionOwnerIfStopped() noexcept
{
    if (m_manualMoveMode != ManualMoveMode::NONE ||
        HasActiveManualAxis())
    {
        return;
    }

    if (m_manualMotionLease.IsValid())
    {
        m_motion.ReleaseMotionOwner(m_manualMotionLease);
    }
    m_manualMotionLease = MotionOwnerLease{};
}

// =========================================================
// Main Cyclic Process
// =========================================================
void NCPLCManager::Process()
{
    // Single control-side consumer for RT mailbox results.
    m_motion.ProcessAxisCommandResults();

    ProcessSafetyInputs(); // 1. Safety First

    // =====================================================
    // 2. Active Safety Input Gate
    // C5 Emergency, C140~147 Axis Protection
    // �u�n�o�� Level Safety Input �٦s�b�A�᭱�� Start / Reset / JOG / HOME / AUX �����T��C
    // Hard Limit C180/C190 ����b�o�̡A�]������ݭn���\�Ϥ�V Recovery�C
    // =====================================================
    bool safetyInputActive = m_plc.Get_C(NCPLC::C::EMERGENCY_STOP);

    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        const bool axisProtect = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::AXIS_PROTECT_STOP_BASE, i));
        if (axisProtect)
        {
            safetyInputActive = true;
            break;
        }
    }

    if (safetyInputActive)
    {
        m_lastMPGCount = static_cast<int32_t>(m_plc.GetMemory("DR", NCPLC::DR::MPG_ENCODER_COUNT)); // Safety gate skips ProcessManualInputs(). Keep DR200 baseline synchronized so clearing safety cannot replay handwheel counts accumulated during the stop.
        SyncNCStateToPLC();
        return;
    }

    // 3. PLC -> NC
    ProcessGlobalInputs();
    ProcessHomeInputs();
    ProcessManualInputs();
    ProcessAuxiliaryHandshake();

    // 4. NC -> PLC
    SyncNCStateToPLC();
}

// =========================================================
// Global PLC Inputs
// =========================================================
void NCPLCManager::ProcessGlobalInputs()
{
    m_servoReady = m_plc.Get_C(NCPLC::C::SERVO_READY); // C11 - Servo / Machine Ready (Level Signal)
    m_nc.SetExternalReadyInterlock(m_servoReady);

    // =====================================================
    // C12 - Cycle Start (Rising Edge)
    // Cycle Start �����T�{�G1. C11 Servo Ready 2. �S������ Hard Limit 3. ���b���� Manual Move Mode 4. �S�� JOG Axis �٦b�ʧ@
    // =====================================================
    const bool cycleStart = m_plc.Get_C(NCPLC::C::CYCLE_START);

    if (cycleStart && !m_prevCycleStart)
    {
        // =================================================
        // HOME Resume Gate
        //
        // �@�� Cycle Start�G���� Hard Limit ���T��C
        //
        // LIMIT_ONLY / LIMIT_INDEX HOME �Ȱ��ɡG
        // �w����V Limit �i�ऴ�M ON�A�������\ C12 Resume�A
        // ���b�~�� Backoff ���} Limit�C
        // =================================================

        const bool homingResume =
            m_nc.Homing.IsActive() &&
            (m_nc.Homing.IsPaused() ||
                m_nc.Homing.IsHoldDecelerating());


        bool hardLimitActive =
            false;

        for (int i = 0;
            i < NCPLC::AXIS_COUNT;
            ++i)
        {
            const bool positiveLimit =
                m_plc.Get_C(
                    NCPLC::C::AxisPoint(
                        NCPLC::C::POSITIVE_LIMIT_BASE,
                        i));

            const bool negativeLimit =
                m_plc.Get_C(
                    NCPLC::C::AxisPoint(
                        NCPLC::C::NEGATIVE_LIMIT_BASE,
                        i));


            const bool expectedPositive =
                homingResume &&
                m_nc.Homing.IsExpectedPositiveHardLimit(i);

            const bool expectedNegative =
                homingResume &&
                m_nc.Homing.IsExpectedNegativeHardLimit(i);


            if ((positiveLimit &&
                !expectedPositive) ||
                (negativeLimit &&
                    !expectedNegative))
            {
                hardLimitActive =
                    true;

                break;
            }
        }

        // Manual Move Mode Check: ����Ū PLC Raw Mode�A���̿�W�@ Scan �� m_manualMoveMode�A�]�� ProcessGlobalInputs() �� ProcessManualInputs() ������C
        const bool continuousJogMode = m_plc.Get_C(NCPLC::C::JOG_MODE);
        const bool fineJogMode = m_plc.Get_C(NCPLC::C::FINE_JOG_MODE);
        const bool inchJogMode = m_plc.Get_C(NCPLC::C::INCH_JOG_MODE);
        const bool mpgMode = m_plc.Get_C(NCPLC::C::MPG_MODE);
        const bool manualMoveModeActive = continuousJogMode || fineJogMode || inchJogMode || mpgMode;

        // JOG Motion Ownership Check: �Y�� C19 �w�g OFF�A�b�i���٦b JOG_dec_time ��t�C���ɤ��� Start �۰ʵ{���C
        bool jogAxisActive = false;
        for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
        {
            if (m_jogActive[i])
            {
                jogAxisActive = true;
                break;
            }
        }

        const bool noHomeOwnershipConflict =
            !m_nc.Homing.IsActive() ||
            homingResume;


        const bool cycleStartAllowed =
            m_servoReady &&
            !hardLimitActive &&
            !manualMoveModeActive &&
            !jogAxisActive &&
            noHomeOwnershipConflict;
        if (cycleStartAllowed)
        {
            m_nc.CycleStart();
        }
    }
    m_prevCycleStart = cycleStart;

    const bool reset = m_plc.Get_C(NCPLC::C::RESET); // C13 - NC Reset (Rising Edge)
    if (reset && !m_prevReset)
    {
        m_nc.Reset();
    }
    m_prevReset = reset;

    const bool servoFaultReset = m_plc.Get_C(NCPLC::C::SERVO_FAULT_RESET); // C14 - Servo Fault Reset (Rising Edge) ���ϥ� ResetAllFaults() �קK�M�� Group Command Queue�C
    if (servoFaultReset && !m_prevServoFaultReset)
    {
        if (m_nc.GetState() != NCState::RUN) // RUN ���T�� Servo Fault Reset
        {
            for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
            {
                AxisContext& axis = m_motion.GetAxisContext(i);
                if (!axis.isExist) continue;

                const bool needsReset = axis.isFault || axis.isLagAlarm || axis.state == MotionState::MotionState_ERROR || axis.state == MotionState::MotionState_ESTOP;
                if (!needsReset) continue;

                m_motion.RequestAxisFaultReset(i);
            }
        }
    }
    m_prevServoFaultReset = servoFaultReset;

    const bool singleBlock = m_plc.Get_C(NCPLC::C::SINGLE_BLOCK); // C16 - Single Block (Level Signal)
    m_nc.SetSingleBlockEnabled(singleBlock);

    const bool optionalStop = m_plc.Get_C(NCPLC::C::OPTIONAL_STOP); // C17 - Optional Stop (Level Signal)
    m_nc.SetOptionalStopEnabled(optionalStop);

    const bool blockSkip = m_plc.Get_C(NCPLC::C::BLOCK_SKIP); // C18 - Block Skip (Level Signal)
    m_nc.SetBlockSkipEnabled(blockSkip);

    m_edmProtectionBypass = m_plc.Get_C(NCPLC::C::EDM_PROTECTION_BYPASS); // C20 - EDM Protection Bypass: �u�O�s���A�C���� bypass: Emergency, Hard Limit, Axis Protection, Servo Fault, Lag Alarm, Safety Chain

    const bool controlledStop = m_plc.Get_C(NCPLC::C::CONTROLLED_STOP); // C4 - Controlled Stop / Feed Hold (Rising Edge)
    if (controlledStop && !m_prevControlledStop)
    {
        m_nc.FeedHold();
    }
    m_prevControlledStop = controlledStop;
}

// =========================================================
// Safety Inputs
// =========================================================
void NCPLCManager::ProcessSafetyInputs()
{
    const bool emergencyStop = m_plc.Get_C(NCPLC::C::EMERGENCY_STOP); // C5 - Emergency Stop (Level Sensitive Stop, Alarm only Rising Edge)
    if (emergencyStop)
    {
        m_motion.RequestEmergencyStopAllAxes(); // �C Scan �������b����
        m_nc.ChangeState(NCState::ALARM);

        if (!m_prevEmergencyStop) // Alarm �u�إߤ@��
        {
            AlarmManager::GetInstance().Trigger(AlarmManager::EMG_STOP);
        }
    }
    m_prevEmergencyStop = emergencyStop;

    bool axisProtectionActive = false; // C140 ~ C147 Axis Protection (Level Sensitive Stop, Rising Edge Alarm)
    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        const bool axisProtect = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::AXIS_PROTECT_STOP_BASE, i));
        if (axisProtect)
        {
            axisProtectionActive = true;
            if (!m_prevAxisProtect[i])
            {
                AxisContext& axis = m_motion.GetAxisContext(i);
                const int alarmAxisIndex = axis.isExist ? axis.axisIndex : i;
                AlarmManager::GetInstance().Trigger(AlarmManager::MANUAL_AXIS_PROTECT, 0, alarmAxisIndex);
            }
        }
        m_prevAxisProtect[i] = axisProtect;
    }

    if (axisProtectionActive) // C140~147 ���� ON�A�N����������� Emergency Stop�C
    {
        m_motion.RequestEmergencyStopAllAxes();
        m_nc.ChangeState(NCState::ALARM);
    }

    // =====================================================
    // C180 ~ C187 (+OT), C190 ~ C197 (-OT)
    // Hard Limit �u�b Rising Edge: 1. Trigger Alarm 2. Emergency Stop All Axes 3. NC -> ALARM
    // ���� ON �����s Emergency Stop�A�]������ Manual Recovery �������\�����} Limit ����V���ʡC
    // =====================================================
    bool hardLimitTriggered = false;
    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        AxisContext& axis = m_motion.GetAxisContext(i);
        const int alarmAxisIndex = axis.isExist ? axis.axisIndex : i;

        const bool positiveLimit = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::POSITIVE_LIMIT_BASE, i)); // +OT
        const bool negativeLimit = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::NEGATIVE_LIMIT_BASE, i)); // -OT

        axis.hardLimitPositive = positiveLimit;
        axis.hardLimitNegative = negativeLimit;

        // =====================================================
        // G81 HOME Expected Hard Limit
        //
        // �@�뱡�p�G
        //
        //     +OT / -OT Rising Edge
        //         -> 3002 HARD_LIMIT
        //         -> Emergency Stop
        //
        // LIMIT_INDEX / LIMIT_ONLY �M���I�ɡG
        //
        // �u���u���b HOME ���b�v
        // +
        // �u���T HomeDirection�v
        // +
        // �u���\��Ĳ Hard Limit �� HomeState�v
        //
        // �~���Ӥ�V Hard Limit �������` HOME Event�C
        //
        // �ۤϤ�V Hard Limit�G�û� Alarm�C
        // +OT / -OT �P�� ON�G�û����`�C
        // =====================================================

        const bool bothHardLimits =
            positiveLimit &&
            negativeLimit;

        const bool expectedPositiveHomeLimit =
            !bothHardLimits &&
            m_nc.Homing.IsExpectedPositiveHardLimit(i);

        const bool expectedNegativeHomeLimit =
            !bothHardLimits &&
            m_nc.Homing.IsExpectedNegativeHardLimit(i);

        const bool positiveLimitRising =
            positiveLimit &&
            !m_prevPositiveLimit[i];

        const bool negativeLimitRising =
            negativeLimit &&
            !m_prevNegativeLimit[i];

        const bool axisHoming =
            m_nc.Homing.IsAxisHoming(i);

        // HOME �����t�����P�� ON�A�ϥαM�� HOME Alarm�A
        // �קK�P�@ Scan ���ƫإߨⵧ�@�� HARD_LIMIT�C
        if (bothHardLimits &&
            (positiveLimitRising || negativeLimitRising))
        {
            AlarmManager::GetInstance().Trigger(
                axisHoming
                ? AlarmManager::HOME_BOTH_LIMITS
                : AlarmManager::HARD_LIMIT,
                0,
                alarmAxisIndex);

            hardLimitTriggered = true;
        }
        else
        {
            if (positiveLimitRising &&
                !expectedPositiveHomeLimit)
            {
                AlarmManager::GetInstance().Trigger(
                    axisHoming
                    ? AlarmManager::HOME_OPPOSITE_LIMIT
                    : AlarmManager::HARD_LIMIT,
                    0,
                    alarmAxisIndex);

                hardLimitTriggered = true;
            }

            if (negativeLimitRising &&
                !expectedNegativeHomeLimit)
            {
                AlarmManager::GetInstance().Trigger(
                    axisHoming
                    ? AlarmManager::HOME_OPPOSITE_LIMIT
                    : AlarmManager::HARD_LIMIT,
                    0,
                    alarmAxisIndex);

                hardLimitTriggered = true;
            }
        }
        // =====================================================
        // Final Travel Direction Block State
        //
        // Physical +OT / -OT �û����ġC
        // Software Limit �u�� CoordinateManager �P�w Active �ɥͮġC
        //
        // �o������u�N���u�Ӥ�V�ثe�ण��A�~�򨫡v�A
        // ���N�� Alarm�C
        // =====================================================

        axis.positiveTravelBlocked =
            axis.hardLimitPositive ||
            !m_nc.GetCoordSys().CanMoveSoftwarePositive(axis);

        axis.negativeTravelBlocked =
            axis.hardLimitNegative ||
            !m_nc.GetCoordSys().CanMoveSoftwareNegative(axis);

        m_prevPositiveLimit[i] = positiveLimit; // Edge Memory
        m_prevNegativeLimit[i] = negativeLimit;
    }

    if (hardLimitTriggered) // �� Scan ���s�� Hard Limit
    {
        m_motion.RequestEmergencyStopAllAxes();
        m_nc.ChangeState(NCState::ALARM);
    }
}

// =========================================================
// Manual Inputs
// =========================================================
void NCPLCManager::ProcessManualInputs()
{
    // =========================================================
    // Manual Move Mode (�|�ؼҦ����� One-Hot)
    // C19=Normal Continuous JOG, C23=Fine Continuous JOG, C24=INCH JOG, C21=MPG
    // =========================================================
    const bool continuousJogMode = m_plc.Get_C(NCPLC::C::JOG_MODE);
    const bool fineJogMode = m_plc.Get_C(NCPLC::C::FINE_JOG_MODE);
    const bool inchJogMode = m_plc.Get_C(NCPLC::C::INCH_JOG_MODE);
    const bool mpgMode = m_plc.Get_C(NCPLC::C::MPG_MODE);
    const int activeModeCount = (continuousJogMode ? 1 : 0) + (fineJogMode ? 1 : 0) + (inchJogMode ? 1 : 0) + (mpgMode ? 1 : 0);

    if (activeModeCount == 1)
    {
        if (continuousJogMode)      m_manualMoveMode = ManualMoveMode::CONTINUOUS_JOG;
        else if (fineJogMode)       m_manualMoveMode = ManualMoveMode::FINE_JOG;
        else if (inchJogMode)       m_manualMoveMode = ManualMoveMode::INCH_JOG;
        else                        m_manualMoveMode = ManualMoveMode::MPG;
    }
    else
    {
        m_manualMoveMode = ManualMoveMode::NONE;
    }

    // =========================================================
    // Manual Permission Gate
    // �u���\ NC Mode: MANUAL/MDI, NC State: IDLE/READY, C11 Servo Ready, No Alarm
    // =========================================================
    const NCOperationMode ncMode = m_nc.GetMode();
    const NCState ncState = m_nc.GetState();
    const bool operationModeAllowed = ncMode == NCOperationMode::MANUAL || ncMode == NCOperationMode::MDI;
    const bool ncStateAllowed = ncState == NCState::IDLE || ncState == NCState::READY;
    const bool alarmActive = AlarmManager::GetInstance().HasAlarm();

    if (!operationModeAllowed || !ncStateAllowed || !m_servoReady || alarmActive || m_nc.Homing.IsActive())
    {
        m_manualMoveMode = ManualMoveMode::NONE;
    }



    MotionOwner requestedManualOwner = MotionOwner::NONE;
    if (m_manualMoveMode == ManualMoveMode::MPG)
    {
        requestedManualOwner = MotionOwner::MPG;
    }
    else if (m_manualMoveMode != ManualMoveMode::NONE)
    {
        requestedManualOwner = MotionOwner::JOG;
    }

    if (m_manualMotionLease.IsValid() &&
        !m_motion.IsMotionOwnerLeaseCurrent(m_manualMotionLease))
    {
        m_manualMotionLease = MotionOwnerLease{};
    }

    // JOG <-> MPG is a real ownership transfer. Stop the old mode first;
    // release occurs only after every owned axis reaches IDLE.
    if (m_manualMotionLease.IsValid() &&
        m_manualMotionLease.owner != requestedManualOwner)
    {
        m_manualMoveMode = ManualMoveMode::NONE;
    }
    else if (requestedManualOwner != MotionOwner::NONE &&
        !m_manualMotionLease.IsValid())
    {
        if (!m_motion.TryAcquireMotionOwner(
            requestedManualOwner, m_manualMotionLease))
        {
            m_manualMoveMode = ManualMoveMode::NONE;
        }
    }

    int jogSpeedPercent = static_cast<int>(m_plc.GetMemory("R", NCPLC::R::JOG_SPEED_PERCENT)); // R200 Continuous JOG Speed % (0 ~ 100)
    if (jogSpeedPercent < 0) jogSpeedPercent = 0;
    if (jogSpeedPercent > 100) jogSpeedPercent = 100;
    m_jogSpeedPercent = static_cast<double>(jogSpeedPercent);

    // Fine JOG Speed Select (���� One-Hot)
    const bool fineJog0001 = m_plc.Get_C(NCPLC::C::FINE_JOG_SPEED_0001);
    const bool fineJog0010 = m_plc.Get_C(NCPLC::C::FINE_JOG_SPEED_0010);
    const bool fineJog0100 = m_plc.Get_C(NCPLC::C::FINE_JOG_SPEED_0100);
    const bool fineJog1000 = m_plc.Get_C(NCPLC::C::FINE_JOG_SPEED_1000);
    const int fineJogSpeedSelectCount = (fineJog0001 ? 1 : 0) + (fineJog0010 ? 1 : 0) + (fineJog0100 ? 1 : 0) + (fineJog1000 ? 1 : 0);

    int inchLevel = static_cast<int>(m_plc.GetMemory("R", NCPLC::R::INCH_DISTANCE_LEVEL)); // R201 INCH Distance Level (0~3)
    if (inchLevel < 0) inchLevel = 0;
    if (inchLevel > 3) inchLevel = 3;
    m_inchDistanceLevel = inchLevel; // R201 �u�t�d��� INCH Distance Level�C�u���Z���ѨC�@�b AxisContext �� INCH �ѼƨM�w�C

    // =========================================================
    // Manual Frame - Continuous / Fine JOG
    // CoordinateManager owns: Enabled, Yaw, Pitch, Roll
    // NCPLCManager only creates a Manual XYZ vector and asks CoordinateManager to transform it into Machine XYZ.
    // IMPORTANT: Vector rotation is done in physical units, NOT directly in Pulse space.
    // =========================================================
    const bool manualFrameVelocityMode = m_nc.GetCoordSys().IsManualFrameEnabled() && (m_manualMoveMode == ManualMoveMode::CONTINUOUS_JOG || m_manualMoveMode == ManualMoveMode::FINE_JOG);
    bool manualFrameXYZHasCommand = false;
    bool manualFrameXYZValid = true;
    bool manualFrameXYZGroupStop = false;
    double manualFrameTargetVelocityPPS[3] = { 0.0, 0.0, 0.0 };

    auto GetFineJogPPS = [&](const AxisContext& axis) -> double // Fine JOG PPS Helper
    {
        if (fineJogSpeedSelectCount != 1) return 0.0;
        if (fineJog0001) return axis.FINE_JOG_0001_PPS;
        if (fineJog0010) return axis.FINE_JOG_0010_PPS;
        if (fineJog0100) return axis.FINE_JOG_0100_PPS;
        if (fineJog1000) return axis.FINE_JOG_1000_PPS;
        return 0.0;
    };

    if (manualFrameVelocityMode)
    {
        double manualVector[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // 1. Build Manual XYZ Direction Vector (C120/C130)
        bool logicalAxisActive[3] = { false, false, false };
        bool directionConflict = false;

        for (int logicalAxis = 0; logicalAxis < 3; ++logicalAxis)
        {
            const bool positive = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::JOG_POSITIVE_BASE, logicalAxis));
            const bool negative = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::JOG_NEGATIVE_BASE, logicalAxis));

            if (positive && negative) // + / - �P�� ON
            {
                directionConflict = true;
                continue;
            }

            if (positive)
            {
                manualVector[logicalAxis] = 1.0;
                logicalAxisActive[logicalAxis] = true;
            }
            else if (negative)
            {
                manualVector[logicalAxis] = -1.0;
                logicalAxisActive[logicalAxis] = true;
            }
        }

        if (directionConflict)
        {
            manualFrameXYZValid = false;
        }

        const double manualMagnitude = std::sqrt(manualVector[0] * manualVector[0] + manualVector[1] * manualVector[1] + manualVector[2] * manualVector[2]); // 2. Normalize Manual XYZ Vector
        constexpr double VECTOR_EPSILON = 1.0e-12;

        if (manualMagnitude > VECTOR_EPSILON)
        {
            manualFrameXYZHasCommand = true;
            manualVector[0] /= manualMagnitude;
            manualVector[1] /= manualMagnitude;
            manualVector[2] /= manualMagnitude;

            double machineVector[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // 3. Manual Frame -> Machine Frame
            m_nc.GetCoordSys().TransformManualVector(manualVector, machineVector);

            for (int machineAxis = 0; machineAxis < 3; ++machineAxis) // ���� sin/cos �y�������p�B�I�ݭȡC
            {
                if (std::abs(machineVector[machineAxis]) < VECTOR_EPSILON)
                {
                    machineVector[machineAxis] = 0.0;
                }
            }

            double baseSpeedUnitPerSec = 0.0; // 4. Determine Manual Base Speed (Pulse/sec -> Unit/sec)
            bool baseSpeedInitialized = false;

            for (int logicalAxis = 0; logicalAxis < 3; ++logicalAxis)
            {
                if (!logicalAxisActive[logicalAxis]) continue;

                AxisContext& logicalContext = m_motion.GetAxisContext(logicalAxis);
                if (!logicalContext.isExist || logicalContext.resolution_PPR <= 0.0 || logicalContext.finalLead <= 0.0)
                {
                    manualFrameXYZValid = false;
                    break;
                }

                const double pulsePerUnit = logicalContext.resolution_PPR / logicalContext.finalLead;
                double logicalPPS = 0.0;

                if (m_manualMoveMode == ManualMoveMode::CONTINUOUS_JOG)
                {
                    logicalPPS = logicalContext.JOG_MAX_PPS * (m_jogSpeedPercent / 100.0);
                }
                else
                {
                    logicalPPS = GetFineJogPPS(logicalContext);
                }

                if (logicalPPS <= 0.0)
                {
                    manualFrameXYZValid = false;
                    break;
                }

                if (logicalContext.maxVel_PPS > 0.0 && logicalPPS > logicalContext.maxVel_PPS)
                {
                    logicalPPS = logicalContext.maxVel_PPS;
                }

                const double logicalSpeedUnit = logicalPPS / pulsePerUnit;
                if (!baseSpeedInitialized || logicalSpeedUnit < baseSpeedUnitPerSec)
                {
                    baseSpeedUnitPerSec = logicalSpeedUnit;
                    baseSpeedInitialized = true;
                }
            }

            if (!baseSpeedInitialized || baseSpeedUnitPerSec <= 0.0)
            {
                manualFrameXYZValid = false;
            }

            // 5. Physical XYZ Validation + Speed Limit (����ᥲ���ݯu�� Machine Axis: Servo, Fault, +/-OT, JOG Speed, Max Vel)
            if (manualFrameXYZValid)
            {
                for (int machineAxis = 0; machineAxis < 3; ++machineAxis)
                {
                    const double component = machineVector[machineAxis];
                    if (std::abs(component) < VECTOR_EPSILON) continue;

                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    const bool axisFault = physicalAxis.isFault || physicalAxis.isLagAlarm || physicalAxis.state == MotionState::MotionState_ERROR || physicalAxis.state == MotionState::MotionState_ESTOP;

                    if (!physicalAxis.isExist || !physicalAxis.isServoOn || axisFault || physicalAxis.resolution_PPR <= 0.0 || physicalAxis.finalLead <= 0.0)
                    {
                        manualFrameXYZValid = false;
                        break;
                    }

                    // =====================================================
                    // Final Travel Direction Block
                    //
                    // Manual Frame �g�L�����A�����ݯu����
                    // Physical Machine Axis Direction�C
                    //
                    // positiveTravelBlocked / negativeTravelBlocked
                    // �w�g��X Physical Hard Limit + Software Limit�C
                    // =====================================================

                    if (component > 0.0 &&
                        physicalAxis.positiveTravelBlocked)
                    {
                        manualFrameXYZValid = false;
                        break;
                    }

                    if (component < 0.0 &&
                        physicalAxis.negativeTravelBlocked)
                    {
                        manualFrameXYZValid = false;
                        break;
                    }

                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead; // Physical Axis Speed Capacity
                    double physicalLimitPPS = 0.0;

                    if (m_manualMoveMode == ManualMoveMode::CONTINUOUS_JOG)
                    {
                        physicalLimitPPS = physicalAxis.JOG_MAX_PPS * (m_jogSpeedPercent / 100.0);
                    }
                    else
                    {
                        physicalLimitPPS = GetFineJogPPS(physicalAxis);
                    }

                    if (physicalLimitPPS <= 0.0)
                    {
                        manualFrameXYZValid = false;
                        break;
                    }

                    if (physicalAxis.maxVel_PPS > 0.0 && physicalLimitPPS > physicalAxis.maxVel_PPS)
                    {
                        physicalLimitPPS = physicalAxis.maxVel_PPS;
                    }

                    const double physicalLimitUnit = physicalLimitPPS / pulsePerUnit;
                    const double allowedBaseSpeed = physicalLimitUnit / std::abs(component); // base <= AxisLimit / component

                    if (allowedBaseSpeed < baseSpeedUnitPerSec)
                    {
                        baseSpeedUnitPerSec = allowedBaseSpeed;
                    }
                }
            }

            // 6. Build Physical Axis Target PPS
            if (manualFrameXYZValid && baseSpeedUnitPerSec > 0.0)
            {
                for (int machineAxis = 0; machineAxis < 3; ++machineAxis)
                {
                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    if (physicalAxis.resolution_PPR <= 0.0 || physicalAxis.finalLead <= 0.0)
                    {
                        manualFrameXYZValid = false;
                        break;
                    }
                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead;
                    manualFrameTargetVelocityPPS[machineAxis] = baseSpeedUnitPerSec * machineVector[machineAxis] * pulsePerUnit;
                }
            }

            // 7. Coordinated Direction Change (���@ XYZ �ݭn�ϦV�A��ե���)
            if (manualFrameXYZValid)
            {
                for (int machineAxis = 0; machineAxis < 3; ++machineAxis)
                {
                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    const double targetVelocity = manualFrameTargetVelocityPPS[machineAxis];
                    const bool needsMotion = std::abs(targetVelocity) > 0.01;

                    if (needsMotion)
                    {
                        if (physicalAxis.state != MotionState::MotionState_IDLE && physicalAxis.state != MotionState::MotionState_VELOCITY) // Manual Frame ����m��L Motion�C
                        {
                            manualFrameXYZValid = false;
                            break;
                        }

                        if (physicalAxis.state == MotionState::MotionState_VELOCITY)
                        {
                            if (!m_jogActive[machineAxis]) // �u���ڭ̫����� Manual JOG �~���\��s Velocity�C
                            {
                                manualFrameXYZValid = false;
                                break;
                            }
                            const bool reversing = (physicalAxis.currentCmdVel > 0.0 && targetVelocity < 0.0) || (physicalAxis.currentCmdVel < 0.0 && targetVelocity > 0.0);
                            if (reversing)
                            {
                                manualFrameXYZGroupStop = true;
                            }
                        }
                    }
                    else
                    {
                        if (m_jogActive[machineAxis] && physicalAxis.state == MotionState::MotionState_VELOCITY) // �쥻�O����V�q���@�����A�s�V�q�{�b�ܦ� 0�A�]����հ��A���ؤ�V�C
                        {
                            manualFrameXYZGroupStop = true;
                        }
                    }
                }
            }
        }
    }

    // =========================================================
    // MPG Input Decode
    // C210~217=Axis Select, C220~223=Multiplier, DR200=Accumulated Handwheel Count
    // =========================================================
    int mpgSelectedAxis = -1;
    int mpgAxisSelectCount = 0;

    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        const bool selected = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::MPG_AXIS_SELECT_BASE, i));
        if (selected)
        {
            ++mpgAxisSelectCount;
            mpgSelectedAxis = i;
        }
    }

    const bool mpgX1 = m_plc.Get_C(NCPLC::C::MPG_MULTIPLIER_X1);
    const bool mpgX10 = m_plc.Get_C(NCPLC::C::MPG_MULTIPLIER_X10);
    const bool mpgX100 = m_plc.Get_C(NCPLC::C::MPG_MULTIPLIER_X100);
    const bool mpgX1000 = m_plc.Get_C(NCPLC::C::MPG_MULTIPLIER_X1000);
    const int mpgMultiplierSelectCount = (mpgX1 ? 1 : 0) + (mpgX10 ? 1 : 0) + (mpgX100 ? 1 : 0) + (mpgX1000 ? 1 : 0);

    double mpgMultiplier = 1.0;
    if (mpgX10) mpgMultiplier = 10.0;
    else if (mpgX100) mpgMultiplier = 100.0;
    else if (mpgX1000) mpgMultiplier = 1000.0;

    const int32_t currentMPGCount = static_cast<int32_t>(m_plc.GetMemory("DR", NCPLC::DR::MPG_ENCODER_COUNT));
    int64_t mpgDelta64 = static_cast<int64_t>(currentMPGCount) - static_cast<int64_t>(m_lastMPGCount); // Signed 32-bit wrap-safe delta

    if (mpgDelta64 > 2147483647LL) mpgDelta64 -= 4294967296LL;
    else if (mpgDelta64 < -2147483648LL) mpgDelta64 += 4294967296LL;
    int32_t mpgDeltaCount = static_cast<int32_t>(mpgDelta64);

    m_lastMPGCount = currentMPGCount; // Always consume the current counter value.

    const bool mpgCommandValid = m_manualMoveMode == ManualMoveMode::MPG && mpgAxisSelectCount == 1 && mpgMultiplierSelectCount == 1;
    if (!mpgCommandValid)
    {
        mpgDeltaCount = 0; // Invalid selection must not queue movement for later.
    }

    // =========================================================
    // Axis Manual Motion
    // =========================================================
    for (int i = 0; i < NCPLC::AXIS_COUNT; ++i)
    {
        AxisContext& axis = m_motion.GetAxisContext(i);

        const bool rawPositive = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::JOG_POSITIVE_BASE, i)); // Raw Direction: + : C120 ~ C127
        const bool rawNegative = m_plc.Get_C(NCPLC::C::AxisPoint(NCPLC::C::JOG_NEGATIVE_BASE, i)); // Raw Direction: - : C130 ~ C137

        const bool positiveRising = rawPositive && !m_prevJogPositive[i]; // Rising Edge (INCH �ϥ�)
        const bool negativeRising = rawNegative && !m_prevJogNegative[i];

        m_prevJogPositive[i] = rawPositive; // Edge Memory (�����C Scan ����s)
        m_prevJogNegative[i] = rawNegative;

        m_jogPositive[i] = false; // Default Valid Direction
        m_jogNegative[i] = false;

        // Manual Motion Ownership Release (�u�� IDLE ��~���� ownership)
        if (m_jogActive[i] && axis.state == MotionState::MotionState_IDLE)
        {
            m_jogActive[i] = false;
        }

        if (!axis.isExist) // Axis Existence
        {
            m_jogActive[i] = false;
            continue;
        }

        const bool axisFault = axis.isFault || axis.isLagAlarm || axis.state == MotionState::MotionState_ERROR || axis.state == MotionState::MotionState_ESTOP; // Axis Fault Gate
        if (axisFault)
        {
            m_jogActive[i] = false;
            continue;
        }

        if (!axis.isServoOn) // Servo On Gate
        {
            if (m_jogActive[i])
            {
                if (axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                else if (axis.state == MotionState::MotionState_MOVING) QueueManualStop(i, axis.INCH_dec_time);
                else if (axis.state == MotionState::MotionState_MPG) QueueManualStop(i, axis.JOG_dec_time);
            }
            continue;
        }

        // Mode Change Stop: Continuous JOG �٨S�����A�o�����L Manual Mode�G������C
        const bool velocityJogModeActive = m_manualMoveMode == ManualMoveMode::CONTINUOUS_JOG || m_manualMoveMode == ManualMoveMode::FINE_JOG;
        if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY && !velocityJogModeActive)
        {
            QueueManualStop(i, axis.JOG_dec_time);
            continue;
        }

        // INCH �٦b P2P�A�o���� INCH Mode�G�� Controlled Stop�C
        if (m_jogActive[i] && axis.state == MotionState::MotionState_MOVING && m_manualMoveMode != ManualMoveMode::INCH_JOG)
        {
            QueueManualStop(i, axis.INCH_dec_time);
            continue;
        }

        // MPG Mode Change Stop
        if (m_jogActive[i] && axis.state == MotionState::MotionState_MPG && m_manualMoveMode != ManualMoveMode::MPG)
        {
            QueueManualStop(i, axis.JOG_dec_time);
            continue;
        }

        if (m_manualMoveMode == ManualMoveMode::NONE) // Manual Mode NONE
        {
            continue;
        }

        // =====================================================
        // MPG / Manual Pulse Generator
        // =====================================================
        if (m_manualMoveMode == ManualMoveMode::MPG)
        {
            // Manual Frame MPG �u�B�z XYZ
            const bool manualFrameMPG = m_nc.GetCoordSys().IsManualFrameEnabled() && mpgCommandValid && mpgSelectedAxis >= 0 && mpgSelectedAxis < 3;
            if (manualFrameMPG)
            {
                if (i >= 3) // ��L����b�p�G���e�ٰ��d�b MPG�A�� Controlled Stop�C
                {
                    if (axis.state == MotionState::MotionState_MPG)
                    {
                        QueueManualStop(i, axis.JOG_dec_time);
                        m_jogActive[i] = true;
                    }
                    continue;
                }

                if (i != mpgSelectedAxis) continue; // ��� XYZ �u����@���C�H�ثe MPG Selected Logical Axis ���@ Group Executor�C

                auto StopManualFrameMPGXYZ = [&]() // Helper: Stop all XYZ MPG axes
                {
                    for (int machineAxis = 0; machineAxis < 3; ++machineAxis)
                    {
                        AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                        if (physicalAxis.state == MotionState::MotionState_MPG)
                        {
                            QueueManualStop(machineAxis, physicalAxis.JOG_dec_time);
                            m_jogActive[machineAxis] = true;
                        }
                    }
                };

                if (mpgDeltaCount == 0) continue; // No New Count ���I�s MPGMove�C�w�g�O MPG State ���b�|�~��l���e finalTargetPos�C

                AxisContext& logicalAxis = axis; // Logical Manual Axis Parameters
                if (logicalAxis.MPG_BASE_DISTANCE <= 0.0 || logicalAxis.MPG_MAX_PPS <= 0.0 || logicalAxis.resolution_PPR <= 0.0 || logicalAxis.finalLead <= 0.0)
                {
                    StopManualFrameMPGXYZ();
                    continue;
                }

                const double logicalPulsePerUnit = logicalAxis.resolution_PPR / logicalAxis.finalLead;
                double manualVector[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // Manual Unit Direction
                manualVector[mpgSelectedAxis] = 1.0;

                double machineDirection[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // Manual Frame -> Machine Frame
                m_nc.GetCoordSys().TransformManualVector(manualVector, machineDirection);

                constexpr double MPG_VECTOR_EPSILON = 1.0e-10;
                for (int machineAxis = 0; machineAxis < 3; ++machineAxis) // �M������x�}���L�p�B�I�ݭ�
                {
                    if (std::abs(machineDirection[machineAxis]) < MPG_VECTOR_EPSILON)
                    {
                        machineDirection[machineAxis] = 0.0;
                    }
                }

                const double deltaDistance = static_cast<double>(mpgDeltaCount) * logicalAxis.MPG_BASE_DISTANCE * mpgMultiplier; // DR200 Count -> Logical Distance
                if (std::abs(deltaDistance) <= MPG_VECTOR_EPSILON) continue;

                double logicalMaxPPS = logicalAxis.MPG_MAX_PPS; // Logical MPG Max Path Speed
                if (logicalAxis.maxVel_PPS > 0.0 && logicalMaxPPS > logicalAxis.maxVel_PPS) logicalMaxPPS = logicalAxis.maxVel_PPS;
                double pathMaxUnitPerSec = logicalMaxPPS / logicalPulsePerUnit;

                if (pathMaxUnitPerSec <= 0.0)
                {
                    StopManualFrameMPGXYZ();
                    continue;
                }

                double groupAccTime = logicalAxis.JOG_acc_time; // Group Acc / Dec (�Ҧ� XYZ �ϥΦP�@�ծɶ�)
                double groupDecTime = logicalAxis.JOG_dec_time;
                if (groupAccTime < 0.001) groupAccTime = 0.2;
                if (groupDecTime < 0.001) groupDecTime = groupAccTime;
                bool groupValid = true;
                bool softwareTargetRejected = false;

                for (int machineAxis = 0; machineAxis < 3; ++machineAxis) // Validate Physical Machine XYZ (Limit �n�̷ӱ�����ڤ�V�P�_)
                {
                    const double component = machineDirection[machineAxis];
                    if (std::abs(component) <= MPG_VECTOR_EPSILON) continue;

                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    const bool physicalFault = physicalAxis.isFault || physicalAxis.isLagAlarm || physicalAxis.state == MotionState::MotionState_ERROR || physicalAxis.state == MotionState::MotionState_ESTOP;

                    if (!physicalAxis.isExist || !physicalAxis.isServoOn || physicalFault || physicalAxis.resolution_PPR <= 0.0 || physicalAxis.finalLead <= 0.0 || physicalAxis.MPG_MAX_PPS <= 0.0)
                    {
                        groupValid = false;
                        break;
                    }

                    if (physicalAxis.state != MotionState::MotionState_IDLE && physicalAxis.state != MotionState::MotionState_MPG)
                    {
                        groupValid = false;
                        break;
                    }

                    const double physicalDeltaUnit = deltaDistance * component; // Rotated Physical Delta
                    if (physicalAxis.hardLimitPositive &&
                        physicalAxis.hardLimitNegative)
                    {
                        groupValid = false;
                        break;
                    }

                    if (physicalDeltaUnit > 0.0 &&
                        physicalAxis.positiveTravelBlocked)
                    {
                        groupValid = false;

                        if (!physicalAxis.hardLimitPositive)
                        {
                            softwareTargetRejected = true;
                        }

                        break;
                    }

                    if (physicalDeltaUnit < 0.0 &&
                        physicalAxis.negativeTravelBlocked)
                    {
                        groupValid = false;

                        if (!physicalAxis.hardLimitNegative)
                        {
                            softwareTargetRejected = true;
                        }

                        break;
                    }

                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead; // Physical Axis MPG Speed Capacity
                    const double deltaPulse = physicalDeltaUnit * pulsePerUnit;
                    const double baseTarget = (physicalAxis.state == MotionState::MotionState_MPG) ? physicalAxis.finalTargetPos : physicalAxis.currentCmdPos;
                    const double targetPosition = baseTarget + deltaPulse;
                    const double targetMCS = targetPosition / pulsePerUnit;

                    const bool targetWithinSoftwareLimit = m_nc.GetCoordSys().IsTargetWithinSoftwareTravelLimit(physicalAxis, targetMCS);
                    const bool positiveSoftwareLimitActive = physicalAxis.travelLimit1PositiveActive || physicalAxis.travelLimit2PositiveActive || physicalAxis.travelLimit3PositiveActive;
                    const bool negativeSoftwareLimitActive = physicalAxis.travelLimit1NegativeActive || physicalAxis.travelLimit2NegativeActive || physicalAxis.travelLimit3NegativeActive;
                    const bool recoveringFromPositiveLimit = positiveSoftwareLimitActive && physicalDeltaUnit < 0.0;
                    const bool recoveringFromNegativeLimit = negativeSoftwareLimitActive && physicalDeltaUnit > 0.0;

                    if (!targetWithinSoftwareLimit && !recoveringFromPositiveLimit && !recoveringFromNegativeLimit)
                    {
                        groupValid = false;
                        softwareTargetRejected = true;
                        break;
                    }

                    double physicalMaxPPS = physicalAxis.MPG_MAX_PPS;
                    if (physicalAxis.maxVel_PPS > 0.0 && physicalMaxPPS > physicalAxis.maxVel_PPS) physicalMaxPPS = physicalAxis.maxVel_PPS;
                    const double physicalMaxUnitPerSec = physicalMaxPPS / pulsePerUnit;
                    const double allowedPathSpeed = physicalMaxUnitPerSec / std::abs(component);

                    if (allowedPathSpeed < pathMaxUnitPerSec)
                    {
                        pathMaxUnitPerSec = allowedPathSpeed;
                    }

                    double physicalAccTime = physicalAxis.JOG_acc_time; // Group Acc / Dec ���ѻP�b���C���ɶ�
                    double physicalDecTime = physicalAxis.JOG_dec_time;
                    if (physicalAccTime < 0.001) physicalAccTime = 0.2;
                    if (physicalDecTime < 0.001) physicalDecTime = physicalAccTime;
                    if (physicalAccTime > groupAccTime) groupAccTime = physicalAccTime;
                    if (physicalDecTime > groupDecTime) groupDecTime = physicalDecTime;
                }

                if (!groupValid || pathMaxUnitPerSec <= 0.0)
                {
                    if (!softwareTargetRejected) StopManualFrameMPGXYZ();
                    continue;
                }

                for (int machineAxis = 0; machineAxis < 3; ++machineAxis) // Execute Physical XYZ MPG
                {
                    const double component = machineDirection[machineAxis];
                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);

                    if (std::abs(component) <= MPG_VECTOR_EPSILON) // ���b���ѻP�ثe�����V
                    {
                        if (physicalAxis.state == MotionState::MotionState_MPG)
                        {
                            QueueManualStop(machineAxis, physicalAxis.JOG_dec_time);
                            m_jogActive[machineAxis] = true;
                        }
                        continue;
                    }

                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead;
                    const double physicalDeltaUnit = deltaDistance * component;
                    const double deltaPulse = physicalDeltaUnit * pulsePerUnit;
                    if (std::abs(deltaPulse) <= MPG_VECTOR_EPSILON) continue;

                    const double baseTarget = (physicalAxis.state == MotionState::MotionState_MPG) ? physicalAxis.finalTargetPos : physicalAxis.currentCmdPos; // Dynamic Target Accumulation
                    const double targetPosition = baseTarget + deltaPulse;

                    double physicalMPGMaxPPS = pathMaxUnitPerSec * std::abs(component) * pulsePerUnit; // Physical Axis Max PPS
                    if (physicalAxis.MPG_MAX_PPS > 0.0 && physicalMPGMaxPPS > physicalAxis.MPG_MAX_PPS) physicalMPGMaxPPS = physicalAxis.MPG_MAX_PPS;
                    if (physicalAxis.maxVel_PPS > 0.0 && physicalMPGMaxPPS > physicalAxis.maxVel_PPS) physicalMPGMaxPPS = physicalAxis.maxVel_PPS;
                    if (physicalMPGMaxPPS <= 0.0) continue;

                    QueueManualMPG(machineAxis, targetPosition, physicalMPGMaxPPS, groupAccTime, groupDecTime); // MPG Motion
                    if (physicalAxis.state == MotionState::MotionState_MPG) m_jogActive[machineAxis] = true;
                }
                continue;
            }

            // Original MPG: �H�U���p�������쥻�欰 (Manual Frame OFF �� A/B/C/U/V)
            if (!mpgCommandValid || i != mpgSelectedAxis) // Invalid selector or this is not selected axis.
            {
                if (axis.state == MotionState::MotionState_MPG)
                {
                    QueueManualStop(i, axis.JOG_dec_time);
                    m_jogActive[i] = true;
                }
                continue;
            }

            if (axis.state != MotionState::MotionState_IDLE && axis.state != MotionState::MotionState_MPG) continue; // MPG cannot steal another Motion owner.
            if (mpgDeltaCount == 0) continue; // No new handwheel count

            const bool blockedPositive =
                mpgDeltaCount > 0 &&
                axis.positiveTravelBlocked;

            const bool blockedNegative =
                mpgDeltaCount < 0 &&
                axis.negativeTravelBlocked;

            if (axis.hardLimitPositive &&
                axis.hardLimitNegative)
            {
                if (axis.state == MotionState::MotionState_MPG)
                {
                    QueueManualStop(i, axis.JOG_dec_time);
                    m_jogActive[i] = true;
                }

                continue;
            }

            if (blockedPositive || blockedNegative)
            {
                const bool blockedByPhysicalLimit =
                    (blockedPositive && axis.hardLimitPositive) ||
                    (blockedNegative && axis.hardLimitNegative);

                if (blockedByPhysicalLimit &&
                    axis.state == MotionState::MotionState_MPG)
                {
                    QueueManualStop(i, axis.JOG_dec_time);
                    m_jogActive[i] = true;
                }

                continue;
            }

            if (axis.MPG_BASE_DISTANCE <= 0.0 || axis.MPG_MAX_PPS <= 0.0 || axis.resolution_PPR <= 0.0 || axis.finalLead <= 0.0) continue; // Axis Parameters

            const double pulsePerUnit = axis.resolution_PPR / axis.finalLead;
            const double deltaDistance = static_cast<double>(mpgDeltaCount) * axis.MPG_BASE_DISTANCE * mpgMultiplier;
            const double deltaPulse = deltaDistance * pulsePerUnit;
            if (deltaPulse == 0.0) continue;

            const double baseTarget = (axis.state == MotionState::MotionState_MPG) ? axis.finalTargetPos : axis.currentCmdPos; // Dynamic Absolute Target
            const double targetPosition = baseTarget + deltaPulse;
            const double targetMCS = targetPosition / pulsePerUnit;

            const bool targetWithinSoftwareLimit = m_nc.GetCoordSys().IsTargetWithinSoftwareTravelLimit(axis, targetMCS);
            const bool positiveSoftwareLimitActive = axis.travelLimit1PositiveActive || axis.travelLimit2PositiveActive || axis.travelLimit3PositiveActive;
            const bool negativeSoftwareLimitActive = axis.travelLimit1NegativeActive || axis.travelLimit2NegativeActive || axis.travelLimit3NegativeActive;
            const bool recoveringFromPositiveLimit = positiveSoftwareLimitActive && deltaDistance < 0.0;
            const bool recoveringFromNegativeLimit = negativeSoftwareLimitActive && deltaDistance > 0.0;

            if (!targetWithinSoftwareLimit && !recoveringFromPositiveLimit && !recoveringFromNegativeLimit)
            {
                continue;
            }

            QueueManualMPG(i, targetPosition, axis.MPG_MAX_PPS, axis.JOG_acc_time, axis.JOG_dec_time); // Original MPG MotionCore
            if (axis.state == MotionState::MotionState_MPG) m_jogActive[i] = true;

            continue;
        }

        // =====================================================
        // Manual Frame - Normal / Fine JOG XYZ
        // =====================================================
        if (manualFrameVelocityMode && i < 3)
        {
            if (!manualFrameXYZHasCommand || !manualFrameXYZValid || manualFrameXYZGroupStop) // No command / Invalid / Coordinated Stop
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            const double targetVelocity = manualFrameTargetVelocityPPS[i];
            if (std::abs(targetVelocity) <= 0.01) // This physical axis does not participate in the rotated vector.
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            if (axis.state == MotionState::MotionState_STOPPING) continue; // STOPPING must finish first.
            if (axis.state != MotionState::MotionState_IDLE && axis.state != MotionState::MotionState_VELOCITY) continue; // Do not steal P2P / Interpolation / MPG.

            QueueManualVelocity(i, targetVelocity, axis.JOG_acc_time); // Execute physical machine-axis velocity.
            m_jogActive[i] = true;
            continue;
        }

        // =====================================================
        // Direction Conflict: + / - �P�� ON �����\���ʡC
        // =====================================================
        if (rawPositive && rawNegative)
        {
            if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
            continue;
        }

        // =====================================================
 // Physical Hard Limit
 //
 // +OT / -OT
 //
 // Physical Limit �û����ġC
 // =====================================================

        // =====================================================
        // Final Travel Direction Block
        //
        // axis.positiveTravelBlocked / negativeTravelBlocked
        // �w�g��X�G
        //
        // 1. Physical +OT / -OT
        // 2. Software Travel Limit 1 / 2 / 3
        //
        // �o�̥u�ݭn�M�� Operator Direction�C
        // =====================================================

        const bool allowPositive =
            rawPositive &&
            !axis.positiveTravelBlocked;

        const bool allowNegative =
            rawNegative &&
            !axis.negativeTravelBlocked;


        // =====================================================
        // Physical +OT �P -OT �P�� ON
        //
        // �o�ݩ󲧱` Hardware Input State�C
        //
        // Software Limit ���ϥγo�ӧP�_�A
        // �]�� Software + / - Block �z�פW�i��] Parameter
        // �]�w���D�ӥt�~�B�z�C
        // =====================================================

        if (axis.hardLimitPositive &&
            axis.hardLimitNegative)
        {
            if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY)
            {
                QueueManualStop(i, axis.JOG_dec_time);
            }

            continue;
        }

        m_jogPositive[i] = allowPositive;
        m_jogNegative[i] = allowNegative;

        // =====================================================
        // 1. CONTINUOUS JOG
        // =====================================================
        if (m_manualMoveMode == ManualMoveMode::CONTINUOUS_JOG)
        {
            if (!allowPositive && !allowNegative) // �S����V
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            if (axis.JOG_MAX_PPS <= 0.0) continue; // �� JOG �t��

            double jogVelocity = axis.JOG_MAX_PPS * (m_jogSpeedPercent / 100.0);
            if (axis.maxVel_PPS > 0.0 && jogVelocity > axis.maxVel_PPS) jogVelocity = axis.maxVel_PPS; // Clamp Axis Maximum

            if (jogVelocity <= 0.0) // R200 = 0
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            double targetVelocity = 0.0; // Direction
            if (allowPositive) targetVelocity = jogVelocity;
            else if (allowNegative) targetVelocity = -jogVelocity;

            if (axis.state == MotionState::MotionState_STOPPING) continue; // STOPPING �@�w���u������ IDLE
            if (axis.state == MotionState::MotionState_MOVING || axis.state == MotionState::MotionState_INTERPOLATING) continue; // P2P / Interpolation ���b�ϥ� Axis

            if (axis.state == MotionState::MotionState_VELOCITY) // Direction Reversal
            {
                const bool reversing = (axis.currentCmdVel > 0.0 && targetVelocity < 0.0) || (axis.currentCmdVel < 0.0 && targetVelocity > 0.0);
                if (reversing)
                {
                    QueueManualStop(i, axis.JOG_dec_time);
                    continue;
                }
            }

            QueueManualVelocity(i, targetVelocity, axis.JOG_acc_time); // Velocity Move
            m_jogActive[i] = true;
            continue;
        }

        // =====================================================
        // 2. FINE CONTINUOUS JOG
        // =====================================================
        if (m_manualMoveMode == ManualMoveMode::FINE_JOG)
        {
            if (!allowPositive && !allowNegative)
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            if (fineJogSpeedSelectCount != 1) // Fine Speed Selector ���� One-Hot�C
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            double fineJogVelocity = 0.0;
            if (fineJog0001) fineJogVelocity = axis.FINE_JOG_0001_PPS;
            else if (fineJog0010) fineJogVelocity = axis.FINE_JOG_0010_PPS;
            else if (fineJog0100) fineJogVelocity = axis.FINE_JOG_0100_PPS;
            else if (fineJog1000) fineJogVelocity = axis.FINE_JOG_1000_PPS;

            if (fineJogVelocity <= 0.0)
            {
                if (m_jogActive[i] && axis.state == MotionState::MotionState_VELOCITY) QueueManualStop(i, axis.JOG_dec_time);
                continue;
            }

            if (axis.maxVel_PPS > 0.0 && fineJogVelocity > axis.maxVel_PPS) fineJogVelocity = axis.maxVel_PPS;

            double targetVelocity = 0.0;
            if (allowPositive) targetVelocity = fineJogVelocity;
            else if (allowNegative) targetVelocity = -fineJogVelocity;

            if (axis.state == MotionState::MotionState_STOPPING) continue;
            if (axis.state == MotionState::MotionState_MOVING || axis.state == MotionState::MotionState_INTERPOLATING) continue;

            if (axis.state == MotionState::MotionState_VELOCITY) // �ϦV�ɥ����� IDLE�A�A�ϦV�C
            {
                const bool reversing = (axis.currentCmdVel > 0.0 && targetVelocity < 0.0) || (axis.currentCmdVel < 0.0 && targetVelocity > 0.0);
                if (reversing)
                {
                    QueueManualStop(i, axis.JOG_dec_time);
                    continue;
                }
            }

            QueueManualVelocity(i, targetVelocity, axis.JOG_acc_time); // Fine JOG �P Normal JOG �@�Υ[��t�CC200~C203 �����ɥi������s targetVelocity�C
            m_jogActive[i] = true;
            continue;
        }

        // =====================================================
        // 3. INCH JOG
        // =====================================================
        if (m_manualMoveMode == ManualMoveMode::INCH_JOG)
        {
            // A. Manual Frame XYZ INCH
            if (m_nc.GetCoordSys().IsManualFrameEnabled() && i < 3)
            {
                if (axis.state != MotionState::MotionState_IDLE) continue; // �@�� INCH �����q��������}�l

                double inchDistance = 0.0; // Logical Axis INCH Distance
                switch (m_inchDistanceLevel)
                {
                case 0: inchDistance = axis.INCH_0001_DISTANCE; break;
                case 1: inchDistance = axis.INCH_0010_DISTANCE; break;
                case 2: inchDistance = axis.INCH_0100_DISTANCE; break;
                case 3: inchDistance = axis.INCH_1000_DISTANCE; break;
                default: inchDistance = axis.INCH_0001_DISTANCE; break;
                }
                if (inchDistance <= 0.0) continue;

                const bool inchPositive = positiveRising; // Rising Edge: INCH �@�������u�ʤ@���C
                const bool inchNegative = negativeRising;
                if (!inchPositive && !inchNegative) continue;
                if (inchPositive && inchNegative) continue;

                double manualVector[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // Manual Distance Vector (INCH �O�Z���A���� Normalize)
                manualVector[i] = inchPositive ? inchDistance : -inchDistance;

                double machineVector[8] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; // Manual Frame -> Machine Frame
                m_nc.GetCoordSys().TransformManualVector(manualVector, machineVector);

                constexpr double INCH_VECTOR_EPSILON = 1.0e-10;
                const double pathDistance = std::sqrt(machineVector[0] * machineVector[0] + machineVector[1] * machineVector[1] + machineVector[2] * machineVector[2]); // Rotated Path Length
                if (pathDistance <= INCH_VECTOR_EPSILON) continue;

                if (axis.resolution_PPR <= 0.0 || axis.finalLead <= 0.0 || axis.INCH_JOG_PPS <= 0.0) continue; // Logical Axis Speed
                const double logicalPulsePerUnit = axis.resolution_PPR / axis.finalLead;
                double pathSpeedUnitPerSec = axis.INCH_JOG_PPS / logicalPulsePerUnit;

                if (axis.maxVel_PPS > 0.0)
                {
                    const double logicalMaxUnitPerSec = axis.maxVel_PPS / logicalPulsePerUnit;
                    if (pathSpeedUnitPerSec > logicalMaxUnitPerSec) pathSpeedUnitPerSec = logicalMaxUnitPerSec;
                }
                if (pathSpeedUnitPerSec <= 0.0) continue;

                bool groupValid = true; // Validate Physical XYZ Group
                double groupAccTime = 0.001;
                double groupDecTime = 0.001;

                for (int machineAxis = 0; machineAxis < 3; ++machineAxis)
                {
                    const double deltaUnit = machineVector[machineAxis];
                    if (std::abs(deltaUnit) <= INCH_VECTOR_EPSILON) continue;

                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    const bool physicalAxisFault = physicalAxis.isFault || physicalAxis.isLagAlarm || physicalAxis.state == MotionState::MotionState_ERROR || physicalAxis.state == MotionState::MotionState_ESTOP;

                    if (!physicalAxis.isExist || !physicalAxis.isServoOn || physicalAxisFault || physicalAxis.state != MotionState::MotionState_IDLE) // Axis / Servo / Motion Ownership
                    {
                        groupValid = false;
                        break;
                    }
                    if (physicalAxis.resolution_PPR <= 0.0 || physicalAxis.finalLead <= 0.0 || physicalAxis.INCH_JOG_PPS <= 0.0)
                    {
                        groupValid = false;
                        break;
                    }

                    if (physicalAxis.hardLimitPositive &&
                        physicalAxis.hardLimitNegative)
                    {
                        groupValid = false;
                        break;
                    }

                    if (deltaUnit > 0.0 &&
                        physicalAxis.positiveTravelBlocked)
                    {
                        groupValid = false;
                        break;
                    }

                    if (deltaUnit < 0.0 &&
                        physicalAxis.negativeTravelBlocked)
                    {
                        groupValid = false;
                        break;
                    }

                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead; // Physical Axis Speed Capacity
                    const double deltaPulse = deltaUnit * pulsePerUnit;
                    const double targetPosition = physicalAxis.currentActPos + deltaPulse;
                    const double targetMCS = targetPosition / pulsePerUnit;

                    const bool targetWithinSoftwareLimit = m_nc.GetCoordSys().IsTargetWithinSoftwareTravelLimit(physicalAxis, targetMCS);
                    const bool positiveSoftwareLimitActive = physicalAxis.travelLimit1PositiveActive || physicalAxis.travelLimit2PositiveActive || physicalAxis.travelLimit3PositiveActive;
                    const bool negativeSoftwareLimitActive = physicalAxis.travelLimit1NegativeActive || physicalAxis.travelLimit2NegativeActive || physicalAxis.travelLimit3NegativeActive;
                    const bool recoveringFromPositiveLimit = positiveSoftwareLimitActive && deltaUnit < 0.0;
                    const bool recoveringFromNegativeLimit = negativeSoftwareLimitActive && deltaUnit > 0.0;

                    if (!targetWithinSoftwareLimit && !recoveringFromPositiveLimit && !recoveringFromNegativeLimit)
                    {
                        groupValid = false;
                        break;
                    }

                    double physicalMaxPPS = physicalAxis.INCH_JOG_PPS;
                    if (physicalAxis.maxVel_PPS > 0.0 && physicalMaxPPS > physicalAxis.maxVel_PPS) physicalMaxPPS = physicalAxis.maxVel_PPS;

                    const double physicalMaxUnitPerSec = physicalMaxPPS / pulsePerUnit;
                    const double directionComponent = std::abs(deltaUnit) / pathDistance;

                    if (directionComponent > INCH_VECTOR_EPSILON)
                    {
                        const double allowedPathSpeed = physicalMaxUnitPerSec / directionComponent;
                        if (allowedPathSpeed < pathSpeedUnitPerSec) pathSpeedUnitPerSec = allowedPathSpeed;
                    }

                    double axisAccTime = physicalAxis.INCH_acc_time; // Group Acc / Dec (�Ҧ��ѻP XYZ �ϥάۦP�ɶ�)
                    double axisDecTime = physicalAxis.INCH_dec_time;
                    if (axisAccTime < 0.001) axisAccTime = 0.2;
                    if (axisDecTime < 0.001) axisDecTime = axisAccTime;
                    if (axisAccTime > groupAccTime) groupAccTime = axisAccTime;
                    if (axisDecTime > groupDecTime) groupDecTime = axisDecTime;
                }

                if (!groupValid || pathSpeedUnitPerSec <= 0.0) continue;

                for (int machineAxis = 0; machineAxis < 3; ++machineAxis) // Execute Rotated XYZ INCH
                {
                    const double deltaUnit = machineVector[machineAxis];
                    if (std::abs(deltaUnit) <= INCH_VECTOR_EPSILON) continue;

                    AxisContext& physicalAxis = m_motion.GetAxisContext(machineAxis);
                    const double pulsePerUnit = physicalAxis.resolution_PPR / physicalAxis.finalLead;
                    const double deltaPulse = deltaUnit * pulsePerUnit;
                    const double targetPosition = physicalAxis.currentActPos + deltaPulse;

                    const double directionComponent = std::abs(deltaUnit) / pathDistance;
                    double axisVelocity = pathSpeedUnitPerSec * directionComponent * pulsePerUnit;

                    if (axisVelocity <= 0.0) continue;
                    if (physicalAxis.maxVel_PPS > 0.0 && axisVelocity > physicalAxis.maxVel_PPS) axisVelocity = physicalAxis.maxVel_PPS;

                    QueueManualMove(machineAxis, targetPosition, axisVelocity, groupAccTime, groupDecTime, false); // XYZ �O Linear Axis�A���ݭn Rotary Shortest Path �B�z�C
                    m_jogActive[machineAxis] = true;
                }

                continue; // �w���� Manual Frame XYZ INCH�C���藍�i�A���U�����³�b INCH�C
            }

            // B. Original INCH (Manual Frame OFF �� A/B/C/U/V)
            if (axis.state != MotionState::MotionState_IDLE) continue; // INCH �u��q��������}�l

            double inchDistance = 0.0; // R201 -> �C�b�ۤv�� INCH Distance Parameter
            switch (m_inchDistanceLevel)
            {
            case 0: inchDistance = axis.INCH_0001_DISTANCE; break;
            case 1: inchDistance = axis.INCH_0010_DISTANCE; break;
            case 2: inchDistance = axis.INCH_0100_DISTANCE; break;
            case 3: inchDistance = axis.INCH_1000_DISTANCE; break;
            default: inchDistance = axis.INCH_0001_DISTANCE; break;
            }

            if (inchDistance <= 0.0) continue;

            // =====================================================
     // INCH Direction Permission
     //
     // allowPositive / allowNegative �e���w�g��X�G
     //
     // 1. Physical +OT / -OT
     // 2. Software Travel Limit 1 / 2 / 3
     //
     // �ҥH INCH �����u�άۦP Direction Permission�C
     // =====================================================

            const bool inchPositive = positiveRising && allowPositive;
            const bool inchNegative = negativeRising && allowNegative;

            if (!inchPositive && !inchNegative)
            {
                continue;
            }

            if (inchPositive && inchNegative)
            {
                continue;
            }


            // =====================================================
            // Mechanical Conversion
            // =====================================================

            if (axis.resolution_PPR <= 0.0 || axis.finalLead <= 0.0)
            {
                continue;
            }

            const double pulsePerUnit = axis.resolution_PPR / axis.finalLead;
            const double inchDistancePulse = inchDistance * pulsePerUnit;

            if (inchDistancePulse <= 0.0)
            {
                continue;
            }


            // =====================================================
            // Calculate Relative INCH Target
            //
            // MotionCore Position:
            //     Pulse
            // =====================================================

            double targetPosition = axis.currentActPos;

            if (inchPositive)
            {
                targetPosition += inchDistancePulse;
            }
            else
            {
                targetPosition -= inchDistancePulse;
            }


            // =====================================================
            // Software Travel Limit Target Pre-Check
            //
            // CoordinateManager �� Target Check �ϥΡG
            //
            // Linear Axis:
            //     mm
            //
            // Rotary Axis:
            //     degree
            //
            // �ҥH�� Pulse Target ��^ Machine Unit�C
            //
            // �Ҧp�G
            //
            // Current X = 99.999
            // INCH     = +0.010
            // Limit    = +100.000
            //
            // Target   = 100.009
            //
            // => Reject
            //
            // ���� MotionCore ����o�@�� MoveToPosition�C
            // =====================================================

            const double targetMCS = targetPosition / pulsePerUnit;
            const bool targetWithinSoftwareLimit = m_nc.GetCoordSys().IsTargetWithinSoftwareTravelLimit(axis, targetMCS);
            const bool positiveSoftwareLimitActive = axis.travelLimit1PositiveActive || axis.travelLimit2PositiveActive || axis.travelLimit3PositiveActive;
            const bool negativeSoftwareLimitActive = axis.travelLimit1NegativeActive || axis.travelLimit2NegativeActive || axis.travelLimit3NegativeActive;
            const bool recoveringFromPositiveLimit = positiveSoftwareLimitActive && inchNegative;
            const bool recoveringFromNegativeLimit = negativeSoftwareLimitActive && inchPositive;

            if (!targetWithinSoftwareLimit && !recoveringFromPositiveLimit && !recoveringFromNegativeLimit)
            {
                continue;
            }


            // =====================================================
            // INCH Speed
            // =====================================================

            double inchVelocity = axis.INCH_JOG_PPS;

            if (inchVelocity <= 0.0) continue;
            if (axis.maxVel_PPS > 0.0 && inchVelocity > axis.maxVel_PPS) inchVelocity = axis.maxVel_PPS;

            double inchAccTime = axis.INCH_acc_time; // INCH Acc / Dec
            double inchDecTime = axis.INCH_dec_time;
            if (inchAccTime < 0.001) inchAccTime = 0.2;
            if (inchDecTime < 0.001) inchDecTime = inchAccTime;

            QueueManualMove(
                i, targetPosition, inchVelocity, inchAccTime, inchDecTime,
                axis.axisType == AxisType::ROTARY ? false : axis.useShortestPath);
            m_jogActive[i] = true;
            continue;
        }
    }

    ReleaseManualMotionOwnerIfStopped();
}

// =========================================================
// Home Inputs
// =========================================================
void NCPLCManager::ProcessHomeInputs()
{
    // =====================================================
    // 1. HOME Request Input Decode
    //
    // C15�G
    //     HOME_ALL
    //
    // C150~157�G
    //     Axis 0~7 ��b HOME Request
    //
    // �Ҧ���J���u���� OFF -> ON Rising Edge�C
    //
    // �P�@�� Scan �Y���h�ӳ�b HOME Request�A
    // �|�X�֦��P�@�� axisMask�A�@���e�� HomingManager�C
    //
    // PLC / Panel HOME �w�]�ϥΡG
    //
    // P0 = SIMULTANEOUS
    //
    // P1 = BY_ORDER
    // ����� G81 P1 �Υ��ӱM�� PLC Mode �A���ѡC
    // =====================================================

    const bool homeAll =
        m_plc.Get_C(
            NCPLC::C::HOME_ALL);

    const bool homeAllRising =
        homeAll &&
        !m_prevHomeAll;

    m_prevHomeAll =
        homeAll;


    uint8_t axisHomeRequestMask =
        0;

    for (int i = 0;
        i < NCPLC::AXIS_COUNT;
        ++i)
    {
        const bool homeRequest =
            m_plc.Get_C(
                NCPLC::C::AxisPoint(
                    NCPLC::C::HOME_REQUEST_BASE,
                    i));

        const bool homeRequestRising =
            homeRequest &&
            !m_prevHomeRequest[i];

        m_prevHomeRequest[i] =
            homeRequest;


        if (homeRequestRising)
        {
            axisHomeRequestMask |=
                static_cast<uint8_t>(
                    1u << i);
        }
    }


    // =====================================================
    // 2. PLC / Panel HOME Permission Gate
    //
    // �o�̥u���� PLC ���O�J�f�C
    //
    // ���� G81 �O NC Program Command�A
    // �|�����q GCode Handler �I�s HomingManager�A
    // �����o�� Manual Panel Gate ����C
    //
    // PLC HOME ���\�G
    //
    // Mode�G
    //     MANUAL
    //     MDI
    //
    // State�G
    //     IDLE
    //     READY
    //
    // �åB�G
    //
    // Servo Ready
    // No Alarm
    // HomingManager �ثe�S�����b�����L HOME
    // =====================================================

    const NCOperationMode ncMode =
        m_nc.GetMode();

    const NCState ncState =
        m_nc.GetState();

    const bool operationModeAllowed =
        ncMode == NCOperationMode::MANUAL ||
        ncMode == NCOperationMode::MDI;

    const bool ncStateAllowed =
        ncState == NCState::IDLE ||
        ncState == NCState::READY;

    const bool alarmActive =
        AlarmManager::GetInstance().HasAlarm();

    const bool panelHomeAllowed =
        operationModeAllowed &&
        ncStateAllowed &&
        m_servoReady &&
        !alarmActive &&
        !m_nc.Homing.IsActive();


    // =====================================================
    // 3. Build HomeRequest
    //
    // HOME_ALL Rising�G
    //
    //     axisMask = 0
    //
    // HomingManager �|�۰ʿ���G
    //
    //     axis.isExist
    //     &&
    //     axis.home.enabled
    //
    // ��b / �h�b Rising�G
    //
    //     axisMask = ���� Bit Mask
    //
    // �Y HOME_ALL �P��b Request �P Scan �o�͡A
    // HOME_ALL �u���C
    // =====================================================

    if (panelHomeAllowed)
    {
        if (homeAllRising)
        {
            HomeRequest request{};

            request.axisMask =
                0;

            request.sequenceMode =
                HomeSequenceMode::SIMULTANEOUS;

            const bool started = m_nc.Homing.Start(request);
            if (!started)
            {
                const HomeErrorReason reason = m_nc.Homing.GetLastError();
                const int alarmCode = (reason == HomeErrorReason::SERVO_NOT_READY || reason == HomeErrorReason::MOTION_BUSY || reason == HomeErrorReason::SERVO_FAULT || reason == HomeErrorReason::MOTION_FAULT)
                    ? AlarmManager::HOME_MOTION_FAULT : AlarmManager::HOME_INVALID_CONFIG;
                if (!AlarmManager::GetInstance().HasAlarm())
                    AlarmManager::GetInstance().Trigger(alarmCode, 0, m_nc.Homing.GetLastErrorAxis());
                m_motion.RequestEmergencyStopAllAxes();
                m_nc.ChangeState(NCState::ALARM);
            }
        }
        else if (axisHomeRequestMask != 0)
        {
            HomeRequest request{};

            request.axisMask =
                axisHomeRequestMask;

            request.sequenceMode =
                HomeSequenceMode::SIMULTANEOUS;

            const bool started = m_nc.Homing.Start(request);
            if (!started)
            {
                const HomeErrorReason reason = m_nc.Homing.GetLastError();
                const int alarmCode = (reason == HomeErrorReason::SERVO_NOT_READY || reason == HomeErrorReason::MOTION_BUSY || reason == HomeErrorReason::SERVO_FAULT || reason == HomeErrorReason::MOTION_FAULT)
                    ? AlarmManager::HOME_MOTION_FAULT : AlarmManager::HOME_INVALID_CONFIG;
                if (!AlarmManager::GetInstance().HasAlarm())
                    AlarmManager::GetInstance().Trigger(alarmCode, 0, m_nc.Homing.GetLastErrorAxis());
                m_motion.RequestEmergencyStopAllAxes();
                m_nc.ChangeState(NCState::ALARM);
            }
        }
    }


    // =====================================================
    // 4. G81 HOME State Machine Cyclic Process
    //
    // NCPLCManager::Process() �ثe�Ѩt�� 10ms �g���I�s�A
    // �]�� HomingManager �ϥ� 0.010 ����s Runtime Timer�C
    //
    // HomingManager::Process() �|���槹�� HOME ���A���F
    // ������իe�������ϥΧC�t�P��b�Ѽ����ҡC
    // =====================================================

    constexpr double HOME_PROCESS_CYCLE_SEC =
        0.010;

    m_nc.Homing.Process(
        HOME_PROCESS_CYCLE_SEC);
}

// =========================================================
// Auxiliary Handshake
// =========================================================
void NCPLCManager::ProcessAuxiliaryHandshake()
{
    // Future: NC -> PLC (S30 AUX_REQUEST), PLC -> NC (C10 AUX_FIN)
    // Data: R100 M, R101 S, R102 T, R103 Valid Mask
}

// =========================================================
// NC -> PLC Status
// =========================================================
void NCPLCManager::SyncNCStateToPLC()
{

}