#pragma once
#include "NC_Types.h"
#include <cstdint>

// =============================================================================
// Stage NC-0.2A - G-code semantic / modal-group contract
//
// Parser �u�t�d��@�� Word�F���h�t�d�G
//   1. �P�_ G-code �O�_���ثe�䴩���y�N�C
//   2. �P�@ Modal Group �Ĭ��ˬd�]�Ҧp G90 G91�^�C
//   3. ����P�@ Block �̦h�@�� Primary Action�C
//   4. �إߩT�w�e�q�B�i�w�������涶�ǡC
//
// �����ϥΩT�w�}�C�A���t�m�ʺA�O����C
// =============================================================================

enum class NCGCodeModalGroup : std::uint8_t
{
    NONE = 0,
    MOTION,
    PLANE,
    DISTANCE,
    UNITS,
    WORK_COORDINATE,
    STORED_STROKE,
    TOOL_LENGTH,
    CUTTER_RADIUS,
    COORD_ROTATION_2D,
    WORKPIECE_ROTATION_3D,
    SCALING,
    MIRROR,
    POLAR,
    C_AXIS_OFFSET_ROTATION,
    MODAL_MACRO,
    COUNT
};

enum class NCGCodeRole : std::uint8_t
{
    SETTING = 0,
    PRIMARY_ACTION
};

enum class NCGCodePlanError : std::uint8_t
{
    NONE = 0,
    TOO_MANY_G_CODES,
    UNSUPPORTED_G_CODE,
    MODAL_GROUP_CONFLICT,
    MULTIPLE_PRIMARY_ACTIONS
};

struct NCGCodeDescriptor
{
    int code = -1;
    NCGCodeModalGroup group = NCGCodeModalGroup::NONE;
    NCGCodeRole role = NCGCodeRole::SETTING;
    int dispatchOrder = 0;
    bool barrier = false;
    bool motionAction = false;
    bool suppressesImplicitMotion = false;
};

struct NCGCodeExecutionPlan
{
    int orderedCodes[NC_MAX_G_CODES_PER_BLOCK] = { 0 };
    int count = 0;
    bool hasPrimaryAction = false;
    int primaryActionCode = -1;
};

namespace NCGCodeSemantics
{
    bool TryGetDescriptor(
        int code,
        NCGCodeDescriptor& descriptor) noexcept;

    bool BuildExecutionPlan(
        const NCBlock& block,
        NCGCodeExecutionPlan& plan,
        NCGCodePlanError& error,
        int& firstConflictCode,
        int& secondConflictCode) noexcept;

    bool Contains(
        const NCBlock& block,
        int code) noexcept;

    bool IsBlockBarrier(
        const NCBlock& block) noexcept;

    bool IsMotionAction(
        int code) noexcept;

    int GetPrimaryActionCode(
        const NCBlock& block) noexcept;

    bool BlockSuppressesImplicitMotion(
        const NCBlock& block) noexcept;
}
