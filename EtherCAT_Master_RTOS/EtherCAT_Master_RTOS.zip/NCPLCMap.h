#pragma once


namespace NCPLC
{
    constexpr int AXIS_COUNT = 8;                                  // NC �̤j�b�ơGX/Y/Z/A/B/C/U/V


    // ============================================================
    // C Point
    //
    // PLC -> NC
    // ============================================================

    namespace C
    {
        // --------------------------------------------------------
        // NC ���챱��
        // --------------------------------------------------------

        constexpr int CONTROLLED_STOP = 4;                         // �����t���� / Feed Hold
        constexpr int EMERGENCY_STOP = 5;                          // ��氱��

        constexpr int AUX_FIN = 10;                                // M/S/T ���U�\�৹���T��
        constexpr int SERVO_READY = 11;                            // Servo / Machine Ready

        constexpr int CYCLE_START = 12;                            // Cycle Start
        constexpr int RESET = 13;                                  // NC Reset
        constexpr int SERVO_FAULT_RESET = 14;                      // Servo Fault Reset
        constexpr int HOME_ALL = 15;                               // ���b HOME

        constexpr int SINGLE_BLOCK = 16;                           // Single Block
        constexpr int OPTIONAL_STOP = 17;                          // Optional Stop
        constexpr int BLOCK_SKIP = 18;                             // Block Skip

        constexpr int JOG_MODE = 19;                               // Normal Continuous JOG
        constexpr int EDM_PROTECTION_BYPASS = 20;                  // EDM �[�u�O�@�ȮɸѰ�
        constexpr int MPG_MODE = 21;                               // MPG ����Ҧ�
        constexpr int RESERVED_22 = 22;                            // �O�d�AManual Frame ���ϥ� PLC �I��
        constexpr int FINE_JOG_MODE = 23;                          // Fine Continuous JOG
        constexpr int INCH_JOG_MODE = 24;                          // INCH �w�Z����


        // --------------------------------------------------------
        // HOME Sensor
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int HOME_DOG_BASE = 100;                         // C100~107 HOME DOG Sensor
        constexpr int HOME_INDEX_BASE = 108;                       // C108~115 HOME Encoder Index


        // --------------------------------------------------------
        // Manual Direction
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int JOG_POSITIVE_BASE = 120;                     // C120~127 ��ʥ���V JOG+
        constexpr int JOG_NEGATIVE_BASE = 130;                     // C130~137 ��ʭt��V JOG-


        // --------------------------------------------------------
        // Axis Protection
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int AXIS_PROTECT_STOP_BASE = 140;                // C140~147 �~���b�O�@����


        // --------------------------------------------------------
        // HOME Request
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int HOME_REQUEST_BASE = 150;                     // C150~157 ��b HOME Request


        // --------------------------------------------------------
        // Servo Reset
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int SERVO_RESET_BASE = 160;                      // C160~167 ��b Servo Reset


        // --------------------------------------------------------
        // Hard Limit
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int POSITIVE_LIMIT_BASE = 180;                   // C180~187 ������ +OT
        constexpr int NEGATIVE_LIMIT_BASE = 190;                   // C190~197 �t���� -OT


        // --------------------------------------------------------
        // Fine JOG Speed Select
        //
        // ���� One-Hot
        // �o�ǬO�t�װѼƿ�ܡA���O���ʶZ��
        // --------------------------------------------------------

        constexpr int FINE_JOG_SPEED_0001 = 200;                   // C200 ��� Fine JOG 0.001 �t�װѼ�
        constexpr int FINE_JOG_SPEED_0010 = 201;                   // C201 ��� Fine JOG 0.010 �t�װѼ�
        constexpr int FINE_JOG_SPEED_0100 = 202;                   // C202 ��� Fine JOG 0.100 �t�װѼ�
        constexpr int FINE_JOG_SPEED_1000 = 203;                   // C203 ��� Fine JOG 1.000 �t�װѼ�


        // --------------------------------------------------------
        // MPG Axis Select
        //
        // ���� One-Hot
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int MPG_AXIS_SELECT_BASE = 210;                  // C210~217 MPG �b���


        // --------------------------------------------------------
        // MPG Multiplier
        //
        // ���� One-Hot
        // --------------------------------------------------------

        constexpr int MPG_MULTIPLIER_X1 = 220;                     // C220 MPG ��1
        constexpr int MPG_MULTIPLIER_X10 = 221;                    // C221 MPG ��10
        constexpr int MPG_MULTIPLIER_X100 = 222;                   // C222 MPG ��100
        constexpr int MPG_MULTIPLIER_X1000 = 223;                  // C223 MPG ��1000


        // --------------------------------------------------------
        // Helper
        // --------------------------------------------------------

        constexpr int AxisPoint(int base, int axisIndex)           // ���o�Y�b������ C Point
        {
            return base + axisIndex;
        }
    }


    // ============================================================
    // S Point
    //
    // NC -> PLC
    // ============================================================

    namespace S
    {
        // --------------------------------------------------------
        // NC State
        // --------------------------------------------------------

        constexpr int SYSTEM_READY = 0;                            // NC �t�� Ready
        constexpr int NC_START = 1;                                // NC Program Running
        constexpr int NC_HOLD = 2;                                 // NC Feed Hold
        constexpr int PROGRAM_END = 3;                             // Program End
        constexpr int RESET_STATE = 4;                             // Reset State
        constexpr int ALARM_ACTIVE = 5;                            // NC Alarm Active


        // --------------------------------------------------------
        // NC Mode
        // --------------------------------------------------------

        constexpr int MODE_MEMORY = 10;                            // MEMORY Mode
        constexpr int MODE_MDI = 11;                               // MDI Mode
        constexpr int MODE_MANUAL = 12;                            // MANUAL Mode
        constexpr int MODE_EDIT = 13;                              // EDIT Mode


        // --------------------------------------------------------
        // Program Control State
        // --------------------------------------------------------

        constexpr int SINGLE_BLOCK = 20;                           // Single Block Active
        constexpr int OPTIONAL_STOP = 22;                          // Optional Stop Active
        constexpr int BLOCK_SKIP = 23;                             // Block Skip Active


        // --------------------------------------------------------
        // Auxiliary M / S / T
        // --------------------------------------------------------

        constexpr int AUX_REQUEST = 30;                            // NC �o�X M/S/T ����n�D
        constexpr int AUX_WAIT_FIN = 31;                           // NC ���� AUX FIN


        // --------------------------------------------------------
        // Axis Servo State
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int SERVO_ON_BASE = 100;                         // S100~107 Servo ON
        constexpr int HOMED_BASE = 110;                            // S110~117 HOME ����


        // --------------------------------------------------------
        // Axis Limit State
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int POSITIVE_LIMIT_BASE = 120;                   // S120~127 ������ +OT
        constexpr int NEGATIVE_LIMIT_BASE = 130;                   // S130~137 �t���� -OT


        // --------------------------------------------------------
        // HOME State
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int HOME_SEARCH_DOG_BASE = 140;                  // S140~147 HOME DOG Search


        // --------------------------------------------------------
        // Axis Alarm
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int LAG_ALARM_BASE = 150;                        // S150~157 Following Error / Lag Alarm
        constexpr int DRIVE_FAULT_BASE = 160;                      // S160~167 Servo Drive Fault


        // --------------------------------------------------------
        // Coordinate / Mirror
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int MIRROR_ACTIVE_BASE = 170;                    // S170~177 Axis Mirror Active


        // --------------------------------------------------------
        // Manual JOG State
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int JOG_ACTIVE_BASE = 180;                       // S180~187 Manual JOG Active


        // --------------------------------------------------------
        // HOME Index State
        //
        // Axis 0~7
        // --------------------------------------------------------

        constexpr int HOME_SEARCH_INDEX_BASE = 190;                // S190~197 HOME Index Search


        // --------------------------------------------------------
        // Manual Function State
        // --------------------------------------------------------

        constexpr int MANUAL_FRAME_ACTIVE = 200;                   // S200 Manual Frame �w�ҥ�
        constexpr int MPG_ACTIVE = 201;                            // S201 MPG Mode Active
        constexpr int EDM_PROTECTION_BYPASS_ACTIVE = 202;          // S202 EDM Protection Bypass Active

        // --------------------------------------------------------
        // G81 HOME Global Run Control
        // --------------------------------------------------------

        constexpr int HOME_ACTIVE = 203;                           // S203 HOME Request Active�]Running / Hold / Paused ���O�� ON�^
        constexpr int HOME_HOLD_DECEL = 204;                       // S204 HOME Feed Hold Controlled Stop �i�椤
        constexpr int HOME_PAUSED = 205;                           // S205 HOME �w��������A���� C12 Resume

        // --------------------------------------------------------
        // Software Travel Limit State
        //
        // Axis 0~7
        //
        // Level Signal / Warning State
        //
        // �o���O Alarm�C
        // �� PLC / HMI ��ܥثe�Ӥ�V�w�� Software Limit�C
        // --------------------------------------------------------

        constexpr int SOFTWARE_POSITIVE_LIMIT_BASE = 210;           // S210~217 Software + Limit Active
        constexpr int SOFTWARE_NEGATIVE_LIMIT_BASE = 220;           // S220~227 Software - Limit Active


        // --------------------------------------------------------
        // Helper
        // --------------------------------------------------------

        constexpr int AxisPoint(int base, int axisIndex)           // ���o�Y�b������ S Point
        {
            return base + axisIndex;
        }
    }


    // ============================================================
    // R Register
    //
    // PLC <-> NC
    // Integer
    // ============================================================

    namespace R
    {
        // --------------------------------------------------------
        // Auxiliary M / S / T
        // --------------------------------------------------------

        constexpr int AUX_M_CODE = 100;                            // R100 M Code
        constexpr int AUX_S_CODE = 101;                            // R101 S Code
        constexpr int AUX_T_CODE = 102;                            // R102 T Code
        constexpr int AUX_VALID_MASK = 103;                        // R103 M/S/T ���ĸ�� Mask


        // --------------------------------------------------------
        // Manual Motion
        // --------------------------------------------------------

        constexpr int JOG_SPEED_PERCENT = 200;                     // R200 Normal JOG Speed 0~100%
        constexpr int INCH_DISTANCE_LEVEL = 201;                   // R201 INCH �Z������ 0~3
    }


    // ============================================================
    // DR Register
    //
    // PLC <-> NC
    // 32-bit Integer
    // ============================================================

    namespace DR
    {
        constexpr int MPG_ENCODER_COUNT = 200;                     // DR200 MPG ����ֿn Encoder Count
    }
}